/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.migration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import hudson.model.Job;

import java.util.UUID;

import jenkins.model.Jenkins;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.jvnet.hudson.test.JenkinsRule;
import org.jvnet.hudson.test.recipes.LocalData;
import org.jvnet.hudson.test.recipes.WithPlugin;

import de.bluecarat.trafficlight.TrafficLightConfigurator;
import de.bluecarat.trafficlight.configuration.LinkedTrafficLights;
import de.bluecarat.trafficlight.configuration.TrafficLightId;
import de.bluecarat.trafficlight.powerstrips.AbstractPowerStrip;
import de.bluecarat.trafficlight.powerstrips.InfraTecPowerStrip;
import de.bluecarat.trafficlight.powerstrips.NetControlPowerStrip;
import de.bluecarat.trafficlight.powerstrips.NetControlV4PowerStrip;
import de.bluecarat.trafficlight.powerstrips.PowerStripConfig;
import edu.umd.cs.findbugs.annotations.SuppressWarnings;

public class MigrationIntegrationTest {

    @Rule
    public JenkinsRule jenkinsRule = new JenkinsRule();

    private Jenkins jenkins = null;
    private TrafficLightConfigurator trafficLightConfigurator = null;

    @Before
    public void prepare() {
        jenkins = jenkinsRule.getInstance();
        trafficLightConfigurator = jenkins.getDescriptorByType(TrafficLightConfigurator.class);
    }

    @Test
    @WithPlugin("trafficlightcontroller-current.hpi")
    @LocalData
    public void shouldMigrateFrom23ToCurrent() throws Exception {
        verifyNumberOfTrafficLights(2);
        verifyGenerationOfUuids();
        verifyGenerationOfNames();

        verifyLinkageOfJobToTrafficLight("AAA", getIdFromTrafficLight(InfraTecPowerStrip.class));
        verifyLinkageOfJobToTrafficLight("BBB", getIdFromTrafficLight(InfraTecPowerStrip.class));
        verifyLinkageOfJobToTrafficLight("BBB", getIdFromTrafficLight(NetControlPowerStrip.class));
        verifyLinkageOfJobToTrafficLight("CCC", getIdFromTrafficLight(InfraTecPowerStrip.class));

        verifyGenerationOfPorts();
    }

    private void verifyGenerationOfPorts() {
        verifyGenerationOfPortFor(InfraTecPowerStrip.class, "80");
        verifyGenerationOfPortFor(NetControlPowerStrip.class, "80");
    }

    private void verifyGenerationOfPortFor(final Class< ? extends AbstractPowerStrip> powerStripType, final String port) {
        assertEquals(getPortFromTrafficLight(powerStripType), port);
    }

    private String getIdFromTrafficLight(final Class< ? extends AbstractPowerStrip> powerStripType) {
        for (final PowerStripConfig powerStripConfig : trafficLightConfigurator.getPowerStripList().getPowerStrips()) {
            if (powerStripConfig.getPowerStrip().getClass() == powerStripType) {
                return powerStripConfig.getPowerStrip().getId();
            }
        }
        return null;
    }

    private String getPortFromTrafficLight(final Class< ? extends AbstractPowerStrip> powerStripType) {
        for (final PowerStripConfig powerStripConfig : trafficLightConfigurator.getPowerStripList().getPowerStrips()) {
            if (powerStripConfig.getPowerStrip().getClass() == powerStripType) {
                return powerStripConfig.getPowerStrip().getPort();
            }
        }
        return null;
    }

    private void verifyLinkageOfJobToTrafficLight(final String jobIdentifier, final String idOfTrafficLight) {
        final LinkedTrafficLights property = getJob(jobIdentifier).getProperty(LinkedTrafficLights.class);
        assertTrue(property.getTrafficLights().contains(new TrafficLightId(idOfTrafficLight)));
    }

    @Test
    @WithPlugin("trafficlightcontroller-current.hpi")
    @LocalData
    public void shouldNotConsiderEmptyEntriesWhenMigratingFrom23ToCurrent() throws Exception {
        verifyNumberOfTrafficLights(0);

        verifyNoLinkageToTrafficLight("AAA");
        verifyNoLinkageToTrafficLight("BBB");
        verifyNoLinkageToTrafficLight("CCC");
    }

    private void verifyNoLinkageToTrafficLight(final String jobIdentifier) {
        assertNull(getJob(jobIdentifier).getProperty(LinkedTrafficLights.class));
    }

    @SuppressWarnings(value = "NP_NULL_ON_SOME_PATH", justification = "If something here is null a test will fail anyway.")
    private Job< ? , ? > getJob(final String jobIdentifier) {
        return jenkins.getItem(jobIdentifier).getAllJobs().iterator().next();
    }

    private void verifyGenerationOfNames() {
        for (final PowerStripConfig powerStripConfig : trafficLightConfigurator.getPowerStripList().getPowerStrips()) {
            final AbstractPowerStrip powerStrip = powerStripConfig.getPowerStrip();
            if (powerStrip instanceof InfraTecPowerStrip) {
                assertEquals("InfraTecTrafficLight", powerStrip.getName());
            } else if (powerStrip instanceof NetControlPowerStrip) {
                assertEquals("NetControlTrafficLight", powerStrip.getName());
            } else {
                fail("Unknown power strip found!");
            }
        }
    }

    private void verifyGenerationOfUuids() {
        for (final PowerStripConfig powerStripConfig : trafficLightConfigurator.getPowerStripList().getPowerStrips()) {
            try {
                UUID.fromString(powerStripConfig.getPowerStrip().getId());
            } catch (IllegalArgumentException e) {
                fail("Expected a valid UUID. The given one seems to be invalid: "
                        + powerStripConfig.getPowerStrip().getId());
            }
        }
    }

    private void verifyNumberOfTrafficLights(final int expectedNumber) {
        assertEquals(expectedNumber, trafficLightConfigurator.getPowerStripList().getPowerStrips().size());
    }

    @Test
    @WithPlugin("trafficlightcontroller-current.hpi")
    @LocalData
    public void shouldMigrateFrom30ToCurrent() throws Exception {
        verifyGenerationOfPorts();
        verifyNoChangeOfPortFor(NetControlV4PowerStrip.class, "71");
    }

    private void verifyNoChangeOfPortFor(final Class< ? extends AbstractPowerStrip> powerStripType, final String port) {
        assertEquals(getPortFromTrafficLight(powerStripType), port);
    }
}
