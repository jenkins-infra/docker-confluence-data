/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import hudson.util.Secret;

import java.net.URI;
import java.net.URISyntaxException;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import de.bluecarat.trafficlight.connectionhandler.HttpGetHandler;
import de.bluecarat.trafficlight.connectionhandler.HttpPostHandler;
import de.bluecarat.trafficlight.connectionhandler.exception.HandlerException;
import de.bluecarat.trafficlight.connectionhandler.exception.PowerStripCommunicationException;
import de.bluecarat.trafficlight.powerstrips.NetControlV4PowerStrip;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ HttpGetHandler.class, HttpPostHandler.class, Secret.class })
public class NetControlV4TrafficLightControllerTest {
    private static final String ALL_SOCKETS_OFF = ";;;;;;;;;;;;;;;;;;;;0;0;0";
    private static final String ALL_SOCKETS_ON = ";;;;;;;;;;;;;;;;;;;;1;1;1";
    private static final String FIRST_SOCKETS_ON = ";;;;;;;;;;;;;;;;;;;;1;0;0";
    private static final String FIRST_SOCKETS_OFF = ";;;;;;;;;;;;;;;;;;;;0;1;1";

    private NetControlV4TrafficLightController controller;

    @Mock
    private HttpGetHandler getHandler;

    @Mock
    private HttpPostHandler postHandler;

    @Mock
    Secret secret;

    @Rule
    ExpectedException thrown = ExpectedException.none();

    @Before
    public void prepare() {
        mockStatic(Secret.class);
        when(Secret.toString(secret)).thenReturn("somepassword");
        final NetControlV4PowerStrip powerStrip = new NetControlV4PowerStrip("dc9d87a0-08e2-11e4-a978-0002a5d5c51b",
                "some name", "somehost", "80", "some user", secret);
        controller = new NetControlV4TrafficLightController(powerStrip, getHandler, postHandler);
    }

    @Test
    public void shouldTakeNameFromConstructor() {
        assertEquals("some name", controller.getName());
    }

    @Test
    public void shouldTakeIdFromConstructor() {
        assertEquals("dc9d87a0-08e2-11e4-a978-0002a5d5c51b", controller.getId().toString());
    }

    @Test
    public void shouldTurnOnGreen() throws Exception {
        when(getHandler.handle(URI.create("http://somehost:80/strg.cfg"))).thenReturn(ALL_SOCKETS_OFF);
        controller.greenOn();
        verify(postHandler).handle(URI.create("http://somehost:80/ctrl.htm"), "F1=");
    }

    @Test
    public void shouldTurnOffGreen() throws Exception {
        when(getHandler.handle(URI.create("http://somehost:80/strg.cfg"))).thenReturn(ALL_SOCKETS_ON);
        controller.greenOff();
        verify(postHandler).handle(URI.create("http://somehost:80/ctrl.htm"), "F1=");
    }

    @Test
    public void shouldTurnOnYellow() throws Exception {
        when(getHandler.handle(URI.create("http://somehost:80/strg.cfg"))).thenReturn(FIRST_SOCKETS_OFF);
        controller.yellowOn();
        verify(postHandler).handle(URI.create("http://somehost:80/ctrl.htm"), "F0=");
    }

    @Test
    public void shouldTurnOffYellow() throws Exception {
        when(getHandler.handle(URI.create("http://somehost:80/strg.cfg"))).thenReturn(FIRST_SOCKETS_ON);
        controller.yellowOff();
        verify(postHandler).handle(URI.create("http://somehost:80/ctrl.htm"), "F0=");
    }

    @Test
    public void shouldTurnOnRed() throws Exception {
        when(getHandler.handle(URI.create("http://somehost:80/strg.cfg"))).thenReturn(ALL_SOCKETS_OFF);
        controller.redOn();
        verify(postHandler).handle(URI.create("http://somehost:80/ctrl.htm"), "F2=");
    }

    @Test
    public void shouldTurnOffRed() throws Exception {
        when(getHandler.handle(URI.create("http://somehost:80/strg.cfg"))).thenReturn(ALL_SOCKETS_ON);
        controller.redOff();
        verify(postHandler).handle(URI.create("http://somehost:80/ctrl.htm"), "F2=");
    }

    @Test
    public void shouldNotTurnOnGreenWhenAlreadyOn() throws Exception {
        when(getHandler.handle(URI.create("http://somehost:80/strg.cfg"))).thenReturn(ALL_SOCKETS_ON);
        controller.greenOn();
        verify(postHandler, never()).handle(URI.create("http://somehost:80/ctrl.htm"), "F1=");
    }

    @Test
    public void shouldNotTurnOffGreenWhenAlreadyOff() throws Exception {
        when(getHandler.handle(URI.create("http://somehost:80/strg.cfg"))).thenReturn(ALL_SOCKETS_OFF);
        controller.greenOff();
        verify(postHandler, never()).handle(URI.create("http://somehost:80/ctrl.htm"), "F1=");
    }

    @Test
    public void shouldNotTurnOnYellownWhenAlreadyOn() throws Exception {
        when(getHandler.handle(URI.create("http://somehost:80/strg.cfg"))).thenReturn(FIRST_SOCKETS_ON);
        controller.yellowOn();
        verify(postHandler, never()).handle(URI.create("http://somehost:80/ctrl.htm"), "F0=");
    }

    @Test
    public void shouldNotTurnOffYellowWhenAlreadyOff() throws Exception {
        when(getHandler.handle(URI.create("http://somehost:80/strg.cfg"))).thenReturn(FIRST_SOCKETS_OFF);
        controller.yellowOff();
        verify(postHandler, never()).handle(URI.create("http://somehost:80/ctrl.htm"), "F0=");
    }

    @Test
    public void shouldNotTurnOnRedWhenAlreadyOn() throws Exception {
        when(getHandler.handle(URI.create("http://somehost:80/strg.cfg"))).thenReturn(ALL_SOCKETS_ON);
        controller.redOn();
        verify(postHandler, never()).handle(URI.create("http://somehost:80/ctrl.htm"), "F2=");
    }

    @Test
    public void shouldNotTurnOffRedWhenAlreadyOff() throws Exception {
        when(getHandler.handle(URI.create("http://somehost:80/strg.cfg"))).thenReturn(ALL_SOCKETS_OFF);
        controller.redOff();
        verify(postHandler, never()).handle(URI.create("http://somehost:80/ctrl.htm"), "F2=");
    }

    @Test
    public void shouldThrowPowerStripCommunicationExceptionWhenHostnameIsIllegalForPost() throws Exception {
        when(getHandler.handle(URI.create("http://somehost:80/strg.cfg"))).thenReturn(ALL_SOCKETS_OFF);
        doThrow(URISyntaxException.class).when(postHandler).handle(any(URI.class), anyString());

        thrown.expect(PowerStripCommunicationException.class);
        controller.greenOn();
    }

    @Test
    public void shoulThrowPowerStripCommunicationExceptionWhenHandlerHasAnErrorForPost() throws Exception {
        when(getHandler.handle(URI.create("http://somehost:80/strg.cfg"))).thenReturn(ALL_SOCKETS_OFF);
        doThrow(HandlerException.class).when(postHandler).handle(any(URI.class), anyString());

        thrown.expect(PowerStripCommunicationException.class);
        controller.greenOn();
    }

    @Test
    public void shouldThrowPowerStripCommunicationExceptionWhenHostnameIsIllegalForGet() throws Exception {
        doThrow(URISyntaxException.class).when(getHandler).handle(any(URI.class));
        thrown.expect(PowerStripCommunicationException.class);
        controller.greenOn();
    }

    @Test
    public void shouldThrowPowerStripCommunicationExceptionWhenHandlerHasAnErrorForGet() throws Exception {
        doThrow(HandlerException.class).when(getHandler).handle(any(URI.class));
        thrown.expect(PowerStripCommunicationException.class);
        controller.greenOn();
    }

    @Test
    public void shouldThrowPowerStripCommunicationExceptionWhenResponseCanNotBeParsed() throws Exception {
        when(getHandler.handle(URI.create("http://somehost:80/strg.cfg"))).thenReturn("invalid response");
        thrown.expect(PowerStripCommunicationException.class);
        controller.redOn();
    }

    @Test
    public void shouldThrowPowerStripCommunicationExceptionWhenWhenResponseCanNotBeParsed() throws Exception {
        when(getHandler.handle(URI.create("http://somehost:80/strg.cfg"))).thenReturn("invalid response");
        thrown.expect(PowerStripCommunicationException.class);
        controller.redOn();
    }
}
