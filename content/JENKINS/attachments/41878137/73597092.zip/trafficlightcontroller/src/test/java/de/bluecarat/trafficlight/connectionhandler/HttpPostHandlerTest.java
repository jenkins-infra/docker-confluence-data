/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.connectionhandler;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.verify;
import static com.github.tomakehurst.wiremock.http.Fault.RANDOM_DATA_THEN_CLOSE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.springframework.util.Assert.isInstanceOf;

import java.net.SocketTimeoutException;
import java.net.URI;

import org.apache.commons.httpclient.HttpStatus;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.junit.WireMockRule;

import de.bluecarat.trafficlight.connectionhandler.exception.HandlerException;

public class HttpPostHandlerTest {

    private URI mockUri = null;

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(0);

    private HttpPostHandler handler = null;

    @Before
    public void prepare() throws Exception {
        mockUri = URI.create("http://localhost:" + wireMockRule.port());
        handler = new HttpPostHandler(200);
    }

    @Test
    public void shouldUseURIFromParameter() throws Exception {
        stubFor(post(urlEqualTo("/test/")).willReturn(aResponse()));
        handler.handle(URI.create(mockUri.toString() + "/test/"), "");
        verify(postRequestedFor(urlEqualTo("/test/")));
    }

    @Test
    public void shouldUseContentFromParameterAsBody() throws Exception {
        stubFor(post(urlEqualTo("/")).willReturn(aResponse()));
        handler.handle(mockUri, "a cool body");
        verify(postRequestedFor(urlEqualTo("/")).withRequestBody(WireMock.matching("a cool body")));
    }

    @Test
    public void shouldThrowHandlerExceptionIfStatusCodeIsNotOK() throws Exception {
        stubFor(post(urlEqualTo("/")).willReturn(aResponse().withStatus(HttpStatus.SC_BAD_REQUEST)));

        try {
            handler.handle(mockUri, "");
            fail();
        } catch (HandlerException e) {
            isInstanceOf(HandlerException.class, e);
            assertEquals("Unexpected response, aborting (localhost). Status code: 400", e.getMessage());
        }

    }

    @Test
    public void shouldThrowHandlerExceptionIfAnHttpErrorOccured() throws Exception {
        stubFor(post(urlEqualTo("/")).willReturn(aResponse().withFault(RANDOM_DATA_THEN_CLOSE)));

        try {
            handler.handle(mockUri, "");
            fail();
        } catch (HandlerException e) {
            isInstanceOf(HandlerException.class, e);
            assertEquals("Unexpected Error, aborting (localhost).", e.getMessage());
        }

    }

    @Test
    public void shouldThrowHandlerExceptionOnConnectionTimeout() {
        stubFor(post(urlEqualTo("/")).willReturn(aResponse().withFixedDelay(250)));
        try {
            handler.handle(mockUri, "");
            fail();
        } catch (HandlerException e) {
            isInstanceOf(HandlerException.class, e);
            isInstanceOf(SocketTimeoutException.class, e.getCause());
            assertEquals("Unexpected Error, aborting (localhost).", e.getMessage());
        }
    }
}
