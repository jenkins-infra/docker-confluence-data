/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.configuration;

import static java.util.Arrays.asList;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import de.bluecarat.trafficlight.configuration.TrafficLightId.TrafficLightIdDescriptor;
import de.bluecarat.trafficlight.configuration.TrafficLightId.TrafficLightIdDescriptor.TrafficLight;
import de.bluecarat.trafficlight.controller.TrafficLightController;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ TrafficLightRegistry.class })
public class TrafficLightIdTest {

    private TrafficLightIdDescriptor descriptor = null;

    @Mock
    private TrafficLightRegistry registry;

    @Mock
    private TrafficLightController controller;

    @Mock
    private TrafficLightController controller1;

    @Mock
    private TrafficLightController controller2;

    @Before
    public void prepare() throws Exception {
        descriptor = new TrafficLightIdDescriptor();
    }

    @Test
    public void shouldGetAvailableTrafficLights() throws Exception {
        mockRegistryForTwoControllers("some id", "some other id");

        final List<String> availableIds = getIdsFromLights(descriptor.getAvailableTrafficLights());

        assertTrue(availableIds.contains("some id"));
        assertTrue(availableIds.contains("some other id"));
    }

    private void mockRegistryForTwoControllers(final String id1, final String id2) {
        descriptor.setTrafficLightRegistry(registry);
        when(registry.getAllControllerIds()).thenReturn(asSet(id1, id2));
        when(registry.getControllerById(id1)).thenReturn(controller1);
        when(registry.getControllerById(id2)).thenReturn(controller2);
    }

    @Test
    public void shouldGetIdAndName() throws Exception {
        descriptor.setTrafficLightRegistry(registry);
        when(registry.getAllControllerIds()).thenReturn(asSet("some id"));
        when(registry.getControllerById("some id")).thenReturn(controller);
        when(controller.getName()).thenReturn("some name");

        final TrafficLight light = descriptor.getAvailableTrafficLights().get(0);

        assertEquals(light.getId(), "some id");
        assertEquals(light.getName(), "some name");
    }

    @Test
    public void shouldGetDefaultDisplayName() throws Exception {
        assertEquals(descriptor.getDisplayName(), "TrafficLightIdDescriptor");
    }

    private List<String> getIdsFromLights(final List<TrafficLight> lights) {
        final List<String> availableIds = new ArrayList<String>();
        for (final TrafficLight light : lights) {
            availableIds.add(light.getId());
        }
        return availableIds;
    }

    private Set<String> asSet(final String... strings) {
        return new HashSet<String>(asList(strings));
    }

    @Test
    public void shouldUseIdFromConstructor() throws Exception {
        final TrafficLightId id = new TrafficLightId("some id");
        assertEquals(id.getId(), "some id");
    }

    @Test
    public void shouldRetrieveEmptyListWhenRegistryIsNull() throws Exception {
        descriptor.setTrafficLightRegistry(null);
        assertTrue(descriptor.getAvailableTrafficLights().isEmpty());
    }
}
