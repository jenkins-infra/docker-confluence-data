/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.powerstrips;

import static java.util.Arrays.asList;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.containsString;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import hudson.Extension;
import hudson.util.FormValidation;
import hudson.util.FormValidation.Kind;

import java.util.HashSet;
import java.util.UUID;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import de.bluecarat.trafficlight.configuration.TrafficLightRegistry;
import de.bluecarat.trafficlight.connectionhandler.exception.PowerStripCommunicationException;
import de.bluecarat.trafficlight.controller.TrafficLightController;
import de.bluecarat.trafficlight.powerstrips.AbstractPowerStripDescriptorWithValidationTest.DescribableForTest.Validation;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ TrafficLightRegistry.class })
public class AbstractPowerStripDescriptorWithValidationTest {

    private Validation validator = null;

    @Mock
    private AbstractPowerStrip strip;

    @Mock
    private TrafficLightRegistry registry;

    @Mock
    private TrafficLightController controller1;

    @Mock
    private TrafficLightController controller2;

    @Before
    public void prepare() throws Exception {
        validator = new Validation();
    }

    @Test
    public void shouldBeInvalidWhenNameIsEmpty() throws Exception {
        final FormValidation validation = validator.doCheckName("", null);
        assertThat(validation.kind, is(Kind.ERROR));
        assertThat(validation.renderHtml(), containsString("The name may not be empty!"));
    }

    @Test
    public void shouldBeInvalidWhenNameIsNull() throws Exception {
        final FormValidation validation = validator.doCheckName(null, null);
        assertThat(validation.kind, is(Kind.ERROR));
        assertThat(validation.renderHtml(), containsString("The name may not be empty!"));
    }

    @Test
    public void shouldBeInvalidWhenNameIsAlreadyTaken() throws Exception {
        mockRegistryToHaveTwoTrafficLights("name1", "ce6ba1d0-5473-11e4-916c-0800200c9a66", "name2",
                "ddad4590-5473-11e4-916c-0800200c9a67");

        final FormValidation validation = validator.doCheckName("name1", null);

        assertThat(validation.kind, is(Kind.ERROR));
        assertThat(validation.renderHtml(), containsString("The name is already in use!"));
    }

    @Test
    public void shouldBeValidWhenNameIsAlreadyTakenButTrafficLightIsTheSame() throws Exception {
        mockRegistryToHaveTwoTrafficLights("name1", "ce6ba1d0-5473-11e4-916c-0800200c9a66", "name2",
                "ddad4590-5473-11e4-916c-0800200c9a67");
        final FormValidation validation = validator.doCheckName("name1", "ce6ba1d0-5473-11e4-916c-0800200c9a66");
        assertThat(validation.kind, is(Kind.OK));
    }

    @Test
    public void shouldBeValidWhenNameIsAvailable() throws Exception {
        mockRegistryToHaveTwoTrafficLights("name1", "ce6ba1d0-5473-11e4-916c-0800200c9a66", "name2",
                "ddad4590-5473-11e4-916c-0800200c9a67");
        final FormValidation validation = validator.doCheckName("name3", "ce6ba1d0-5473-11e4-916c-0800200c9a68");
        assertThat(validation.kind, is(Kind.OK));
    }

    @Test
    public void shouldBeValidWhenRegistryIsNull() throws Exception {
        final FormValidation validation = validator.doCheckName("a name", null);
        assertThat(validation.kind, is(Kind.OK));
    }

    private void mockRegistryToHaveTwoTrafficLights(final String name1, final String id1, final String name2,
            final String id2) {
        validator.setTrafficLightRegistry(registry);
        when(registry.getAllControllerIds()).thenReturn(new HashSet<String>(asList(id1, id2)));
        when(registry.getControllerById(id1)).thenReturn(controller1);
        when(registry.getControllerById(id2)).thenReturn(controller2);
        when(controller1.getName()).thenReturn(name1);
        when(controller1.getId()).thenReturn(UUID.fromString(id1));
        when(controller2.getName()).thenReturn(name2);
        when(controller2.getId()).thenReturn(UUID.fromString(id2));
    }

    @Test
    public void shouldBeInvalidWhenPortIsNotNumber() throws Exception {
        final FormValidation validation = validator.doCheckPort("am I a number?");
        assertThat(validation.kind, is(Kind.ERROR));
        assertThat(validation.renderHtml(), containsString("The port must be a number between 1 and 65535"));
    }

    @Test
    public void shouldBeInvalidWhenPortIsTooLow() throws Exception {
        final FormValidation validation = validator.doCheckPort("-1");
        assertThat(validation.kind, is(Kind.ERROR));
        assertThat(validation.renderHtml(), containsString("The port must be a number between 1 and 65535"));
    }

    @Test
    public void shouldBeInvalidWhenPortIsTooHigh() throws Exception {
        final FormValidation validation = validator.doCheckPort("65536");
        assertThat(validation.kind, is(Kind.ERROR));
        assertThat(validation.renderHtml(), containsString("The port must be a number between 1 and 65535"));
    }

    @Test
    public void shouldBeValidWhenPortMatchesSpecification() throws Exception {
        final FormValidation validation = validator.doCheckPort("8080");
        assertThat(validation.kind, is(Kind.OK));
    }

    @Test
    public void shouldBeValidWhenPortIsEmpty() throws Exception {
        final FormValidation validation = validator.doCheckPort("");
        assertThat(validation.kind, is(Kind.OK));
    }

    @Test
    public void shouldBlinkIfConnectionIsGood() throws Exception {
        validator.strip = strip;
        when(strip.createController()).thenReturn(controller1);
        validator.doTestConnection(null, null, null, null, null);
        verify(controller1).blink();
    }

    @Test
    public void shouldReturnFormValidationOkWhenConnectionIsGood() throws Exception {
        validator.strip = strip;
        when(strip.createController()).thenReturn(controller1);
        assertThat(validator.doTestConnection(null, null, null, null, null).toString(), containsString("OK"));
    }

    @Test
    public void shouldReturnFormValidationErrorWhenConnectionIsNotGood() throws Exception {
        validator.strip = strip;
        when(strip.createController()).thenReturn(controller1);
        doThrow(new PowerStripCommunicationException("msg")).when(controller1).blink();

        assertThat(validator.doTestConnection(null, null, null, null, null).toString(), containsString("ERROR"));
    }

    @Test
    public void shouldReturnMessageWhenConnectionIsNotGood() throws Exception {
        validator.strip = strip;
        when(strip.createController()).thenReturn(controller1);
        doThrow(new PowerStripCommunicationException("msg")).when(controller1).blink();

        final FormValidation result = validator.doTestConnection(null, null, null, null, null);

        assertThat(result.getMessage(), is("PowerStripCommunicationException: msg"));
    }

    @Test
    public void shouldSetTrafficLightsWhenConnectionIsGood() throws Exception {
        validator.strip = strip;
        when(strip.createController()).thenReturn(controller1);
        validator.setTrafficLightRegistry(registry);
        when(registry.getControllerById("id")).thenReturn(controller1);

        validator.doTestConnection("id", null, null, null, null);

        verify(controller1).setTrafficLights();
    }

    @Test
    public void shouldHaveMessageWhenConnectionIsGood() throws Exception {
        validator.strip = strip;
        when(strip.createController()).thenReturn(controller1);
        assertThat(validator.doTestConnection(null, null, null, null, null).renderHtml(),
                containsString("You should&#039;ve seen the lights blinking!"));
    }

    @Test
    public void shouldNotSetTrafficLightsWhenConnectionIsGoodButControllerIsNull() throws Exception {
        validator.strip = strip;
        when(strip.createController()).thenReturn(controller1);
        validator.setTrafficLightRegistry(registry);
        when(registry.getControllerById("id")).thenReturn(null);

        validator.doTestConnection("id", null, null, null, null);

        verify(controller1, never()).setTrafficLights();
    }

    @Test
    public void shouldNotSetTrafficLightsWhenConnectionIsGoodButRegistryIsNull() throws Exception {
        validator.strip = strip;
        when(strip.createController()).thenReturn(controller1);
        validator.setTrafficLightRegistry(null);

        validator.doTestConnection("id", null, null, null, null);

        verify(controller1, never()).setTrafficLights();
    }

    @Test
    public void shouldBeValidWhenNameIsAvailableAndIdIsEmpty() throws Exception {
        mockRegistryToHaveTwoTrafficLights("name1", "ce6ba1d0-5473-11e4-916c-0800200c9a66", "name2",
                "ddad4590-5473-11e4-916c-0800200c9a67");
        final FormValidation validation = validator.doCheckName("name3", "");
        assertThat(validation.kind, is(Kind.OK));
    }

    @Test
    public void shouldBeValidWhenNameIsAvailableAndIdIsNull() throws Exception {
        mockRegistryToHaveTwoTrafficLights("name1", "ce6ba1d0-5473-11e4-916c-0800200c9a66", "name2",
                "ddad4590-5473-11e4-916c-0800200c9a67");
        final FormValidation validation = validator.doCheckName("name3", null);
        assertThat(validation.kind, is(Kind.OK));
    }

    public static class DescribableForTest extends AbstractPowerStrip {
        public DescribableForTest(final String id, final String name, final String address, final String port) {
            super(id, name, address, port);
        }

        @Override
        public TrafficLightController createController() {
            return null;
        }

        @Extension
        public static class Validation extends AbstractPowerStripDescriptorWithValidation {

            public AbstractPowerStrip strip;

            @Override
            public String getDisplayName() {
                return Validation.class.getSimpleName();
            }

            @Override
            protected AbstractPowerStrip getSpecificPowerStrip(final String address, final String port,
                    final String username, final String password) {
                return strip;
            }
        }
    }
}
