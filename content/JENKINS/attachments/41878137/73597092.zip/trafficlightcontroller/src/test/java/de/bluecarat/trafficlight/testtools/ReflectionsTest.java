/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.testtools;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.lang.reflect.Constructor;

import org.junit.Test;
import org.kohsuke.stapler.DataBoundConstructor;

public class ReflectionsTest {

    @Test
    public void shouldFindAnnotation() throws Exception {
        final Constructor< ? >[] constructors = ClassWithDataBoundConstructor.class.getConstructors();
        assertThat(Reflections.hasDataboundConstructor(constructors), is(true));
    }

    @Test
    public void shouldNotFindAnnotation() throws Exception {
        final Constructor< ? >[] constructors = ClassWithoutDataBoundConstructor.class.getConstructors();
        assertThat(Reflections.hasDataboundConstructor(constructors), is(false));
    }

    private static class ClassWithDataBoundConstructor {
        @DataBoundConstructor
        public ClassWithDataBoundConstructor() {
        }
    }

    private static class ClassWithoutDataBoundConstructor {
    }
}
