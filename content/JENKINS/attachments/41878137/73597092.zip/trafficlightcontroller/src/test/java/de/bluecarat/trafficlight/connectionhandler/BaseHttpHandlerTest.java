/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.connectionhandler;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.apache.commons.httpclient.HttpState;
import org.apache.commons.httpclient.auth.AuthScope;
import org.apache.commons.httpclient.params.HttpClientParams;
import org.apache.commons.httpclient.params.HttpConnectionManagerParams;
import org.junit.Before;
import org.junit.Test;

public class BaseHttpHandlerTest {

    private BaseHttpHandler handler = null;

    @Before
    public void prepare() throws Exception {
        handler = new BaseHttpHandler(200);
    }

    @Test
    public void shouldNotUseCredentialsByDefault() throws Exception {
        final HttpState state = handler.getHttpclient().getState();
        assertNull(state.getCredentials(AuthScope.ANY));
    }

    @Test
    public void shouldUseCredentialsFromContructor() throws Exception {
        handler = new BaseHttpHandler("some user", "some password", 200);
        final HttpState state = handler.getHttpclient().getState();
        assertEquals("some user:some password", state.getCredentials(AuthScope.ANY).toString());
    }

    @Test
    public void shouldUsePreemtiveAuthentication() throws Exception {
        handler = new BaseHttpHandler("some user", "some password", 200);
        final HttpClientParams params = handler.getHttpclient().getParams();
        assertTrue(params.isAuthenticationPreemptive());
    }

    @Test
    public void shouldNotUsePreemtiveAuthenticationByDefault() throws Exception {
        final HttpClientParams params = handler.getHttpclient().getParams();
        assertFalse(params.isAuthenticationPreemptive());
    }

    @Test
    public void shouldUseTimeoutFromConstructor() throws Exception {
        final HttpConnectionManagerParams params = handler.getHttpclient().getHttpConnectionManager().getParams();
        assertEquals(200, params.getSoTimeout());
        assertEquals(200, params.getConnectionTimeout());
    }

}
