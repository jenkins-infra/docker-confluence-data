/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.services;

import static java.util.Arrays.asList;
import static java.util.Collections.EMPTY_LIST;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import hudson.ExtensionList;
import hudson.util.Secret;

import java.util.Iterator;
import java.util.UUID;

import jenkins.model.Jenkins;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import de.bluecarat.trafficlight.NullSafeJenkins;
import de.bluecarat.trafficlight.TrafficLightStateUpdater;
import de.bluecarat.trafficlight.configuration.TrafficLightId.TrafficLightIdDescriptor;
import de.bluecarat.trafficlight.configuration.TrafficLightRegistry;
import de.bluecarat.trafficlight.powerstrips.AbstractPowerStrip;
import de.bluecarat.trafficlight.powerstrips.InfraTecPowerStrip;
import de.bluecarat.trafficlight.powerstrips.InfraTecPowerStrip.InfraTecPowerStripDescriptor;
import de.bluecarat.trafficlight.powerstrips.NetControlPowerStrip;
import de.bluecarat.trafficlight.powerstrips.NetControlPowerStrip.NetControlPowerStripDescriptor;
import de.bluecarat.trafficlight.powerstrips.NetControlV4PowerStrip;
import de.bluecarat.trafficlight.powerstrips.NetControlV4PowerStrip.NetControlV4PowerStripDescriptor;
import de.bluecarat.trafficlight.powerstrips.PowerStripConfig;
import de.bluecarat.trafficlight.powerstrips.PowerStripList;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ TrafficLightRegistry.class, PowerStripList.class, NullSafeJenkins.class, PowerStripConfig.class,
        TrafficLightStateUpdater.class, NetControlPowerStrip.class, Secret.class, NetControlV4PowerStrip.class,
        InfraTecPowerStrip.class, TrafficLightIdDescriptor.class })
public class TrafficLightRegistryConfiguratorTest {

    private TrafficLightRegistryConfigurator configurator = null;

    @Mock
    private TrafficLightRegistry registry;

    @Mock
    private PowerStripList powerStripList;

    @Mock
    private TrafficLightStateUpdater stateUpdater1;

    @Mock
    private TrafficLightStateUpdater stateUpdater2;

    @Mock
    TrafficLightIdDescriptor job1;

    @Mock
    TrafficLightIdDescriptor job2;

    @Mock
    private Jenkins jenkins;

    @Mock
    private PowerStripConfig config;

    @Mock
    private NetControlPowerStrip netControl;

    @Mock
    private NetControlV4PowerStrip netControlV4;

    @Mock
    private InfraTecPowerStrip infraTec;

    @Mock
    private InfraTecPowerStripDescriptor infraTecDescriptor;

    @Mock
    private NetControlPowerStripDescriptor netControlDescriptor;

    @Mock
    private NetControlV4PowerStripDescriptor netControlV4Descriptor;

    @Mock
    private Secret secret;

    @Before
    public void prepare() throws Exception {
        configurator = new TrafficLightRegistryConfigurator();
        mockJenkins();
    }

    private void mockJenkins() {
        mockStatic(NullSafeJenkins.class);
        when(NullSafeJenkins.getInstance()).thenReturn(jenkins);
    }

    @Test
    public void shouldBeNullSafeForRegistry() throws Exception {
        mockEmptyExtensionsForTrafficLightStateUpdater();
        mockEmptyExtensionsForTrafficLightIdDescriptors();

        configurator.initializeTrafficLightRegistry(null, powerStripList);

        assertThat(true, is(true));
    }

    @Test
    public void shouldBeNullSafeForPowerStripList() throws Exception {
        mockEmptyExtensionsForTrafficLightStateUpdater();
        mockEmptyExtensionsForTrafficLightIdDescriptors();

        configurator.initializeTrafficLightRegistry(registry, null);

        assertThat(true, is(true));
    }

    @Test
    public void shouldBeNullSafeForPowerStripsOfPowerStripList() throws Exception {
        when(powerStripList.getPowerStrips()).thenReturn(null);
        mockEmptyExtensionsForTrafficLightStateUpdater();
        mockEmptyExtensionsForTrafficLightIdDescriptors();

        configurator.initializeTrafficLightRegistry(registry, powerStripList);

        assertThat(true, is(true));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void shouldUsePowerStripsOfPowerStripList() throws Exception {
        when(powerStripList.getPowerStrips()).thenReturn(EMPTY_LIST);
        mockEmptyExtensionsForTrafficLightStateUpdater();
        mockEmptyExtensionsForTrafficLightIdDescriptors();

        configurator.initializeTrafficLightRegistry(registry, powerStripList);

        verify(powerStripList, times(2)).getPowerStrips();
    }

    @SuppressWarnings("unchecked")
    private <T> ExtensionList<T> mockEmptyExtensionList() {
        final ExtensionList<T> extensions = mock(ExtensionList.class);
        final Iterator<T> iterator = mock(Iterator.class);
        when(extensions.iterator()).thenReturn(iterator);
        when(iterator.hasNext()).thenReturn(false);
        return extensions;
    }

    @SuppressWarnings("unchecked")
    private <T> void mockExtensionListWithTwoEntries(final T entry1, final T entry2, final Class<T> clazz) {
        final ExtensionList<T> extensions = mock(ExtensionList.class);
        final Iterator<T> iterator = mock(Iterator.class);
        when(extensions.iterator()).thenReturn(iterator);
        when(iterator.hasNext()).thenReturn(true, true, false);
        when(iterator.next()).thenReturn(entry1, entry2);
        when(jenkins.getExtensionList(clazz)).thenReturn(extensions);
    }

    private void mockConfigToHavePowerStrip(final AbstractPowerStrip strip) {
        when(config.getPowerStrip()).thenReturn(strip);
        when(strip.getId()).thenReturn(UUID.randomUUID().toString());
        when(strip.getAddress()).thenReturn("");
    }

    private void mockConfigToHaveNetControl(final NetControlPowerStrip strip) {
        mockConfigToHavePowerStrip(strip);
    }

    private void mockConfigToHaveNetControlV4(final NetControlV4PowerStrip strip) {
        mockConfigToHavePowerStrip(strip);
        when(strip.getUsername()).thenReturn("");
        when(strip.getPassword()).thenReturn(secret);
    }

    private void mockConfigToHaveInfraTec(final InfraTecPowerStrip strip) {
        mockConfigToHavePowerStrip(strip);
        when(strip.getUsername()).thenReturn("");
        when(strip.getPassword()).thenReturn(secret);
        mockStatic(Secret.class);
        when(Secret.toString(secret)).thenReturn("");
    }

    private void mockEmptyExtensionsForTrafficLightIdDescriptors() {
        final ExtensionList<TrafficLightIdDescriptor> descriptors = mockEmptyExtensionList();
        when(jenkins.getExtensionList(TrafficLightIdDescriptor.class)).thenReturn(descriptors);
    }

    private void mockEmptyExtensionsForTrafficLightStateUpdater() {
        final ExtensionList<TrafficLightStateUpdater> updaters = mockEmptyExtensionList();
        when(jenkins.getExtensionList(TrafficLightStateUpdater.class)).thenReturn(updaters);
    }

    @Test
    public void shouldCreateNetControlController() throws Exception {
        when(powerStripList.getPowerStrips()).thenReturn(asList(config));
        mockConfigToHaveNetControl(netControl);
        mockEmptyExtensionsForTrafficLightStateUpdater();
        mockEmptyExtensionsForTrafficLightIdDescriptors();

        configurator.initializeTrafficLightRegistry(registry, powerStripList);

        verify(netControl).createController();
    }

    @Test
    public void shouldCreateNetControlV4Controller() throws Exception {
        when(powerStripList.getPowerStrips()).thenReturn(asList(config));
        mockConfigToHaveNetControlV4(netControlV4);
        mockEmptyExtensionsForTrafficLightStateUpdater();
        mockEmptyExtensionsForTrafficLightIdDescriptors();

        configurator.initializeTrafficLightRegistry(registry, powerStripList);

        verify(netControlV4).createController();
    }

    @Test
    public void shouldCreateInfratecController() throws Exception {
        when(powerStripList.getPowerStrips()).thenReturn(asList(config));
        mockConfigToHaveInfraTec(infraTec);
        mockEmptyExtensionsForTrafficLightStateUpdater();
        mockEmptyExtensionsForTrafficLightIdDescriptors();

        configurator.initializeTrafficLightRegistry(registry, powerStripList);

        verify(infraTec).createController();
    }

    @SuppressWarnings("unchecked")
    @Test
    public void shouldSetRegistryOnTrafficLightStateUpdater() throws Exception {
        when(powerStripList.getPowerStrips()).thenReturn(EMPTY_LIST);
        mockEmptyExtensionsForTrafficLightIdDescriptors();
        mockExtensionListWithTwoEntries(stateUpdater1, stateUpdater2, TrafficLightStateUpdater.class);

        configurator.initializeTrafficLightRegistry(registry, powerStripList);

        verify(stateUpdater1).setTrafficLightRegistry(registry);
        verify(stateUpdater2).setTrafficLightRegistry(registry);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void shouldSetNullRegistryOnTrafficLightStateUpdater() throws Exception {
        when(powerStripList.getPowerStrips()).thenReturn(EMPTY_LIST);
        mockEmptyExtensionsForTrafficLightIdDescriptors();
        mockExtensionListWithTwoEntries(stateUpdater1, stateUpdater2, TrafficLightStateUpdater.class);

        configurator.initializeTrafficLightRegistry(null, powerStripList);

        verify(stateUpdater1).setTrafficLightRegistry(null);
        verify(stateUpdater2).setTrafficLightRegistry(null);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void shouldSetRegistryOnJobs() throws Exception {
        when(powerStripList.getPowerStrips()).thenReturn(EMPTY_LIST);
        mockEmptyExtensionsForTrafficLightStateUpdater();
        mockExtensionListWithTwoEntries(job1, job2, TrafficLightIdDescriptor.class);

        configurator.initializeTrafficLightRegistry(registry, powerStripList);

        verify(job1).setTrafficLightRegistry(registry);
        verify(job2).setTrafficLightRegistry(registry);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void shouldSetNullRegistryOnJobs() throws Exception {
        when(powerStripList.getPowerStrips()).thenReturn(EMPTY_LIST);
        mockEmptyExtensionsForTrafficLightStateUpdater();
        mockExtensionListWithTwoEntries(job1, job2, TrafficLightIdDescriptor.class);

        configurator.initializeTrafficLightRegistry(null, powerStripList);

        verify(job1).setTrafficLightRegistry(null);
        verify(job2).setTrafficLightRegistry(null);
    }

    @Test
    public void shouldSetRegistryOnInfraTecDescriptor() throws Exception {
        mockEmptyExtensionsForTrafficLightStateUpdater();
        mockEmptyExtensionsForTrafficLightIdDescriptors();
        when(jenkins.getDescriptorByType(InfraTecPowerStripDescriptor.class)).thenReturn(infraTecDescriptor);

        configurator.initializeTrafficLightRegistry(registry, powerStripList);

        verify(infraTecDescriptor).setTrafficLightRegistry(registry);
    }

    @Test
    public void shouldSetNullRegistryOnInfraTecDescriptor() throws Exception {
        mockEmptyExtensionsForTrafficLightStateUpdater();
        mockEmptyExtensionsForTrafficLightIdDescriptors();
        when(jenkins.getDescriptorByType(InfraTecPowerStripDescriptor.class)).thenReturn(infraTecDescriptor);

        configurator.initializeTrafficLightRegistry(null, powerStripList);

        verify(infraTecDescriptor).setTrafficLightRegistry(null);
    }

    @Test
    public void shouldSetRegistryOnNetControlDescriptor() throws Exception {
        mockEmptyExtensionsForTrafficLightStateUpdater();
        mockEmptyExtensionsForTrafficLightIdDescriptors();
        when(jenkins.getDescriptorByType(NetControlPowerStripDescriptor.class)).thenReturn(netControlDescriptor);

        configurator.initializeTrafficLightRegistry(registry, powerStripList);

        verify(netControlDescriptor).setTrafficLightRegistry(registry);
    }

    @Test
    public void shouldSetNullRegistryOnNetControlDescriptor() throws Exception {
        mockEmptyExtensionsForTrafficLightStateUpdater();
        mockEmptyExtensionsForTrafficLightIdDescriptors();
        when(jenkins.getDescriptorByType(NetControlPowerStripDescriptor.class)).thenReturn(netControlDescriptor);

        configurator.initializeTrafficLightRegistry(null, powerStripList);

        verify(netControlDescriptor).setTrafficLightRegistry(null);
    }

    @Test
    public void shouldSetRegistryOnNetControlV4Descriptor() throws Exception {
        mockEmptyExtensionsForTrafficLightStateUpdater();
        mockEmptyExtensionsForTrafficLightIdDescriptors();
        when(jenkins.getDescriptorByType(NetControlV4PowerStripDescriptor.class)).thenReturn(netControlV4Descriptor);

        configurator.initializeTrafficLightRegistry(registry, powerStripList);

        verify(netControlV4Descriptor).setTrafficLightRegistry(registry);
    }

    @Test
    public void shouldSetNullRegistryOnNetControlV4Descriptor() throws Exception {
        mockEmptyExtensionsForTrafficLightStateUpdater();
        mockEmptyExtensionsForTrafficLightIdDescriptors();
        when(jenkins.getDescriptorByType(NetControlV4PowerStripDescriptor.class)).thenReturn(netControlV4Descriptor);

        configurator.initializeTrafficLightRegistry(null, powerStripList);

        verify(netControlV4Descriptor).setTrafficLightRegistry(null);
    }

    @Test
    public void shouldNotSetRegistryOnDescriptorWhenDescriptorIsNull() throws Exception {
        mockEmptyExtensionsForTrafficLightStateUpdater();
        mockEmptyExtensionsForTrafficLightIdDescriptors();
        when(jenkins.getDescriptorByType(InfraTecPowerStripDescriptor.class)).thenReturn(null);

        configurator.initializeTrafficLightRegistry(registry, powerStripList);

        verify(infraTecDescriptor, never()).setTrafficLightRegistry(registry);
    }
}
