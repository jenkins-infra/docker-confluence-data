/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.migration;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;

public class MigrationConfigTest {

    @Test
    public void migrationConfig() {
        MigrationConfig config = new MigrationConfig();
        List<Migrator> migrators = config.getMigrators();
        assertTrue(migrators.get(0) instanceof Migrator23To30);
        assertTrue(migrators.get(1) instanceof Migrator30To31);
    }
}
