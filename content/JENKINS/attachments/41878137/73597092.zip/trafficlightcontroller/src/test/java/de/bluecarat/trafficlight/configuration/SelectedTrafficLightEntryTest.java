/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.configuration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;

import org.junit.Test;

public class SelectedTrafficLightEntryTest {

    @Test
    public void testConstructor() {

        final SelectedTrafficLightEntry entry = new SelectedTrafficLightEntry("foo");
        assertEquals("foo", entry.getSelectedTrafficLightControllerId());

        final SelectedTrafficLightEntry anotherEntry = new SelectedTrafficLightEntry("bar");
        assertEquals("bar", anotherEntry.getSelectedTrafficLightControllerId());
    }

    @Test
    public void testEquals() {
        final SelectedTrafficLightEntry entry = new SelectedTrafficLightEntry("foo");
        final SelectedTrafficLightEntry equal = new SelectedTrafficLightEntry("foo");
        assertEquals(entry, equal);
        assertEquals(entry.hashCode(), equal.hashCode());

        final SelectedTrafficLightEntry notEqual = new SelectedTrafficLightEntry("bar");
        assertFalse(entry.equals(notEqual));
        assertNotEquals(entry.hashCode(), notEqual.hashCode());
    }

}
