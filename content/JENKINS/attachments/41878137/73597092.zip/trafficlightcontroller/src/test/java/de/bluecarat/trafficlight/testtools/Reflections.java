/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.testtools;

import java.lang.reflect.Constructor;

import org.kohsuke.stapler.DataBoundConstructor;

/**
 * Various reflection operations.
 */
public final class Reflections {

    private Reflections() {
    }

    /**
     * Test if the given constrcutors contain a {@link DataBoundConstructor}.
     *
     * @param constructors
     *            to check
     * @return true if a {@link DataBoundConstructor} was found
     */
    public static boolean hasDataboundConstructor(final Constructor< ? >... constructors) {
        for (final Constructor< ? > constructor : constructors) {
            if (constructor.getAnnotation(DataBoundConstructor.class) != null) {
                return true;
            }
        }
        return false;
    }
}
