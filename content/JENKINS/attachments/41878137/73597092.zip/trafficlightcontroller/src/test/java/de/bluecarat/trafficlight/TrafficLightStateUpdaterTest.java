/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight;

import static java.util.Arrays.asList;
import static java.util.Collections.EMPTY_LIST;
import static java.util.Collections.EMPTY_SET;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import hudson.model.FreeStyleBuild;
import hudson.model.Result;
import hudson.model.TopLevelItem;
import hudson.model.FreeStyleProject;
import hudson.model.Run;

import java.util.HashSet;
import java.util.Set;

import jenkins.model.Jenkins;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import de.bluecarat.trafficlight.configuration.LinkedTrafficLights;
import de.bluecarat.trafficlight.configuration.TrafficLightId;
import de.bluecarat.trafficlight.configuration.TrafficLightRegistry;
import de.bluecarat.trafficlight.controller.TrafficLightController;
import de.bluecarat.trafficlight.services.JobCollector;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ NullSafeJenkins.class, JobCollector.class, TrafficLightRegistry.class, TrafficLightId.class,
        LinkedTrafficLights.class })
public class TrafficLightStateUpdaterTest {

    @SuppressWarnings("rawtypes")
    @Mock
    private Run run;

    @Mock
    private TrafficLightController controller1;

    @Mock
    private TrafficLightController controller2;

    @Mock
    private TrafficLightRegistry trafficLightRegistry;

    @Mock
    private JobCollector collector;

    @Mock
    private Jenkins jenkins;

    @Mock
    private TrafficLightId id1;

    @Mock
    private TrafficLightId id2;

    @Mock
    private LinkedTrafficLights lights;

    @Mock
    private FreeStyleProject project1;

    @Mock
    private FreeStyleProject project2;

    @Mock
    private TopLevelItem nonJob;

    @Mock
    private FreeStyleBuild lastBuild;

    @Mock
    private FreeStyleBuild lastCompletedBuild;

    private TrafficLightStateUpdater stateUpdater;

    @Before
    public void prepare() throws Exception {
        stateUpdater = new TrafficLightStateUpdater();
        stateUpdater.setCollector(collector);
        stateUpdater.setTrafficLightRegistry(trafficLightRegistry);

        mockForLogging();
        mockNullSafeJenkinsToReturnJenkinsMock();
    }

    private void mockNullSafeJenkinsToReturnJenkinsMock() {
        mockStatic(NullSafeJenkins.class);
        when(NullSafeJenkins.getInstance()).thenReturn(jenkins);
    }

    @Test
    public void shouldOnlyConsiderBuildingJobsWithTrafficLightOnFinishedBuild() throws Exception {
        when(collector.collectAllJobsForTrafficLightOf(run)).thenReturn(asSet("job1", "job2"));
        stateUpdater.onFinalized(run);
        verifyIfOnlyBuildingJobsAreConsidiered(2, "job1", "job2");
    }

    private void verifyIfOnlyBuildingJobsAreConsidiered(final int times, final String... jobs) {
        for (String job : jobs) {
            verify(jenkins, times(times)).getItem(job);
        }
    }

    @SuppressWarnings("unchecked")
    @Test
    public void shouldNotChangeTrafficLightsIfThereAreNoProjectsWithTrafficLightsOnFinishedBuild() throws Exception {
        when(collector.collectAllJobsForTrafficLightOf(run)).thenReturn(EMPTY_SET);
        stateUpdater.onFinalized(run);
        verify(trafficLightRegistry, never()).getControllerById(anyString());
    }

    @Test
    public void shouldChangeTrafficLightWhenNoJobIsBuildingOnFinishedBuild() throws Exception {
        mockJenkinsToHaveTwoProjects(project1, "project 1", false, project2, "project 2", false);
        mockJenkinsToHaveTwoController("traffic light id 1", "traffic light id 2");
        mockCurrentRunWithTwoTrafficLights(project1, "traffic light id 1", "traffic light id 2");
        mockLastBuildStatusFor(project1, lastBuild, Result.SUCCESS);
        mockLastBuildStatusFor(project2, lastBuild, Result.SUCCESS);

        stateUpdater.onFinalized(run);

        verify(controller1).buildFinished(Result.SUCCESS);
        verify(controller2).buildFinished(Result.SUCCESS);
    }

    @Test
    public void shouldNotChangeTrafficLightWhenJobIsBuildingOnFinishedBuild() throws Exception {
        mockJenkinsToHaveTwoProjects(project1, "project 1", false, project2, "project 2", true);
        mockJenkinsToHaveTwoController("traffic light id 1", "traffic light id 2");
        mockCurrentRunWithTwoTrafficLights(project1, "traffic light id 1", "traffic light id 2");
        mockLastBuildStatusFor(project1, lastBuild, Result.SUCCESS);
        mockLastBuildStatusFor(project2, lastBuild, Result.SUCCESS);

        stateUpdater.onFinalized(run);

        verify(controller1, never()).buildFinished(any(Result.class));
        verify(controller2, never()).buildFinished(any(Result.class));
    }

    @Test
    public void shouldUseTrafficLightControllerForChangingTrafficLightOnFinishedBuild() throws Exception {
        mockJenkinsToHaveProject(project1, "project", false);
        mockJenkinsToHaveController(controller1, "traffic light id");
        mockCurrentRunWithTrafficLight(project1, "traffic light id");
        mockLastBuildStatusFor(project1, lastBuild, Result.SUCCESS);

        stateUpdater.onFinalized(run);

        verify(controller1).buildFinished(any(Result.class));
    }

    @Test
    public void shouldNotChangeTrafficLightWhenTrafficLightControllersIsEmptyOnFinishedBuild() throws Exception {
        mockJenkinsToHaveProject(project1, "project", false);
        mockCurrentRunWithoutTrafficLights(project1);

        stateUpdater.onFinalized(run);

        verify(controller1, never()).buildFinished(any(Result.class));
    }

    @Test
    public void shouldNotSetTrafficLightToGreenWhenAnotherObservedJobFailed() throws Exception {
        mockJenkinsToHaveTwoProjects(project1, "project 1", false, project2, "project 2", false);
        mockJenkinsToHaveTwoController("traffic light id 1", "traffic light id 2");
        mockCurrentRunWithTwoTrafficLights(project1, "traffic light id 1", "traffic light id 2");
        mockLastBuildStatusFor(project1, lastBuild, Result.SUCCESS);
        mockLastBuildStatusFor(project2, lastBuild, Result.FAILURE);

        stateUpdater.onFinalized(run);

        verify(controller1).buildFinished(Result.FAILURE);
        verify(controller2).buildFinished(Result.FAILURE);
    }

    @Test
    public void shouldOnlyConsiderNotBuildingJobsWithTrafficLightOnStartedBuildOld() throws Exception {
        when(collector.collectAllJobsForTrafficLightOf(run)).thenReturn(asSet("job1", "job2"));
        stateUpdater.onStarted(run, null);
        verifyIfOnlyBuildingJobsAreConsidiered(1, "job1", "job2");
    }

    @SuppressWarnings("unchecked")
    @Test
    public void shouldNotChangeTrafficLightsIfThereAreNoProjectsWithTrafficLightsOnStartedBuild() throws Exception {
        when(collector.collectAllJobsForTrafficLightOf(run)).thenReturn(EMPTY_SET);
        stateUpdater.onStarted(run, null);
        verify(trafficLightRegistry, never()).getControllerById(anyString());
    }

    @Test
    public void shouldChangeTrafficLightWhenJobIsBuildingOnStartedBuild() throws Exception {
        mockJenkinsToHaveTwoProjects(project1, "project 1", true, project2, "project 2", false);
        mockJenkinsToHaveTwoController("traffic light id 1", "traffic light id 2");
        mockCurrentRunWithTwoTrafficLights(project1, "traffic light id 1", "traffic light id 2");

        stateUpdater.onStarted(run, null);

        verify(controller1).buildStarted();
        verify(controller2).buildStarted();
    }

    @Test
    public void shouldNotChangeTrafficLightWhenNoJobIsBuildingOnStartedBuild() throws Exception {
        mockJenkinsToHaveTwoProjects(project1, "project 1", false, project2, "project 2", false);
        mockJenkinsToHaveTwoController("traffic light id 1", "traffic light id 2");
        mockCurrentRunWithTwoTrafficLights(project1, "traffic light id 1", "traffic light id 2");

        stateUpdater.onStarted(run, null);

        verify(controller1, never()).buildStarted();
        verify(controller2, never()).buildStarted();
    }

    @Test
    public void shouldUseTrafficLightControllerChangingTrafficLightOnStartedBuild() throws Exception {
        mockJenkinsToHaveProject(project1, "project", true);
        mockJenkinsToHaveController(controller1, "traffic light id");
        mockCurrentRunWithTrafficLight(project1, "traffic light id");
        mockLastBuildStatusFor(project1, lastBuild, Result.SUCCESS);

        stateUpdater.onStarted(run, null);

        verify(controller1).buildStarted();
    }

    @Test
    public void shouldNotChangeTrafficLightWhenTrafficLightControllersIsEmptyOnStartedBuild() throws Exception {
        mockJenkinsToHaveProject(project1, "project", true);
        mockCurrentRunWithoutTrafficLights(project1);

        stateUpdater.onStarted(run, null);

        verify(controller1, never()).buildStarted();
    }

    @Test
    public void shouldUseTrafficLightRegistryFromSetter() throws Exception {
        mockJenkinsToHaveProject(project1, "project", true);
        mockJenkinsToHaveController(controller1, "traffic light id");
        mockCurrentRunWithTrafficLight(project1, "traffic light id");

        stateUpdater.onStarted(run, null);

        verify(trafficLightRegistry).getControllerById("traffic light id");
    }

    @Test
    public void shouldInstantiateWithDefaultConstructor() throws Exception {
        new TrafficLightStateUpdater();
        assertTrue("Instantiation failed", true);
    }

    private Set<String> asSet(final String... strings) {
        return new HashSet<String>(asList(strings));
    }

    private void mockForLogging() {
        when(run.getParent()).thenReturn(project1);
    }

    private void mockJenkinsToHaveProject(final FreeStyleProject project, final String projectName,
            final boolean projectIsBuilding) {
        when(collector.collectAllJobsForTrafficLightOf(run)).thenReturn(asSet(projectName));
        when(jenkins.getItem(projectName)).thenReturn(project);
        when(project.isBuilding()).thenReturn(projectIsBuilding);
    }

    private void mockJenkinsToHaveTwoProjects(final FreeStyleProject project1, final String project1Name,
            final boolean project1building, final FreeStyleProject project2, final String project2Name,
            final boolean project2building) {
        when(collector.collectAllJobsForTrafficLightOf(run)).thenReturn(asSet(project1Name, project2Name));
        when(jenkins.getItem(project1Name)).thenReturn(project1);
        when(project1.isBuilding()).thenReturn(project1building);
        when(jenkins.getItem(project2Name)).thenReturn(project2);
        when(project2.isBuilding()).thenReturn(project2building);
    }

    private void mockLastBuildStatusFor(final FreeStyleProject project, final FreeStyleBuild build,
            final Result buildResult) {
        when(project.getLastBuild()).thenReturn(build);
        when(build.getResult()).thenReturn(buildResult);
    }

    private void mockLastCompletedBuildStatusFor(final FreeStyleProject project, final FreeStyleBuild build,
            final Result buildResult) {
        when(project.getLastCompletedBuild()).thenReturn(build);
        when(build.getResult()).thenReturn(buildResult);
    }

    private void mockJenkinsToHaveController(final TrafficLightController controller, final String id) {
        when(trafficLightRegistry.getControllerById(id)).thenReturn(controller);
    }

    private void mockJenkinsToHaveTwoController(final String id1, final String id2) {
        mockJenkinsToHaveController(controller1, id1);
        mockJenkinsToHaveController(controller2, id2);
    }

    private void mockCurrentRunWithTrafficLight(final FreeStyleProject builtProject, final String trafficLightId) {
        when(run.getParent()).thenReturn(builtProject);
        when(builtProject.getProperty(LinkedTrafficLights.class)).thenReturn(lights);
        when(lights.getTrafficLights()).thenReturn(asList(id1));
        when(id1.getId()).thenReturn(trafficLightId);
    }

    @SuppressWarnings("unchecked")
    private void mockCurrentRunWithoutTrafficLights(final FreeStyleProject builtProject) {
        when(run.getParent()).thenReturn(builtProject);
        when(builtProject.getProperty(LinkedTrafficLights.class)).thenReturn(lights);
        when(lights.getTrafficLights()).thenReturn(EMPTY_LIST);
    }

    private void mockCurrentRunWithTwoTrafficLights(final FreeStyleProject builtProject, final String trafficLight1Id,
            final String trafficLight2Id) {
        when(run.getParent()).thenReturn(builtProject);
        when(builtProject.getProperty(LinkedTrafficLights.class)).thenReturn(lights);
        when(lights.getTrafficLights()).thenReturn(asList(id1, id2));
        when(id1.getId()).thenReturn(trafficLight1Id);
        when(id2.getId()).thenReturn(trafficLight2Id);
    }

    @Test
    public void shouldSetStatusOfJobToSuccessIfOtherJobAbortedButWasLastCompletedWithSuccess() throws Exception {
        mockJenkinsToHaveTwoProjects(project1, "project 1", false, project2, "project 2", false);
        mockJenkinsToHaveTwoController("traffic light id 1", "traffic light id 2");
        mockCurrentRunWithTwoTrafficLights(project1, "traffic light id 1", "traffic light id 2");
        mockLastBuildStatusFor(project1, lastBuild, Result.SUCCESS);
        mockLastBuildStatusFor(project2, lastBuild, Result.ABORTED);
        mockLastCompletedBuildStatusFor(project2, lastCompletedBuild, Result.SUCCESS);

        stateUpdater.onFinalized(run);

        verify(controller1).buildFinished(Result.SUCCESS);
        verify(controller2).buildFinished(Result.SUCCESS);
    }

    @Test
    public void shouldSetStatusOfJobToFailedIfOtherJobAbortedAndWasLastCompletedWithFailure() throws Exception {
        mockJenkinsToHaveTwoProjects(project1, "project 1", false, project2, "project 2", false);
        mockJenkinsToHaveTwoController("traffic light id 1", "traffic light id 2");
        mockCurrentRunWithTwoTrafficLights(project1, "traffic light id 1", "traffic light id 2");
        mockLastBuildStatusFor(project1, lastBuild, Result.SUCCESS);
        mockLastBuildStatusFor(project2, lastBuild, Result.ABORTED);
        mockLastCompletedBuildStatusFor(project2, lastCompletedBuild, Result.FAILURE);

        stateUpdater.onFinalized(run);

        verify(controller1).buildFinished(Result.FAILURE);
        verify(controller2).buildFinished(Result.FAILURE);
    }

    @Test
    public void shouldSetStatusOfJobToSuccessIfThereIsNoLastBuild() throws Exception {
        mockJenkinsToHaveProject(project1, "project", false);
        mockJenkinsToHaveController(controller1, "traffic light id");
        mockCurrentRunWithTrafficLight(project1, "traffic light id");
        when(project1.getLastBuild()).thenReturn(null);

        stateUpdater.onFinalized(run);

        verify(controller1).buildFinished(Result.SUCCESS);
    }

    @Test
    public void shouldIgnoreNonJobItems() throws Exception {
        when(collector.collectAllJobsForTrafficLightOf(run)).thenReturn(asSet("project"));
        when(jenkins.getItem("project")).thenReturn(nonJob);

        stateUpdater.onFinalized(run);

        verify(trafficLightRegistry, never()).getControllerById(anyString());
    }

    @Test
    public void shouldDoNothingWhenTrafficLightRegistryIsNotSet() throws Exception {
        mockJenkinsToHaveProject(project1, "project", true);
        stateUpdater.setTrafficLightRegistry(null);

        stateUpdater.onStarted(run, null);

        verify(trafficLightRegistry, never()).getControllerById(anyString());
    }
}
