/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.connectionhandler;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.getRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.http.Fault.MALFORMED_RESPONSE_CHUNK;
import static com.github.tomakehurst.wiremock.http.Fault.RANDOM_DATA_THEN_CLOSE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.springframework.util.Assert.isInstanceOf;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.net.URI;

import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.junit.WireMockRule;

import de.bluecarat.trafficlight.connectionhandler.exception.HandlerException;

public class HttpGetHandlerTest {

    private URI mockUri = null;

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(0);

    private HttpGetHandler handler = null;

    @Before
    public void prepare() throws Exception {
        mockUri = URI.create("http://localhost:" + wireMockRule.port());
        handler = new HttpGetHandler(200);
    }

    @Test
    public void shouldUseURIFromParameter() throws Exception {
        stubFor(get(urlEqualTo("/test/")).willReturn(aResponse()));
        handler.handle(URI.create(mockUri.toString() + "/test/"));
        WireMock.verify(getRequestedFor(urlEqualTo("/test/")));
    }

    @Test
    public void shouldThrowHandlerExceptionIfStatusCodeIsNotOK() throws Exception {
        stubFor(get(urlEqualTo("/")).willReturn(aResponse().withStatus(HttpStatus.SC_BAD_REQUEST)));

        try {
            handler.handle(mockUri);
            fail();
        } catch (HandlerException e) {
            isInstanceOf(HandlerException.class, e);
            assertEquals("Unexpected response, aborting (localhost). Status code: 400", e.getMessage());
        }

    }

    @Test
    public void shouldThrowHandlerExceptionIfAnHttpErrorOccured() throws Exception {
        stubFor(get(urlEqualTo("/")).willReturn(aResponse().withFault(RANDOM_DATA_THEN_CLOSE)));

        try {
            handler.handle(mockUri);
            fail();
        } catch (HandlerException e) {
            isInstanceOf(HandlerException.class, e);
            isInstanceOf(HttpException.class, e.getCause());
            assertEquals("Unexpected Error, aborting (localhost).", e.getMessage());
        }

    }

    @Test
    public void shouldThrowHandlerExceptionOnConnectionTimeout() {
        stubFor(get(urlEqualTo("/")).willReturn(aResponse().withFixedDelay(250)));
        try {
            handler.handle(mockUri);
            fail();
        } catch (HandlerException e) {
            isInstanceOf(HandlerException.class, e);
            isInstanceOf(SocketTimeoutException.class, e.getCause());
            assertEquals("Unexpected Error, aborting (localhost).", e.getMessage());
        }
    }

    @Test
    public void shouldThrowHandlerExceptionWhenUnauthorized() {
        stubFor(get(urlEqualTo("/")).willReturn(aResponse().withStatus(HttpStatus.SC_UNAUTHORIZED)));
        try {
            handler.handle(mockUri);
            fail();
        } catch (HandlerException e) {
            isInstanceOf(HandlerException.class, e);
            assertEquals("Unauthorized. Check your credentials.", e.getMessage());
        }
    }

    @Test
    public void shouldReturnStringFromResponseBody() throws Exception {
        stubFor(get(urlEqualTo("/")).willReturn(aResponse().withBody("some string")));

        final String result = handler.handle(mockUri);

        assertEquals("some string", result);
    }

    @Test
    public void shouldThrowHandlerExceptionWhenBodyCouldNotBeReadFromResponse() {
        stubFor(get(urlEqualTo("/")).willReturn(aResponse().withFault(MALFORMED_RESPONSE_CHUNK)));
        try {
            handler.handle(mockUri);
            fail();
        } catch (HandlerException e) {
            isInstanceOf(HandlerException.class, e);
            isInstanceOf(IOException.class, e.getCause());
            assertEquals("Could not parse response, aborting (localhost).", e.getMessage());
        }
    }
}
