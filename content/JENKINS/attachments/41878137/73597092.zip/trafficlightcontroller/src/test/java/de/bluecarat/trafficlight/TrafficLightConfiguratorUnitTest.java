/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight;

import static java.util.Arrays.asList;
import static java.util.Collections.EMPTY_LIST;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import hudson.ExtensionList;
import hudson.model.listeners.SaveableListener;
import hudson.util.Secret;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import jenkins.model.Jenkins;
import net.sf.json.JSONObject;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.kohsuke.stapler.StaplerRequest;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import de.bluecarat.trafficlight.configuration.TrafficLightId;
import de.bluecarat.trafficlight.configuration.TrafficLightId.TrafficLightIdDescriptor;
import de.bluecarat.trafficlight.configuration.TrafficLightRegistry;
import de.bluecarat.trafficlight.powerstrips.InfraTecPowerStrip;
import de.bluecarat.trafficlight.powerstrips.PowerStripConfig;
import de.bluecarat.trafficlight.powerstrips.PowerStripList;
import de.bluecarat.trafficlight.services.JobConfigurationJanitor;
import de.bluecarat.trafficlight.services.TrafficLightRegistryConfigurator;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ JobConfigurationJanitor.class, Jenkins.class, Secret.class, JSONObject.class, SaveableListener.class,
        TrafficLightRegistryConfigurator.class, PowerStripList.class })
public class TrafficLightConfiguratorUnitTest {

    private TrafficLightConfigurator configurator = null;

    @Rule
    public TemporaryFolder file = new TemporaryFolder();

    @Mock
    private Jenkins jenkins;

    @Mock
    private Secret secret;

    @Mock
    private StaplerRequest request;

    @Mock
    private JSONObject json;

    @Mock
    private ExtensionList<TrafficLightStateUpdater> extensionListStateUpdater;

    @Mock
    private Iterator<TrafficLightStateUpdater> iteratorStateUpdater;

    @Mock
    private ExtensionList<TrafficLightIdDescriptor> extensionListIdDescriptor;

    @Mock
    private Iterator<TrafficLightIdDescriptor> iteratorIdDescriptor;

    @Mock
    private JobConfigurationJanitor janitor;

    @Mock
    private TrafficLightRegistryConfigurator registryConfigurator;

    @Mock
    private PowerStripList powerStrips;

    @Before
    public void prepare() throws Exception {
        mockJenkinsWithEmptyConfiguration();
        configurator = new TrafficLightConfigurator();
        configurator.setJobConfigurationJanitor(janitor);
        configurator.setRegistryConfigurator(registryConfigurator);
    }

    private void mockJenkinsWithEmptyConfiguration() throws IOException {
        mockStatic(Jenkins.class);
        when(Jenkins.getInstance()).thenReturn(jenkins);
        file.newFile(TrafficLightConfigurator.class.getName() + ".xml");
        when(jenkins.getRootDir()).thenReturn(file.getRoot());
    }

    private void mockJenkinsToHaveNoListener() {
        when(jenkins.getExtensionList(TrafficLightStateUpdater.class)).thenReturn(extensionListStateUpdater);
        when(extensionListStateUpdater.iterator()).thenReturn(iteratorStateUpdater);
        when(iteratorStateUpdater.hasNext()).thenReturn(false);

        when(jenkins.getExtensionList(TrafficLightIdDescriptor.class)).thenReturn(extensionListIdDescriptor);
        when(extensionListIdDescriptor.iterator()).thenReturn(iteratorIdDescriptor);
        when(iteratorIdDescriptor.hasNext()).thenReturn(false);

        mockStatic(SaveableListener.class);
    }

    private void mockJenkinsToHavePowerStrip(final String id) {
        mockStatic(Secret.class);
        when(Secret.toString(secret)).thenReturn("password");

        final InfraTecPowerStrip infaTecConfig = new InfraTecPowerStrip(id, "name", "address", "80", "username", secret);
        final List<PowerStripConfig> powerStrips = asList(new PowerStripConfig(infaTecConfig));
        when(request.bindJSON(PowerStripList.class, json)).thenReturn(new PowerStripList(powerStrips));
    }

    @Test
    public void shouldCleanUpOrphanTrafficLightIdsInJobConfigurations() throws Exception {
        mockJenkinsToHavePowerStrip("34a7c220-245f-11e4-8c21-0800200c9a66");
        mockJenkinsToHaveNoListener();

        configurator.configure(request, json);

        verify(janitor).removeInvalidTrafficLightsFromProjects(
                asList(new TrafficLightId("34a7c220-245f-11e4-8c21-0800200c9a66")));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void shouldUseRegistryConfigurator() throws Exception {
        configurator.setRegistryConfigurator(registryConfigurator);
        configurator.setPowerStripList(powerStrips);
        when(powerStrips.getPowerStrips()).thenReturn(EMPTY_LIST);

        configurator.initializeTrafficLightRegistry();

        verify(registryConfigurator).initializeTrafficLightRegistry(any(TrafficLightRegistry.class),
                any(PowerStripList.class));
    }
}
