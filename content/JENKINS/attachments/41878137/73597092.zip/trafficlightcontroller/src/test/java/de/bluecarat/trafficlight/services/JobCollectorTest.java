/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.services;

import static java.util.Arrays.asList;
import static java.util.Collections.EMPTY_LIST;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import hudson.model.Item;
import hudson.model.TopLevelItem;
import hudson.model.Job;
import hudson.model.Run;

import java.util.List;
import java.util.Set;

import jenkins.model.Jenkins;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import de.bluecarat.trafficlight.NullSafeJenkins;
import de.bluecarat.trafficlight.configuration.LinkedTrafficLights;
import de.bluecarat.trafficlight.configuration.SelectedTrafficLightEntry;
import de.bluecarat.trafficlight.configuration.TrafficLightId;
import de.bluecarat.trafficlight.testtools.JobListAnswer;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ NullSafeJenkins.class, LinkedTrafficLights.class, SelectedTrafficLightEntry.class,
    TrafficLightId.class })
public class JobCollectorTest {

    @Mock
    private Jenkins jenkins;

    @Mock
    private TopLevelItem topItem1;

    @Mock
    private TopLevelItem topItem2;

    @Mock
    private Item item1;

    @Mock
    private Job< ? , ? > jobSource;

    @Mock
    private Job< ? , ? > job1;

    @Mock
    private Job< ? , ? > job2;

    @Mock
    private Job< ? , ? > job3;

    @Mock
    private SelectedTrafficLightEntry entry;

    @Mock
    private LinkedTrafficLights linkedLightsSource;

    @Mock
    private LinkedTrafficLights linkedLights1;

    @Mock
    private LinkedTrafficLights linkedLights2;

    @Mock
    private LinkedTrafficLights linkedLights3;

    @Mock
    private TrafficLightId idSource;

    @Mock
    private TrafficLightId id1;

    @Mock
    private TrafficLightId id2;

    @Mock
    private TrafficLightId id3;

    private JobCollector collector = null;

    @SuppressWarnings("rawtypes")
    @Mock
    private Run run;

    @Before
    public void prepare() throws Exception {
        mockJenkins();
        collector = new JobCollector();
    }

    private void mockJenkins() {
        mockStatic(NullSafeJenkins.class);
        when(NullSafeJenkins.getInstance()).thenReturn(jenkins);
    }

    @Test
    public void shouldGetAllItemsFromJenkinsWhenLookingForSpecificJob() throws Exception {
        collector.collectAllVisualizedJobs(entry);
        verify(jenkins).getAllItems();
    }

    @SuppressWarnings("unchecked")
    @Test
    public void shouldHaveEmptyResultWhenJenkinsHasNoJobs() throws Exception {
        when(jenkins.getAllItems()).thenReturn(EMPTY_LIST);
        assertTrue(collector.collectAllVisualizedJobs(entry).isEmpty());
    }

    @Test
    public void shouldOnlyConsiderTopLevelItemsAsValidJobs() throws Exception {
        mockJenkinsToHaveItems(topItem1, item1);

        mockJenkinsToHaveOneJobWithLinkedLights(topItem1, job1, "job1", linkedLights1);
        mockJenkinsToHaveOneJobWithLinkedLights(item1, job2, "job2", linkedLights2);

        mockIdForLinkedLight(linkedLights1, id1, "id", entry);
        mockIdForJob(id1, "id");
        mockIdForLinkedLight(linkedLights2, id2, "id", entry);
        mockIdForJob(id2, "id");

        final Set<String> result = collector.collectAllVisualizedJobs(entry);

        verifyNoUsage(linkedLights2, id2);
        assertTrue(result.contains("job1"));
        assertFalse(result.contains("job2"));
    }

    @Test
    public void shouldFilterAllJobsForLinkedTrafficLight() throws Exception {
        mockJenkinsToHaveItems(topItem1, topItem2);

        mockJenkinsToHaveOneJobWithLinkedLights(topItem1, job1, "job1", linkedLights1);
        mockJenkinsToHaveOneJobWithLinkedLights(topItem2, job2, "job2", linkedLights2);

        mockIdForLinkedLight(linkedLights1, id1, "id", entry);
        mockIdForJob(id1, "id");
        mockIdForLinkedLight(linkedLights2, id2, "id", entry);
        mockIdForJob(id2, "false_id");

        final Set<String> result = collector.collectAllVisualizedJobs(entry);

        assertTrue(result.contains("job1"));
        assertFalse(result.contains("job2"));
    }

    @Test
    public void shouldUseIdOfSelectedTrafficLightForFiltering() throws Exception {
        mockJenkinsToHaveItems(topItem1);

        mockJenkinsToHaveOneJobWithLinkedLights(topItem1, job1, "job1", linkedLights1);
        mockIdForLinkedLight(linkedLights1, id1, "id", entry);
        mockIdForJob(id1, "id");

        collector.collectAllVisualizedJobs(entry);

        verify(entry).getSelectedTrafficLightControllerId();
    }

    @Test
    public void shouldFilterWhenAtLeastOneTrafficLightInJobIsLinked() throws Exception {
        mockJenkinsToHaveItems(topItem1);

        mockJobWithDisplayNameAndLinkedLights(job1, "job1", linkedLights1);
        mockJobWithDisplayNameAndLinkedLights(job2, "job2", linkedLights2);
        when(topItem1.getAllJobs()).thenAnswer(new JobListAnswer(job1, job2));

        mockIdForLinkedLight(linkedLights1, id1, "id", entry);
        mockIdForJob(id1, "other id");

        mockIdForLinkedLight(linkedLights2, id2, "id", entry);
        mockIdForJob(id2, "id");

        final Set<String> result = collector.collectAllVisualizedJobs(entry);

        assertTrue(result.contains("job2"));
        assertFalse(result.contains("job1"));
    }

    @Test
    public void shouldNotChooseJobThatHasNoLinkageToTrafficLight() throws Exception {
        mockJenkinsToHaveItems(topItem1);

        mockJobWithDisplayNameAndLinkedLights(job1, "job1", linkedLights1);
        mockJobWithDisplayNameAndLinkedLights(job2, "job2", linkedLights2);
        when(topItem1.getAllJobs()).thenAnswer(new JobListAnswer(job1, job2));

        mockIdForLinkedLight(linkedLights1, id1, "id", entry);
        mockIdForJob(id1, "other id");

        mockIdForLinkedLight(linkedLights2, id2, "id", entry);
        mockIdForJob(id2, "other id");

        final Set<String> result = collector.collectAllVisualizedJobs(entry);

        assertFalse(result.contains("job1"));
        assertFalse(result.contains("job2"));
    }

    @Test
    public void shouldUseDisplayNameOfJobForDisplayingJob() throws Exception {
        mockJenkinsToHaveItems(topItem1);

        mockJenkinsToHaveOneJobWithLinkedLights(topItem1, job1, "job1", linkedLights1);
        mockIdForLinkedLight(linkedLights1, id1, "id", entry);
        mockIdForJob(id1, "id");

        collector.collectAllVisualizedJobs(entry);

        verify(job1).getDisplayName();
    }

    @Test
    public void shouldGetLinkedTrafficLightPropertyFromJobForIdRetrieval() throws Exception {
        mockJenkinsToHaveItems(topItem1);

        mockJenkinsToHaveOneJobWithLinkedLights(topItem1, job1, "job1", linkedLights1);
        mockIdForLinkedLight(linkedLights1, id1, "id", entry);
        mockIdForJob(id1, "id");

        collector.collectAllVisualizedJobs(entry);

        verify(job1).getProperty(LinkedTrafficLights.class);
    }

    @Test
    public void shouldHandleMissingPropertyGracefully() throws Exception {
        mockJenkinsToHaveItems(topItem1, topItem2);
        mockJenkinsToHaveOneJobWithLinkedLights(topItem1, job1, "job1", null);

        assertTrue(collector.collectAllVisualizedJobs(entry).isEmpty());
    }

    @Test
    public void shouldConsiderAllLinkedTrafficLightsOfJobWhenLookingForMatch() throws Exception {
        mockJenkinsToHaveItems(topItem1);

        mockJenkinsToHaveOneJobWithLinkedLights(topItem1, job1, "job1", linkedLights1);
        mockIdsForLinkedLight(linkedLights1, asList(id1, id2), "id", entry);
        mockIdForJob(id1, "id");
        mockIdForJob(id2, "other id");

        collector.collectAllVisualizedJobs(entry);

        final Set<String> result = collector.collectAllVisualizedJobs(entry);

        assertTrue(result.contains("job1"));
    }

    private void mockJenkinsToHaveItems(final Item... items) {
        when(jenkins.getAllItems()).thenReturn(asList(items));
    }

    private void verifyNoUsage(final LinkedTrafficLights linkedLights, final TrafficLightId id) {
        verify(linkedLights, never()).getTrafficLights();
        verify(id, never()).getId();
    }

    private void mockJenkinsToHaveOneJobWithLinkedLights(final Item item, final Job< ? , ? > job,
            final String jobDisplayName, final LinkedTrafficLights linkedLights) {
        when(topItem1.getAllJobs()).thenAnswer(new JobListAnswer(job1));
        mockJobWithDisplayNameAndLinkedLights(job, jobDisplayName, linkedLights);
    }

    private void mockJobWithDisplayNameAndLinkedLights(final Job< ? , ? > job, final String jobDisplayName,
            final LinkedTrafficLights linkedLights) {
        when(job.getProperty(LinkedTrafficLights.class)).thenReturn(linkedLights);
        when(job.getDisplayName()).thenReturn(jobDisplayName);
    }

    private void mockIdForLinkedLight(final LinkedTrafficLights linkedLights, final TrafficLightId id,
            final String trafficLightId, final SelectedTrafficLightEntry entry) {
        mockIdsForLinkedLight(linkedLights, asList(id), trafficLightId, entry);
    }

    private void mockIdsForLinkedLight(final LinkedTrafficLights linkedLights, final List<TrafficLightId> ids,
            final String trafficLightId, final SelectedTrafficLightEntry entry) {
        when(linkedLights.getTrafficLights()).thenReturn(ids);
        when(entry.getSelectedTrafficLightControllerId()).thenReturn(trafficLightId);
    }

    private void mockIdForJob(final TrafficLightId id, final String jobId) {
        when(id.getId()).thenReturn(jobId);
    }

    @Test
    public void shouldGetLinkedLightsPropertyFromRun() throws Exception {
        when(run.getParent()).thenReturn(jobSource);
        collector.collectAllJobsForTrafficLightOf(run);
        verify(jobSource).getProperty(LinkedTrafficLights.class);
    }

    @Test
    public void shouldHandleMissingPropertyOfRunGracefully() throws Exception {
        when(run.getParent()).thenReturn(jobSource);
        when(jobSource.getProperty(LinkedTrafficLights.class)).thenReturn(null);
        assertTrue(collector.collectAllJobsForTrafficLightOf(run).isEmpty());
    }

    @Test
    public void shouldUseLinkedLightsFromProperty() throws Exception {
        mockJobToHaveLinkedLights(jobSource, linkedLightsSource, new TrafficLightId[] {});
        collector.collectAllJobsForTrafficLightOf(run);
        verify(linkedLightsSource).getTrafficLights();
    }

    private void mockJobToHaveLinkedLights(final Job< ? , ? > job, final LinkedTrafficLights linkedLights,
            final TrafficLightId... ids) {
        when(run.getParent()).thenReturn(job);
        when(job.getProperty(LinkedTrafficLights.class)).thenReturn(linkedLights);
        when(linkedLights.getTrafficLights()).thenReturn(asList(ids));
    }

    @Test
    public void shouldUseDisplayNameFromJob() throws Exception {
        mockJobToHaveLinkedLights(jobSource, linkedLightsSource, idSource);
        when(jobSource.getDisplayName()).thenReturn("Display Name");

        final Set<String> result = collector.collectAllJobsForTrafficLightOf(run);

        assertTrue(result.contains("Display Name"));
    }

    @Test
    public void shouldGetTwoLinkedJobsForTrafficLight() throws Exception {
        mockJobToHaveLinkedLights(jobSource, linkedLightsSource, idSource);
        when(jobSource.getDisplayName()).thenReturn("job source");
        when(idSource.getId()).thenReturn("id");

        mockJenkinsToHaveItems(topItem1);

        mockJobWithDisplayNameAndLinkedLights(job1, "job1 name", linkedLights1);
        mockJobWithDisplayNameAndLinkedLights(job2, "job2 name", linkedLights2);
        mockJobWithDisplayNameAndLinkedLights(job3, "job3 name", linkedLights3);
        when(topItem1.getAllJobs()).thenAnswer(new JobListAnswer(job1, job2, job3));

        mockIdForLinkedLight(linkedLights1, id1, "id", entry);
        mockIdForJob(id1, "id");

        mockIdForLinkedLight(linkedLights2, id2, "id", entry);
        mockIdForJob(id2, "other id");

        mockIdForLinkedLight(linkedLights3, id3, "id", entry);
        mockIdForJob(id3, "id");

        final Set<String> result = collector.collectAllJobsForTrafficLightOf(run);

        assertTrue(result.contains("job1 name"));
        assertFalse(result.contains("job2 name"));
        assertTrue(result.contains("job3 name"));
    }
}
