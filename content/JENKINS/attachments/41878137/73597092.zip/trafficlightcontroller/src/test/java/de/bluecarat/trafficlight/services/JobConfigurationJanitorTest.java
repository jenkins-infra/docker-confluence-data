/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.services;

import static java.util.Arrays.asList;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import hudson.model.Item;
import hudson.model.TopLevelItem;
import hudson.model.Job;

import java.io.IOException;

import jenkins.model.Jenkins;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import de.bluecarat.trafficlight.configuration.LinkedTrafficLights;
import de.bluecarat.trafficlight.configuration.TrafficLightId;
import de.bluecarat.trafficlight.testtools.JobListAnswer;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ Jenkins.class })
public class JobConfigurationJanitorTest {

    private JobConfigurationJanitor janitor = null;

    @Mock
    private Jenkins jenkins;

    @Mock
    private TopLevelItem item;

    @Mock
    private Job< ? , ? > job;

    @Captor
    private ArgumentCaptor<LinkedTrafficLights> linkedTrafficLightsCaptor;

    @Before
    public void prepare() throws Exception {
        mockJenkinsWithEmptyConfiguration();
        janitor = new JobConfigurationJanitor();
    }

    private void mockJenkinsWithEmptyConfiguration() throws IOException {
        mockStatic(Jenkins.class);
        when(Jenkins.getInstance()).thenReturn(jenkins);
    }

    @Test
    public void shouldRemovePropertyWhenControllerIsNoLongerAvailable() throws Exception {
        mockJobWithLinkTo("non-existant");

        janitor.removeInvalidTrafficLightsFromProjects(asList(new TrafficLightId("34a7c220-245f-11e4-8c21-0800200c9a66")));

        verify(job).addProperty(linkedTrafficLightsCaptor.capture());
        assertTrue(linkedTrafficLightsCaptor.getValue().getTrafficLights().isEmpty());
    }

    private void mockJobWithLinkTo(final String id) {
        when(jenkins.getAllItems()).thenReturn(asList((Item) item));
        when(item.getAllJobs()).thenAnswer(new JobListAnswer(job));
        when(job.getProperty(LinkedTrafficLights.class)).thenReturn(
                new LinkedTrafficLights(asList(new TrafficLightId(id))));
    }

    private void mockJobWithoutLinkedTrafficLightsProperty() {
        when(jenkins.getAllItems()).thenReturn(asList((Item) item));
        when(item.getAllJobs()).thenAnswer(new JobListAnswer(job));
        when(job.getProperty(LinkedTrafficLights.class)).thenReturn(null);
    }

    @Test
    public void shouldSaveJobWhenPropertiesAreAltered() throws Exception {
        mockJobWithLinkTo("non-existant");
        janitor.removeInvalidTrafficLightsFromProjects(asList(new TrafficLightId("34a7c220-245f-11e4-8c21-0800200c9a66")));
        verify(job).save();
    }

    @Test
    public void shouldNotAlterJobWhenNoPropertyIsSet() throws Exception {
        mockJobWithoutLinkedTrafficLightsProperty();
        janitor.removeInvalidTrafficLightsFromProjects(asList(new TrafficLightId("34a7c220-245f-11e4-8c21-0800200c9a66")));
        verify(job, never()).save();
    }

    @Test
    public void shouldKeepLinkWhenControllerIsStillAvailable() throws Exception {
        mockJobWithLinkTo("34a7c220-245f-11e4-8c21-0800200c9a66");

        janitor.removeInvalidTrafficLightsFromProjects(asList(new TrafficLightId("34a7c220-245f-11e4-8c21-0800200c9a66")));

        verify(job).addProperty(linkedTrafficLightsCaptor.capture());
        assertEquals(linkedTrafficLightsCaptor.getValue().getTrafficLights().get(0).getId(),
                "34a7c220-245f-11e4-8c21-0800200c9a66");
    }
}
