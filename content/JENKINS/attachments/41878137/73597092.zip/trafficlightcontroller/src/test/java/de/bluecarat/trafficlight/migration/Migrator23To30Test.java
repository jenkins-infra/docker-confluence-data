/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.migration;

import static java.util.Arrays.asList;
import static java.util.Collections.EMPTY_LIST;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import hudson.model.Item;
import hudson.model.TopLevelItem;
import hudson.model.Job;
import hudson.util.Secret;
import hudson.util.VersionNumber;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import jenkins.model.Jenkins;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import de.bluecarat.trafficlight.NullSafeJenkins;
import de.bluecarat.trafficlight.TrafficLightConfigurator;
import de.bluecarat.trafficlight.configuration.LinkedTrafficLights;
import de.bluecarat.trafficlight.configuration.TrafficLightId;
import de.bluecarat.trafficlight.powerstrips.InfraTecPowerStrip;
import de.bluecarat.trafficlight.powerstrips.NetControlPowerStrip;
import de.bluecarat.trafficlight.powerstrips.PowerStripConfig;
import de.bluecarat.trafficlight.powerstrips.PowerStripList;
import de.bluecarat.trafficlight.testtools.JobListAnswer;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ TrafficLightConfigurator.class, Secret.class, NullSafeJenkins.class, Jenkins.class, UUID.class })
public class Migrator23To30Test {

    @Mock
    TrafficLightConfigurator configurator;

    @Mock
    Secret secret;

    @Mock
    Jenkins jenkins;

    @Mock
    TopLevelItem item1;

    @Mock
    TopLevelItem item2;

    @Mock
    TopLevelItem item3;

    @Mock
    Job< ? , ? > project1;

    @Mock
    Job< ? , ? > project2;

    @Mock
    Job< ? , ? > project3;

    @Captor
    ArgumentCaptor<PowerStripList> powerStripListCaptor;

    @Captor
    ArgumentCaptor<LinkedTrafficLights> linkedTrafficLightsCaptor;

    private Migrator23To30 migrator = null;

    @Before
    public void prepare() {
        migrator = new Migrator23To30();
        mockMinimalDefaultConfiguration();
    }

    @Test
    public void shouldHandleUnknownVersion() {
        assertTrue(migrator.canHandle(new VersionNumber("0")));
    }

    @Test
    public void shouldNotHandleVersionOne() {
        assertFalse(migrator.canHandle(new VersionNumber("1")));
    }

    @Test
    public void shouldMigrateNetControlAddress() throws Exception {
        when(configurator.getNetControlAddress()).thenReturn("10.0.0.1");

        migrator.migrate(configurator);

        verify(configurator).setPowerStripList(powerStripListCaptor.capture());
        assertEquals("10.0.0.1", powerStripListCaptor.getValue().getPowerStrips().get(0).getPowerStrip().getAddress());
    }

    @Test
    public void shouldMigrateInfratecAddress() throws Exception {
        when(configurator.getInfraTechAddress()).thenReturn("10.0.0.1");

        migrator.migrate(configurator);

        verify(configurator).setPowerStripList(powerStripListCaptor.capture());
        assertEquals("10.0.0.1", powerStripListCaptor.getValue().getPowerStrips().get(0).getPowerStrip().getAddress());
    }

    @Test
    public void shouldMigrateWatchedTrafficLightForNetControl() throws Exception {
        mockJenkinsToHaveThreeProjects("Project A", "Project B", "Project C");
        when(configurator.getObservedItemNamesNetControl()).thenReturn(asList("Project A", "Project B"));

        migrator.migrate(configurator);

        assertTrue(getLinkedTrafficLightsFor("Project A").contains(getIdFromTrafficLight(NetControlPowerStrip.class)));
        assertTrue(getLinkedTrafficLightsFor("Project B").contains(getIdFromTrafficLight(NetControlPowerStrip.class)));
        verifyNotWatchingAnyTrafficLight("Project C");
    }

    @Test
    public void shouldMigrateWatchedTrafficLightForInfratec() throws Exception {
        mockJenkinsToHaveThreeProjects("Project A", "Project B", "Project C");
        when(configurator.getObservedItemNamesInfratech()).thenReturn(asList("Project A", "Project C"));

        migrator.migrate(configurator);

        assertTrue(getLinkedTrafficLightsFor("Project A").contains(getIdFromTrafficLight(InfraTecPowerStrip.class)));
        verifyNotWatchingAnyTrafficLight("Project B");
        assertTrue(getLinkedTrafficLightsFor("Project C").contains(getIdFromTrafficLight(InfraTecPowerStrip.class)));
    }

    @Test
    public void shouldMigrateNetControlWhenWatchingTrafficLightButAddressIsNotSet() throws Exception {
        mockJenkinsToHaveThreeProjects("Project A", "Project B", "Project C");
        when(configurator.getObservedItemNamesNetControl()).thenReturn(asList("Project A"));
        when(configurator.getNetControlAddress()).thenReturn("");

        migrator.migrate(configurator);

        assertFalse(getLinkedTrafficLightsFor("Project A").isEmpty());
        verify(configurator).setPowerStripList(powerStripListCaptor.capture());
        assertFalse(powerStripListCaptor.getValue().getPowerStrips().isEmpty());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void shouldMigrateNetControlWhenNotWatchingTrafficLightButAddressIsSet() throws Exception {
        when(configurator.getObservedItemNamesNetControl()).thenReturn(EMPTY_LIST);
        when(configurator.getNetControlAddress()).thenReturn("10.0.0.1");

        migrator.migrate(configurator);

        verify(configurator).setPowerStripList(powerStripListCaptor.capture());
        assertFalse(powerStripListCaptor.getValue().getPowerStrips().isEmpty());
    }

    @Test
    public void shouldMigrateInfratecWhenWatchingTrafficLightButAddressIsNotSet() throws Exception {
        mockJenkinsToHaveThreeProjects("Project A", "Project B", "Project C");
        when(configurator.getObservedItemNamesInfratech()).thenReturn(asList("Project B"));
        when(configurator.getInfraTechAddress()).thenReturn("");

        migrator.migrate(configurator);

        assertFalse(getLinkedTrafficLightsFor("Project B").isEmpty());
        verify(configurator).setPowerStripList(powerStripListCaptor.capture());
        assertFalse(powerStripListCaptor.getValue().getPowerStrips().isEmpty());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void shouldMigrateInfratecWhenNotWatchingTrafficLightButAddressIsSet() throws Exception {
        when(configurator.getObservedItemNamesInfratech()).thenReturn(EMPTY_LIST);
        when(configurator.getNetControlAddress()).thenReturn("10.0.0.1");

        migrator.migrate(configurator);

        verify(configurator).setPowerStripList(powerStripListCaptor.capture());
        assertFalse(powerStripListCaptor.getValue().getPowerStrips().isEmpty());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void shouldNotMigrateNetControlWhenNeitherWatchingTrafficLightNorAddressIsSet() throws Exception {
        when(configurator.getObservedItemNamesNetControl()).thenReturn(EMPTY_LIST);
        when(configurator.getNetControlAddress()).thenReturn("");

        migrator.migrate(configurator);

        verify(configurator).setPowerStripList(powerStripListCaptor.capture());
        assertTrue(powerStripListCaptor.getValue().getPowerStrips().isEmpty());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void shouldNotMigrateInfratecWhenNeitherWatchingTrafficLightNorAddressIsSet() throws Exception {
        when(configurator.getObservedItemNamesInfratech()).thenReturn(EMPTY_LIST);
        when(configurator.getInfraTechAddress()).thenReturn("");

        migrator.migrate(configurator);

        verify(configurator).setPowerStripList(powerStripListCaptor.capture());
        assertTrue(powerStripListCaptor.getValue().getPowerStrips().isEmpty());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void shouldSetDefaultNameForNetControl() throws Exception {
        when(configurator.getObservedItemNamesNetControl()).thenReturn(EMPTY_LIST);
        when(configurator.getNetControlAddress()).thenReturn("10.0.0.1");

        migrator.migrate(configurator);

        verify(configurator).setPowerStripList(powerStripListCaptor.capture());
        final NetControlPowerStrip netControl = (NetControlPowerStrip) powerStripListCaptor.getValue().getPowerStrips()
                .get(0).getPowerStrip();
        assertEquals("NetControlTrafficLight", netControl.getName());
    }

    @Test
    public void shouldSetDefaultNameForInfratec() throws Exception {
        when(configurator.getInfraTechAddress()).thenReturn("10.0.0.1");

        migrator.migrate(configurator);

        verify(configurator).setPowerStripList(powerStripListCaptor.capture());
        final InfraTecPowerStrip infratec = (InfraTecPowerStrip) powerStripListCaptor.getValue().getPowerStrips()
                .get(0).getPowerStrip();
        assertEquals("InfraTecTrafficLight", infratec.getName());
    }

    @Test
    public void shouldSetDefaultUsernameForInfratec() throws Exception {
        when(configurator.getInfraTechAddress()).thenReturn("10.0.0.1");

        migrator.migrate(configurator);

        verify(configurator).setPowerStripList(powerStripListCaptor.capture());
        final InfraTecPowerStrip infratec = (InfraTecPowerStrip) powerStripListCaptor.getValue().getPowerStrips()
                .get(0).getPowerStrip();
        assertEquals("admin", infratec.getUsername());
    }

    @Test
    public void shouldSetDefaultPasswordForInfratec() throws Exception {
        when(configurator.getInfraTechAddress()).thenReturn("10.0.0.1");

        migrator.migrate(configurator);

        verify(configurator).setPowerStripList(powerStripListCaptor.capture());
        final InfraTecPowerStrip infratec = (InfraTecPowerStrip) powerStripListCaptor.getValue().getPowerStrips()
                .get(0).getPowerStrip();
        assertEquals(Secret.fromString("admin"), infratec.getPassword());
    }

    @Test
    public void shouldNotSearchForPotentialLinksWhenJobIsNoTopLevelItem() throws Exception {
        mockStatic(Jenkins.class);
        when(Jenkins.getInstance()).thenReturn(jenkins);
        final Item item = mock(Item.class);
        when(jenkins.getAllItems()).thenReturn(asList(item));
        when(configurator.getObservedItemNamesInfratech()).thenReturn(asList("Project B"));

        migrator.migrate(configurator);

        verify(item, never()).getAllJobs();
    }

    @Test
    public void shouldHandleExceptionWhenPropertyCannotBeSaved() throws Exception {
        mockJenkinsToHaveThreeProjects("Project A", "Project B", "Project C");
        when(configurator.getObservedItemNamesNetControl()).thenReturn(asList("Project A"));
        doThrow(IOException.class).when(project1).save();

        migrator.migrate(configurator);

        assertTrue("Exception should have been handled", true);
    }

    @Test
    public void shouldMigrateJobsWithMultipleTrafficLights() throws Exception {
        mockJenkinsToHaveThreeProjects("Project A", "Project B", "Project C");
        when(configurator.getObservedItemNamesInfratech()).thenReturn(asList("Project A"));
        when(configurator.getObservedItemNamesNetControl()).thenReturn(asList("Project A"));
        when(project1.getProperty(LinkedTrafficLights.class)).thenReturn(new LinkedTrafficLights(null),
                new LinkedTrafficLights(asList(new TrafficLightId("852ea8e0-23c3-11e4-8c21-0800200c9a66"))));

        migrator.migrate(configurator);

        assertEquals(getLinkedTrafficLightsFor("Project A").size(), 2);
        assertTrue(getLinkedTrafficLightsFor("Project A").contains("852ea8e0-23c3-11e4-8c21-0800200c9a66"));
    }

    private String getIdFromTrafficLight(final Class< ? > powerStrip) {
        verify(configurator).setPowerStripList(powerStripListCaptor.capture());
        for (final PowerStripConfig powerStripConfig : powerStripListCaptor.getValue().getPowerStrips()) {
            if (powerStripConfig.getPowerStrip().getClass() == powerStrip) {
                return powerStripConfig.getPowerStrip().getId();
            }
        }
        fail("No power strip named " + powerStrip.getSimpleName() + " found.");
        return null;
    }

    private List<String> getLinkedTrafficLightsFor(final String projectName) throws IOException {
        if (project1.getDisplayName().equals(projectName)) {
            verify(project1, atLeastOnce()).addProperty(linkedTrafficLightsCaptor.capture());
        } else if (project2.getDisplayName().equals(projectName)) {
            verify(project2, atLeastOnce()).addProperty(linkedTrafficLightsCaptor.capture());
        } else if (project3.getDisplayName().equals(projectName)) {
            verify(project3, atLeastOnce()).addProperty(linkedTrafficLightsCaptor.capture());
        } else {
            fail("No job for " + projectName + " configured.");
            return null;
        }
        final List<String> linkedTrafficLights = new ArrayList<String>();
        for (final TrafficLightId light : linkedTrafficLightsCaptor.getValue().getTrafficLights()) {
            linkedTrafficLights.add(light.getId());
        }
        return linkedTrafficLights;
    }

    private void verifyNotWatchingAnyTrafficLight(final String projectName) throws IOException {
        if (project1.getDisplayName().equals(projectName)) {
            verify(project1, never()).addProperty(any(LinkedTrafficLights.class));
        } else if (project2.getDisplayName().equals(projectName)) {
            verify(project2, never()).addProperty(any(LinkedTrafficLights.class));
        } else if (project3.getDisplayName().equals(projectName)) {
            verify(project3, never()).addProperty(any(LinkedTrafficLights.class));
        } else {
            fail("No configured project " + projectName + " found");
        }
    }

    @SuppressWarnings("unchecked")
    private void mockMinimalDefaultConfiguration() {
        mockStatic(Secret.class);
        when(Secret.fromString("admin")).thenReturn(null);

        when(configurator.getObservedItemNamesNetControl()).thenReturn(EMPTY_LIST);
        when(configurator.getObservedItemNamesInfratech()).thenReturn(EMPTY_LIST);

        when(configurator.getNetControlAddress()).thenReturn("");
        when(configurator.getInfraTechAddress()).thenReturn("");
    }

    private void mockJenkinsToHaveThreeProjects(final String projectName1, final String projectName2,
            final String projectName3) {
        mockStatic(NullSafeJenkins.class);
        when(NullSafeJenkins.getInstance()).thenReturn(jenkins);

        when(jenkins.getAllItems()).thenReturn(asList((Item) item1, (Item) item2, (Item) item3));
        when(item1.getAllJobs()).thenAnswer(new JobListAnswer(project1));
        when(item2.getAllJobs()).thenAnswer(new JobListAnswer(project2));
        when(item3.getAllJobs()).thenAnswer(new JobListAnswer(project3));

        when(project1.getDisplayName()).thenReturn(projectName1);
        when(project2.getDisplayName()).thenReturn(projectName2);
        when(project3.getDisplayName()).thenReturn(projectName3);
    }
}
