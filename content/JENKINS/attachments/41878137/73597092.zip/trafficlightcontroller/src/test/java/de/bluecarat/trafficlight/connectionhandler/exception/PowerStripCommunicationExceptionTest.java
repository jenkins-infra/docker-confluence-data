/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.connectionhandler.exception;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;

import org.junit.Test;

public class PowerStripCommunicationExceptionTest {

    @Test
    public void shouldKeepCause() throws Exception {
        final NullPointerException cause = new NullPointerException();
        final PowerStripCommunicationException exception = new PowerStripCommunicationException(cause);
        assertSame(cause, exception.getCause());
    }

    @Test
    public void shouldKeepMessage() throws Exception {
        final PowerStripCommunicationException exception = new PowerStripCommunicationException("some message");
        assertEquals("some message", exception.getMessage());
    }

    @Test
    public void shouldHaveNoCause() throws Exception {
        final PowerStripCommunicationException exception = new PowerStripCommunicationException();
        assertNull(exception.getCause());
    }
}
