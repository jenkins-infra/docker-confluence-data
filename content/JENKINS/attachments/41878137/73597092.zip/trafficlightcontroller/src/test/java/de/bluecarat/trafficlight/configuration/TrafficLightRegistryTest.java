/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.configuration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.junit.Test;
import org.mockito.Mockito;

import de.bluecarat.trafficlight.controller.TrafficLightController;

public class TrafficLightRegistryTest {

    private static final String CONTROLLER = "firstController";

    private static final UUID CONTROLLER_ID = UUID.fromString("eb517196-8d54-465d-9717-0de37e4355e0");

    @Test
    public void testAddConfiguration() {

        // prepare controller
        final TrafficLightController controller = Mockito.mock(TrafficLightController.class);
        Mockito.when(controller.getId()).thenReturn(CONTROLLER_ID);
        Mockito.when(controller.getName()).thenReturn(CONTROLLER);

        final TrafficLightRegistry registry = new TrafficLightRegistry();
        registry.putController(controller);

        assertEquals(controller, getControllerByName(CONTROLLER, registry));

        final List<String> allControllerNames = getAllControllerNames(registry);
        assertEquals(1, allControllerNames.size());
        assertTrue(allControllerNames.contains(CONTROLLER));
    }

    private TrafficLightController getControllerByName(final String name, final TrafficLightRegistry registry) {
        for (final String id : registry.getAllControllerIds()) {
            final TrafficLightController controller = registry.getControllerById(id);
            if (name.equals(controller.getName())) {
                return controller;
            }
        }
        return null;
    }

    private List<String> getAllControllerNames(final TrafficLightRegistry registry) {
        final List<String> names = new ArrayList<String>();
        for (final String id : registry.getAllControllerIds()) {
            names.add(registry.getControllerById(id).getName());
        }
        return names;
    }

}
