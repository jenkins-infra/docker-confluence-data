/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.powerstrips;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import hudson.Extension;
import hudson.util.Secret;

import java.lang.reflect.Constructor;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import de.bluecarat.trafficlight.controller.InfraTecTrafficLightController;
import de.bluecarat.trafficlight.controller.TrafficLightController;
import de.bluecarat.trafficlight.powerstrips.InfraTecPowerStrip.InfraTecPowerStripDescriptor;
import de.bluecarat.trafficlight.testtools.Reflections;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ Secret.class })
public class InfraTecPowerStripTest {

    @Mock
    Secret secret;

    private InfraTecPowerStrip strip = null;
    private InfraTecPowerStripDescriptor descriptor = null;

    @Before
    public void prepare() {
        descriptor = new InfraTecPowerStripDescriptor();
    }

    @Test
    public void shouldCreateInfratecController() throws Exception {
        strip = new InfraTecPowerStrip("", "", "", "", "", null);
        assertThat(strip.createController(), is(instanceOf(InfraTecTrafficLightController.class)));
    }

    @Test
    public void shouldSetIdForCreatedInfratecController() throws Exception {
        strip = new InfraTecPowerStrip("d1567c70-456f-11e4-916c-0800200c9a66", "", "", "", "", null);
        final TrafficLightController controller = strip.createController();
        assertThat(controller.getId().toString(), is("d1567c70-456f-11e4-916c-0800200c9a66"));
    }

    @Test
    public void shouldSetNameForCreatedInfratecController() throws Exception {
        strip = new InfraTecPowerStrip("", "a name", "", "", "", null);
        final TrafficLightController controller = strip.createController();
        assertThat(controller.getName(), is("a name"));
    }

    @Test
    public void shouldHaveExtension() throws Exception {
        assertThat(InfraTecPowerStripDescriptor.class.getAnnotation(Extension.class), is(notNullValue()));
    }

    @Test
    public void shouldHaveExtensionWithDisplayName() throws Exception {
        assertThat(new InfraTecPowerStripDescriptor().getDisplayName(), is(notNullValue()));
    }

    @Test
    public void shouldHaveDataBoundConstrcutor() throws Exception {
        final Constructor< ? >[] constructors = InfraTecPowerStrip.class.getConstructors();
        assertThat(Reflections.hasDataboundConstructor(constructors), is(true));
    }

    @Test
    public void shouldCreateInfratecPowerStripWithRandomId() throws Exception {
        mockStatic(Secret.class);
        when(Secret.fromString(null)).thenReturn(secret);
        final InfraTecPowerStripDescriptor descriptor = new InfraTecPowerStripDescriptor();

        final AbstractPowerStrip powerStrip = descriptor.getSpecificPowerStrip(null, null, null, null);

        assertThat(powerStrip.getId(), is(instanceOf(String.class)));
    }

    @Test
    public void shouldCreateInfratecPowerStripWithoutName() throws Exception {
        mockStatic(Secret.class);
        when(Secret.fromString(null)).thenReturn(secret);

        final AbstractPowerStrip powerStrip = descriptor.getSpecificPowerStrip(null, null, null, null);

        assertThat(powerStrip.getName(), is(nullValue()));
    }

    @Test
    public void shouldCreateInfratecPowerStripWithAddress() throws Exception {
        mockStatic(Secret.class);
        when(Secret.fromString(null)).thenReturn(secret);

        final AbstractPowerStrip powerStrip = descriptor.getSpecificPowerStrip("address", null, null, null);

        assertThat(powerStrip.getAddress(), is("address"));
    }

    @Test
    public void shouldCreateInfratecPowerStripWithPort() throws Exception {
        mockStatic(Secret.class);
        when(Secret.fromString(null)).thenReturn(secret);

        final AbstractPowerStrip powerStrip = descriptor.getSpecificPowerStrip(null, "80", null, null);

        assertThat(powerStrip.getPort(), is("80"));
    }

    @Test
    public void shouldCreateInfratecPowerStripWithUsername() throws Exception {
        mockStatic(Secret.class);
        when(Secret.fromString(null)).thenReturn(secret);

        final AbstractPowerStripWithAuthentication powerStrip = (AbstractPowerStripWithAuthentication) descriptor
                .getSpecificPowerStrip(null, null, "user", null);

        assertThat(powerStrip.getUsername(), is("user"));
    }

    @Test
    public void shouldCreateInfratecPowerStripWithPassword() throws Exception {
        mockStatic(Secret.class);
        when(Secret.fromString("pass")).thenReturn(secret);

        final AbstractPowerStripWithAuthentication powerStrip = (AbstractPowerStripWithAuthentication) descriptor
                .getSpecificPowerStrip(null, null, null, "pass");

        assertThat(powerStrip.getPassword(), is(secret));
    }

    @Test
    public void shouldCreateInfratecPowerStrip() throws Exception {
        mockStatic(Secret.class);
        when(Secret.fromString(null)).thenReturn(secret);
        assertThat(descriptor.getSpecificPowerStrip(null, null, null, null), is(instanceOf(InfraTecPowerStrip.class)));
    }
}
