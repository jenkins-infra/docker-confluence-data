/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.when;
import hudson.model.Failure;
import jenkins.model.Jenkins;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest(Jenkins.class)
public class NullSafeJenkinsTest {

    @Mock
    private Jenkins jenkins;

    @Test
    public void shouldReturnInstance() throws Exception {
        mockStatic(Jenkins.class);
        when(Jenkins.getInstance()).thenReturn(jenkins);

        assertNotNull(NullSafeJenkins.getInstance());
    }

    @Test
    public void shouldFailWhenInstanceIsNull() throws Exception {
        mockStatic(Jenkins.class);
        when(Jenkins.getInstance()).thenReturn(null);

        try {
            NullSafeJenkins.getInstance();
            fail("Should throw runtime exception.");
        } catch (final Failure f) {
            assertEquals("Could not retrieve Jenkins instance, aborting execution.", f.getMessage());
        }
    }
}
