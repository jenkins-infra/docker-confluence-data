/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight;

import static java.util.Arrays.asList;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import hudson.util.Secret;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.jvnet.hudson.test.JenkinsRule;

import de.bluecarat.trafficlight.controller.NetControlV4TrafficLightController;
import de.bluecarat.trafficlight.powerstrips.AbstractPowerStripWithAuthentication;
import de.bluecarat.trafficlight.powerstrips.NetControlPowerStrip;
import de.bluecarat.trafficlight.powerstrips.NetControlV4PowerStrip;
import de.bluecarat.trafficlight.powerstrips.PowerStripConfig;
import de.bluecarat.trafficlight.powerstrips.PowerStripList;
import de.bluecarat.trafficlight.services.TrafficLightRegistryConfigurator;

/**
 * Test class for class TrafficLightConfigurator.
 *
 * @author CME
 * @author CST
 * @author SHO
 *
 */
public class TrafficLightConfiguratorTest {

    @Rule
    public final JenkinsRule rule = new JenkinsRule();

    private TrafficLightConfigurator testedConfigurator = null;

    @Before
    public final void prepare() throws Exception {
        testedConfigurator = new TrafficLightConfigurator();
        testedConfigurator.setRegistryConfigurator(new TrafficLightRegistryConfigurator());
    }

    @Test
    public void testVersion() throws Exception {
        testedConfigurator.setVersion("3.0");
        assertEquals("3.0", testedConfigurator.getVersion());
    }

    @Test
    public void shouldSetPowerStriplist() throws Exception {
        final PowerStripList powerStripList = createPowerStripList();
        testedConfigurator.setPowerStripList(powerStripList);
        assertEquals(powerStripList, testedConfigurator.getPowerStripList());
    }

    private PowerStripList createPowerStripList() {
        final NetControlPowerStrip ncStrip = new NetControlPowerStrip(UUID.randomUUID().toString(), "nc", "10.0.0.1",
                "80");
        final PowerStripConfig config = new PowerStripConfig(ncStrip);
        final List<PowerStripConfig> powerStripConfigs = new ArrayList<PowerStripConfig>();
        powerStripConfigs.add(config);
        final PowerStripList powerStripList = new PowerStripList(powerStripConfigs);
        return powerStripList;
    }

    @Test
    public void testDisplayName() throws Exception {
        assertFalse(testedConfigurator.getDisplayName().isEmpty());
    }

    @Test
    public final void shouldAddNetControlPowerStrip() {
        final UUID id = UUID.randomUUID();
        final String name = "net control";
        final String address = "10.10.0.1";
        final String port = "80";
        final NetControlPowerStrip powerStrip = new NetControlPowerStrip(id.toString(), name, address, port);
        PowerStripConfig config = new PowerStripConfig(powerStrip);
        final List<PowerStripConfig> configList = new ArrayList<PowerStripConfig>();
        configList.add(config);
        final PowerStripList list = new PowerStripList(configList);
        testedConfigurator.setPowerStripList(list);
        testedConfigurator.initializeTrafficLightRegistry();
        assertEquals(name, testedConfigurator.getTrafficLightRegistry().getControllerById(id.toString()).getName());
    }

    @Test
    public final void shouldAddNetControlV4PowerStrip() {
        final AbstractPowerStripWithAuthentication powerStrip = new NetControlV4PowerStrip(
                "7da63160-0771-11e4-84a3-0002a5d5c51b", "name", "address", "123", "user", Secret.fromString("pwd"));
        final PowerStripList list = new PowerStripList(asList(new PowerStripConfig(powerStrip)));
        testedConfigurator.setPowerStripList(list);

        testedConfigurator.initializeTrafficLightRegistry();

        assertEquals("name",
                testedConfigurator.getTrafficLightRegistry().getControllerById("7da63160-0771-11e4-84a3-0002a5d5c51b")
                        .getName());
        assertEquals(NetControlV4TrafficLightController.class, testedConfigurator.getTrafficLightRegistry()
                .getControllerById("7da63160-0771-11e4-84a3-0002a5d5c51b").getClass());
    }
}
