/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.powerstrips;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import org.junit.Test;

import de.bluecarat.trafficlight.controller.TrafficLightController;

public class AbstractPowerStripTest {

    private AbstractPowerStrip powerStrip = null;

    @Test
    public void shouldTakeIdFromConstructor() throws Exception {
        powerStrip = new PowerStripForTest("some id", null, null, null);
        assertThat(powerStrip.getId(), is("some id"));
    }

    @Test
    public void shouldTakeNameFromConstructor() throws Exception {
        powerStrip = new PowerStripForTest(null, "some name", null, null);
        assertThat(powerStrip.getName(), is("some name"));
    }

    @Test
    public void shouldTakeAddressFromConstructor() throws Exception {
        powerStrip = new PowerStripForTest(null, null, "some address", null);
        assertThat(powerStrip.getAddress(), is("some address"));
    }

    @Test
    public void shouldTakePortFromConstructor() throws Exception {
        powerStrip = new PowerStripForTest(null, null, null, "some port");
        assertThat(powerStrip.getPort(), is("some port"));
    }

    static class PowerStripForTest extends AbstractPowerStrip {
        public PowerStripForTest(final String id, final String name, final String address, final String port) {
            super(id, name, address, port);
        }

        @Override
        public TrafficLightController createController() {
            return null;
        }
    }
}
