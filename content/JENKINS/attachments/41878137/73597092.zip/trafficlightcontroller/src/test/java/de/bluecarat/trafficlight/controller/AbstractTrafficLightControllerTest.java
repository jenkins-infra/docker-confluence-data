/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.controller;

import static java.util.UUID.fromString;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.contains;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import hudson.model.Result;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.modules.junit4.PowerMockRunner;

import de.bluecarat.trafficlight.TrafficLightState;
import de.bluecarat.trafficlight.connectionhandler.exception.PowerStripCommunicationException;
import de.bluecarat.trafficlight.controller.AbstractTrafficLightControllerTest.ControllerForBlinkTest.Action;
import de.bluecarat.trafficlight.controller.AbstractTrafficLightControllerTest.ControllerForTest.PowerStripForTest;
import de.bluecarat.trafficlight.controller.AbstractTrafficLightControllerTest.ControllerForTest.State;
import de.bluecarat.trafficlight.powerstrips.AbstractPowerStrip;

@RunWith(PowerMockRunner.class)
public class AbstractTrafficLightControllerTest {

    private ControllerForTest controller = null;

    @Mock
    AbstractPowerStrip powerStrip;

    @Before
    public void prepare() throws Exception {
        controller = new ControllerForTest(powerStrip);
    }

    @Test
    public void shouldSetStateToYellowOnBuildStarted() throws Exception {
        controller.buildStarted();
        assertTrue("State was: " + controller.getStateDescription(), isState(TrafficLightState.YELLOW));
    }

    @Test
    public void shouldSetStateToGreenOnBuildFinishedWhenResultIsSuccessfulAndStateWasYellow() throws Exception {
        setStateToYellow();
        controller.buildFinished(Result.SUCCESS);
        assertTrue("State was: " + controller.getStateDescription(), isState(TrafficLightState.GREEN));
    }

    @Test
    public void shouldSetStateToRedOnBuildFinishedWhenResultIsNotSuccessfulAndStateWasYellow() throws Exception {
        setStateToYellow();
        controller.buildFinished(Result.FAILURE);
        assertTrue("State was: " + controller.getStateDescription(), isState(TrafficLightState.RED));
    }

    @Test
    public void shouldSetStateToIllegalOnBuildFinishedWhenResultIsSuccessfulAndStateWasGreen() throws Exception {
        controller.buildFinished(Result.SUCCESS);
        assertTrue("State was: " + controller.getStateDescription(), isState(TrafficLightState.ILLEGAL));
    }

    @Test
    public void shouldSetStateToIllegalOnBuildFinishedWhenResultIsNotSuccessfulAndStateWasGreen() throws Exception {
        controller.buildFinished(Result.FAILURE);
        assertTrue("State was: " + controller.getStateDescription(), isState(TrafficLightState.ILLEGAL));
    }

    @Test
    public void shouldCountFailureResultAsNotSuccessful() throws Exception {
        setStateToYellow();
        controller.buildFinished(Result.FAILURE);
        assertTrue("State was: " + controller.getStateDescription(), isState(TrafficLightState.RED));
    }

    @Test
    public void shouldCountUnstableResultAsNotSuccessful() throws Exception {
        setStateToYellow();
        controller.buildFinished(Result.UNSTABLE);
        assertTrue("State was: " + controller.getStateDescription(), isState(TrafficLightState.RED));
    }

    @Test
    public void shouldUseUuidFromPowerStrip() throws Exception {
        controller = new ControllerForTest(new PowerStripForTest("bf440c10-3ff6-11e4-916c-0800200c9a66", null, null,
                null));
        assertEquals(fromString("bf440c10-3ff6-11e4-916c-0800200c9a66"), controller.getId());
    }

    @Test
    public void shouldUseNameFromPowerStrip() throws Exception {
        controller = new ControllerForTest(new PowerStripForTest(null, "controller name", null, null));
        assertEquals("controller name", controller.getName());
    }

    @Test
    public void shouldUseHostnameFromPowerStrip() throws Exception {
        controller = new ControllerForTest(new PowerStripForTest(null, null, "address", null));
        assertEquals("address", controller.getHostname());
    }

    @Test
    public void shouldUsePortFromPowerStrip() throws Exception {
        controller = new ControllerForTest(new PowerStripForTest(null, null, null, "80"));
        assertEquals("80", controller.getPort());
    }

    private void setStateToYellow() {
        controller.buildStarted();
    }

    private boolean isState(final TrafficLightState state) {
        if (state == TrafficLightState.GREEN) {
            return checkGreen();
        } else if (state == TrafficLightState.YELLOW) {
            return checkYellow();
        } else if (state == TrafficLightState.RED) {
            return checkRed();
        } else if (state == TrafficLightState.ILLEGAL) {
            return checkIllegal();
        } else {
            return false;
        }
    }

    private boolean checkGreen() {
        return controller.green == State.ON && controller.yellow == State.OFF && controller.red == State.OFF;
    }

    private boolean checkYellow() {
        return controller.green == State.OFF && controller.yellow == State.ON && controller.red == State.OFF;
    }

    private boolean checkRed() {
        return controller.green == State.OFF && controller.yellow == State.OFF && controller.red == State.ON;
    }

    private boolean checkIllegal() {
        return controller.green == State.ON && controller.yellow == State.ON && controller.red == State.ON;
    }

    @Test
    public void shouldUseAddressTemplate() throws Exception {
        final Map<String, String> values = new HashMap<String, String>();
        values.put("host", "some-host");
        final URI uri = controller.buildUri(values);
        assertThat(uri.toString(), is("http://some-host"));
    }

    @Test
    public void shouldHandlePowerStripException() throws Exception {
        final AbstractTrafficLightController controller = new ControllerForTestThrows(powerStrip);
        controller.setTrafficLights();
        assertThat(true, is(true));
    }

    @Test
    public void shouldBlinkInCorrectOrder() throws Exception {
        ControllerForBlinkTest controller = new ControllerForBlinkTest(powerStrip);
        controller.blink();
        assertThat(
                controller.states,
                contains(Action.RED_OFF, Action.YELLOW_OFF, Action.GREEN_OFF, Action.RED_ON, Action.YELLOW_ON,
                        Action.GREEN_ON, Action.RED_OFF, Action.YELLOW_OFF, Action.GREEN_OFF));

    }

    static class ControllerForTest extends AbstractTrafficLightController {
        static public class PowerStripForTest extends AbstractPowerStrip {
            public PowerStripForTest(final String id, final String name, final String address, final String port) {
                super(id, name, address, port);
            }

            @Override
            public TrafficLightController createController() {
                return null;
            }
        }

        public enum State {
            UNDEFINED, ON, OFF
        }

        public State red = State.UNDEFINED;
        public State yellow = State.UNDEFINED;
        public State green = State.UNDEFINED;

        protected ControllerForTest(final AbstractPowerStrip powerStrip) {
            super(powerStrip);
        }

        @Override
        protected void redOff() {
            red = State.OFF;
        }

        @Override
        protected void redOn() {
            red = State.ON;
        }

        @Override
        protected void yellowOff() {
            yellow = State.OFF;
        }

        @Override
        protected void yellowOn() {
            yellow = State.ON;
        }

        @Override
        protected void greenOff() {
            green = State.OFF;
        }

        @Override
        protected void greenOn() {
            green = State.ON;
        }

        String getStateDescription() {
            return String.format("red=%s, yellow=%s, green=%s", red.name(), yellow.name(), green.name());
        }

        @Override
        protected String getAddressTemplate() {
            return "http://${host}";
        }
    }

    static class ControllerForBlinkTest extends AbstractTrafficLightController {

        enum Action {
            GREEN_ON, YELLOW_ON, RED_ON, GREEN_OFF, YELLOW_OFF, RED_OFF
        }

        public List<Action> states = new ArrayList<Action>();

        protected ControllerForBlinkTest(final AbstractPowerStrip powerStrip) {
            super(powerStrip);
        }

        @Override
        protected void yellowOn() throws PowerStripCommunicationException {
            states.add(Action.YELLOW_ON);
        }

        @Override
        protected void greenOn() throws PowerStripCommunicationException {
            states.add(Action.GREEN_ON);
        }

        @Override
        protected void redOff() throws PowerStripCommunicationException {
            states.add(Action.RED_OFF);
        }

        @Override
        protected void redOn() throws PowerStripCommunicationException {
            states.add(Action.RED_ON);
        }

        @Override
        protected void yellowOff() throws PowerStripCommunicationException {
            states.add(Action.YELLOW_OFF);
        }

        @Override
        protected void greenOff() throws PowerStripCommunicationException {
            states.add(Action.GREEN_OFF);
        }

        @Override
        protected String getAddressTemplate() {
            return null;
        }

    }

    static class ControllerForTestThrows extends AbstractTrafficLightController {

        protected ControllerForTestThrows(final AbstractPowerStrip powerStrip) {
            super(powerStrip);
        }

        @Override
        protected void yellowOn() throws PowerStripCommunicationException {
        }

        @Override
        protected void greenOn() throws PowerStripCommunicationException {
            throw new PowerStripCommunicationException("error msg");
        }

        @Override
        protected void redOff() throws PowerStripCommunicationException {
        }

        @Override
        protected void redOn() throws PowerStripCommunicationException {
        }

        @Override
        protected void yellowOff() throws PowerStripCommunicationException {
        }

        @Override
        protected void greenOff() throws PowerStripCommunicationException {
        }

        @Override
        protected String getAddressTemplate() {
            return null;
        }
    }
}
