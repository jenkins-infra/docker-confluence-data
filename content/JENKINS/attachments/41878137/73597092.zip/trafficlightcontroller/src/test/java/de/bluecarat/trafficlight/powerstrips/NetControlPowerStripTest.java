/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.powerstrips;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import hudson.Extension;
import hudson.util.Secret;

import java.lang.reflect.Constructor;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import de.bluecarat.trafficlight.controller.NetControlTrafficLightController;
import de.bluecarat.trafficlight.controller.TrafficLightController;
import de.bluecarat.trafficlight.powerstrips.NetControlPowerStrip.NetControlPowerStripDescriptor;
import de.bluecarat.trafficlight.testtools.Reflections;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ Secret.class })
public class NetControlPowerStripTest {

    @Mock
    Secret secret;

    private NetControlPowerStrip strip = null;
    private NetControlPowerStripDescriptor descriptor = null;

    @Before
    public void prepare() {
        descriptor = new NetControlPowerStripDescriptor();
    }

    @Test
    public void shouldCreateNetControlController() throws Exception {
        strip = new NetControlPowerStrip("", "", "", "");
        assertThat(strip.createController(), is(instanceOf(NetControlTrafficLightController.class)));
    }

    @Test
    public void shouldSetIdForCreatedNetControlV4Controller() throws Exception {
        strip = new NetControlPowerStrip("d1567c70-456f-11e4-916c-0800200c9a67", "", "", "");
        final TrafficLightController controller = strip.createController();
        assertThat(controller.getId().toString(), is("d1567c70-456f-11e4-916c-0800200c9a67"));
    }

    @Test
    public void shouldSetNameForCreatedNetControlV4Controller() throws Exception {
        strip = new NetControlPowerStrip("", "a name", "", "");
        final TrafficLightController controller = strip.createController();
        assertThat(controller.getName(), is("a name"));
    }

    @Test
    public void shouldHaveExtension() throws Exception {
        assertThat(NetControlPowerStripDescriptor.class.getAnnotation(Extension.class), is(notNullValue()));
    }

    @Test
    public void shouldHaveExtensionWithDisplayName() throws Exception {
        assertThat(new NetControlPowerStripDescriptor().getDisplayName(), is(notNullValue()));
    }

    @Test
    public void shouldHaveDataBoundConstrcutor() throws Exception {
        final Constructor< ? >[] constructors = NetControlPowerStrip.class.getConstructors();
        assertThat(Reflections.hasDataboundConstructor(constructors), is(true));
    }

    @Test
    public void shouldCreateNetControlPowerStripWithRandomId() throws Exception {
        mockStatic(Secret.class);
        when(Secret.fromString(null)).thenReturn(secret);

        final AbstractPowerStrip powerStrip = descriptor.getSpecificPowerStrip(null, null, null, null);

        assertThat(powerStrip.getId(), is(instanceOf(String.class)));
    }

    @Test
    public void shouldCreateNetControlPowerStripWithoutName() throws Exception {
        mockStatic(Secret.class);
        when(Secret.fromString(null)).thenReturn(secret);

        final AbstractPowerStrip powerStrip = descriptor.getSpecificPowerStrip(null, null, null, null);

        assertThat(powerStrip.getName(), is(nullValue()));
    }

    @Test
    public void shouldCreateNetControlPowerStripWithAddress() throws Exception {
        mockStatic(Secret.class);
        when(Secret.fromString(null)).thenReturn(secret);

        final AbstractPowerStrip powerStrip = descriptor.getSpecificPowerStrip("address", null, null, null);

        assertThat(powerStrip.getAddress(), is("address"));
    }

    @Test
    public void shouldCreateNetControlPowerStripWithPort() throws Exception {
        mockStatic(Secret.class);
        when(Secret.fromString(null)).thenReturn(secret);

        final AbstractPowerStrip powerStrip = descriptor.getSpecificPowerStrip(null, "80", null, null);

        assertThat(powerStrip.getPort(), is("80"));
    }

    @Test
    public void shouldCreateNetControlPowerStrip() throws Exception {
        mockStatic(Secret.class);
        when(Secret.fromString(null)).thenReturn(secret);
        assertThat(descriptor.getSpecificPowerStrip(null, null, null, null), is(instanceOf(NetControlPowerStrip.class)));
    }

}
