/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight;

import static org.junit.Assert.assertEquals;
import hudson.model.Result;

import org.junit.Test;

/**
 * Tests the TrafficLightState machine.
 * 
 * @author CME
 * @author CST
 * 
 */
public class TrafficLightStateTest {

    /**
     * Test for green state.
     */
    @Test
    public final void testGreenState() {
        final TrafficLightState greenState = TrafficLightState.GREEN;

        assertEquals(TrafficLightState.YELLOW, greenState.buildStarted(false));

        assertEquals(TrafficLightState.ILLEGAL, greenState.buildFinished(Result.FAILURE, false));

        assertEquals(TrafficLightState.ILLEGAL, greenState.buildFinished(Result.ABORTED, false));

        assertEquals(TrafficLightState.ILLEGAL, greenState.buildFinished(Result.UNSTABLE, false));
        assertEquals(TrafficLightState.ILLEGAL, greenState.buildFinished(Result.SUCCESS, false));
    }

    /**
     * Test for yellow state.
     */
    @Test
    public final void testYellowState() {
        final TrafficLightState yellowState = TrafficLightState.YELLOW;

        assertEquals(TrafficLightState.YELLOW, yellowState.buildStarted(false));

        assertEquals(TrafficLightState.RED, yellowState.buildFinished(Result.FAILURE, false));
        assertEquals(TrafficLightState.RED, yellowState.buildFinished(Result.FAILURE, true));
        assertEquals(TrafficLightState.RED, yellowState.buildFinished(Result.ABORTED, false));
        assertEquals(TrafficLightState.RED, yellowState.buildFinished(Result.ABORTED, true));
        assertEquals(TrafficLightState.RED, yellowState.buildFinished(Result.UNSTABLE, false));
        assertEquals(TrafficLightState.RED, yellowState.buildFinished(Result.UNSTABLE, true));

        assertEquals(TrafficLightState.GREEN, yellowState.buildFinished(Result.SUCCESS, true));
        assertEquals(TrafficLightState.YELLOW, yellowState.buildFinished(Result.SUCCESS, false));

        assertEquals(TrafficLightState.YELLOW, yellowState.buildStarted(false));

        assertEquals(TrafficLightState.YELLOW, yellowState.buildStarted(true));
    }

    /**
     * Test for red state.
     */
    @Test
    public final void testRedState() {
        final TrafficLightState redState = TrafficLightState.RED;

        assertEquals(TrafficLightState.YELLOW, redState.buildStarted(true));

        assertEquals(TrafficLightState.RED, redState.buildStarted(false));

        assertEquals(TrafficLightState.RED, redState.buildFinished(Result.FAILURE, false));
        assertEquals(TrafficLightState.RED, redState.buildFinished(Result.FAILURE, true));
        assertEquals(TrafficLightState.RED, redState.buildFinished(Result.ABORTED, false));
        assertEquals(TrafficLightState.RED, redState.buildFinished(Result.ABORTED, true));
        assertEquals(TrafficLightState.RED, redState.buildFinished(Result.UNSTABLE, false));
        assertEquals(TrafficLightState.RED, redState.buildFinished(Result.UNSTABLE, true));

        assertEquals(TrafficLightState.RED, redState.buildFinished(Result.SUCCESS, true));
        assertEquals(TrafficLightState.RED, redState.buildFinished(Result.SUCCESS, false));
    }

    /**
     * Tests the illegal state.
     */
    @Test
    public final void testIllegalState() {
        final TrafficLightState illegalState = TrafficLightState.ILLEGAL;

        assertEquals(TrafficLightState.YELLOW, illegalState.buildStarted(false));
        assertEquals(TrafficLightState.YELLOW, illegalState.buildStarted(true));

        assertEquals(TrafficLightState.RED, illegalState.buildFinished(Result.FAILURE, false));
        assertEquals(TrafficLightState.RED, illegalState.buildFinished(Result.FAILURE, true));
        assertEquals(TrafficLightState.RED, illegalState.buildFinished(Result.ABORTED, false));
        assertEquals(TrafficLightState.RED, illegalState.buildFinished(Result.ABORTED, true));
        assertEquals(TrafficLightState.RED, illegalState.buildFinished(Result.UNSTABLE, false));
        assertEquals(TrafficLightState.RED, illegalState.buildFinished(Result.UNSTABLE, true));

        assertEquals(TrafficLightState.GREEN, illegalState.buildFinished(Result.SUCCESS, true));
        assertEquals(TrafficLightState.YELLOW, illegalState.buildFinished(Result.SUCCESS, false));
    }
}
