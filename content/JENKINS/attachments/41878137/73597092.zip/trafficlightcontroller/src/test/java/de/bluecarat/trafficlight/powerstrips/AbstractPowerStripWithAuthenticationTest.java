/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.powerstrips;

import static org.junit.Assert.assertEquals;
import hudson.util.Secret;

import org.junit.Test;

import de.bluecarat.trafficlight.controller.TrafficLightController;

public class AbstractPowerStripWithAuthenticationTest {

    @Test
    public void shouldTakeUsernameFromConstructor() {
        final AbstractPowerStripWithAuthentication powerStrip = new PowerStripWithAuthenticationForTest("some id",
                "some name", "some address", "80", "some user", null);
        assertEquals("some user", powerStrip.getUsername());
    }

    @Test
    public void shouldTakePasswordFromConstructor() {
        final AbstractPowerStripWithAuthentication powerStrip = new PowerStripWithAuthenticationForTest("some id",
                "some name", "some address", "80", "some user", null);
        assertEquals(null, powerStrip.getPassword());
    }

    private static class PowerStripWithAuthenticationForTest extends AbstractPowerStripWithAuthentication {

        public PowerStripWithAuthenticationForTest(final String id, final String name, final String address,
                final String port, final String username, final Secret password) {
            super(id, name, address, port, username, password);
        }

        @Override
        public TrafficLightController createController() {
            return null;
        }
    }
}
