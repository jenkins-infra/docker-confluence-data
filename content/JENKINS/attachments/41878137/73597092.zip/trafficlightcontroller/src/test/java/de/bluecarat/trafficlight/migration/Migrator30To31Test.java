/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.migration;

import static java.util.Arrays.asList;
import static java.util.Collections.EMPTY_LIST;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import hudson.util.VersionNumber;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import de.bluecarat.trafficlight.TrafficLightConfigurator;
import de.bluecarat.trafficlight.powerstrips.AbstractPowerStrip;
import de.bluecarat.trafficlight.powerstrips.InfraTecPowerStrip;
import de.bluecarat.trafficlight.powerstrips.NetControlPowerStrip;
import de.bluecarat.trafficlight.powerstrips.NetControlV4PowerStrip;
import de.bluecarat.trafficlight.powerstrips.PowerStripConfig;
import de.bluecarat.trafficlight.powerstrips.PowerStripList;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ TrafficLightConfigurator.class, PowerStripList.class, PowerStripConfig.class,
        InfraTecPowerStrip.class, NetControlPowerStrip.class, NetControlV4PowerStrip.class })
public class Migrator30To31Test {

    @Mock
    TrafficLightConfigurator configurator;

    @Mock
    PowerStripList powerStripList;

    @Mock
    PowerStripConfig config;

    @Mock
    InfraTecPowerStrip infraTec;

    @Mock
    NetControlPowerStrip netControl;

    @Mock
    NetControlV4PowerStrip netControlV4;

    private Migrator30To31 migrator = null;

    @Before
    public void prepare() throws Exception {
        migrator = new Migrator30To31();
    }

    @Test
    public void shouldHandleVersion30() throws Exception {
        assertThat(migrator.canHandle(new VersionNumber("3.0")), is(true));
    }

    @Test
    public void shouldHandleVersion300() throws Exception {
        assertThat(migrator.canHandle(new VersionNumber("3.0.0")), is(true));
    }

    @Test
    public void shouldNotHandleVersion23() throws Exception {
        assertThat(migrator.canHandle(new VersionNumber("2.3")), is(false));
    }

    @Test
    public void shouldNotHandleNull() throws Exception {
        assertThat(migrator.canHandle(null), is(false));
    }

    @Test
    public void shouldNotHandleEmpty() throws Exception {
        assertThat(migrator.canHandle(new VersionNumber("")), is(false));
    }

    @Test
    public void shouldReturn31AsNewVersion() throws Exception {
        mockConfiguratorToHaveNoPowerStrips();
        final VersionNumber newVersion = migrator.migrate(configurator);
        assertThat(newVersion, is(new VersionNumber("3.1")));
    }

    @SuppressWarnings("unchecked")
    private void mockConfiguratorToHaveNoPowerStrips() {
        when(configurator.getPowerStripList()).thenReturn(powerStripList);
        when(powerStripList.getPowerStrips()).thenReturn(EMPTY_LIST);
    }

    @Test
    public void shouldSetDefaultPortOnInfratecPowerStrip() throws Exception {
        mockConfiguratorToHave(infraTec);
        migrator.migrate(configurator);
        verify(infraTec).setPort("80");
    }

    @Test
    public void shouldSetDefaultPortOnNetControlPowerStrip() throws Exception {
        mockConfiguratorToHave(netControl);
        migrator.migrate(configurator);
        verify(netControl).setPort("80");
    }

    @Test
    public void shouldNotSetDefaultPortOnNetControlV4PowerStrip() throws Exception {
        mockConfiguratorToHave(netControlV4);
        migrator.migrate(configurator);
        verify(netControlV4, never()).setPort("80");
    }

    private void mockConfiguratorToHave(final AbstractPowerStrip powerStrip) {
        when(configurator.getPowerStripList()).thenReturn(powerStripList);
        when(powerStripList.getPowerStrips()).thenReturn(asList(config));
        when(config.getPowerStrip()).thenReturn(powerStrip);
    }
}
