/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.configuration;

import static java.util.Arrays.asList;
import static java.util.Collections.EMPTY_LIST;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import hudson.PluginManager;
import hudson.PluginWrapper;
import hudson.util.Secret;
import hudson.util.VersionNumber;

import java.io.IOException;
import java.util.UUID;

import jenkins.model.Jenkins;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import de.bluecarat.trafficlight.TrafficLightConfigurator;
import de.bluecarat.trafficlight.migration.MigrationConfig;
import de.bluecarat.trafficlight.migration.Migrator;
import de.bluecarat.trafficlight.migration.exception.CanNotConvertConfigFileException;
import de.bluecarat.trafficlight.powerstrips.PowerStripList;

/**
 * TODO test: shouldSaveMigration
 *
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ MigrationConfig.class, Jenkins.class, TrafficLightConfigurator.class, Secret.class,
    PowerStripList.class })
public class TrafficLightConfigurationMigratorTest {

    TrafficLightConfigurationMigrator listener = null;

    @Mock
    TrafficLightConfigurator configurator;

    @Mock
    MigrationConfig migrationConfig;

    @Mock
    Migrator migrator;

    @Mock
    Jenkins jenkins;

    @Mock
    PluginManager pluginManager;

    @Mock
    PluginWrapper pluginWrapper;

    @Mock
    Secret password;

    @Mock
    UUID uuid;

    @Captor
    ArgumentCaptor<VersionNumber> versionNumberCaptor;

    @Mock
    PowerStripList powerStripList;

    @Rule
    public TemporaryFolder file = new TemporaryFolder();

    @Before
    public void prepare() throws IOException {
        createListenerWithMigrationConfig();
        createEmptyConfigFile();
        mockDefaultProgramVersion();
        mockDefaultMigrationResult();
    }

    @Test
    public void shouldGetVersionOfConfigurationFile() throws IOException {
        mockConfigurationVersionToBe("2");
        listener.onLoaded();
        verify(migrator).canHandle(new VersionNumber("2"));
    }

    @Test
    public void shouldSetConfigurationVersionToZeroIfVersionIsMissing() throws IOException {
        mockConfigurationVersionToBe(null);
        listener.onLoaded();
        verify(migrator).canHandle(new VersionNumber("0"));
    }

    @Test
    public void shouldNotConvertConfigurationVersionIfVersionIsSet() throws IOException {
        mockConfigurationVersionToBe("1");
        listener.onLoaded();
        verify(migrator).canHandle(new VersionNumber("1"));
    }

    @Test
    public void shouldGetVersionOfPlugin() throws IOException {
        mockConfigurationVersionToBe("9");
        listener.onLoaded();
        verify(configurator).setVersion(anyString());
    }

    @Test
    public void shouldNotMigrateIfVersionsAreEqual() throws IOException {
        mockConfigurationVersionToBe("10");
        mockProgramVersionToBe("10");

        listener.onLoaded();

        verify(configurator, never()).setVersion(anyString());
    }

    @Test
    public void shouldUseMigratorForMigration() throws IOException {
        listener.onLoaded();
        verify(migrator).canHandle(any(VersionNumber.class));
    }

    @Test
    public void shouldUpdateVersionOfConfiguratorAfterSuccessfullMigration() throws IOException {
        mockConfigurationVersionToBe("9");
        listener.onLoaded();
        verify(configurator).setVersion("10");
    }

    @Test
    public void shouldNotUpdateVersionOfConfiguratorWhenNoCompleteMigrationPathWasFound() throws IOException {
        mockConfigurationVersionToBe("9");
        mockProgramVersionToBe("11");

        try {
            listener.onLoaded();
            fail();
        } catch (CanNotConvertConfigFileException e) {
            assertTrue(e != null);
        }
    }

    private void createListenerWithMigrationConfig() {
        when(migrationConfig.getMigrators()).thenReturn(asList(migrator));
        listener = new TrafficLightConfigurationMigrator();
        listener.setMigrationConfig(migrationConfig);
        listener.setTrafficLightConfigurator(configurator);
    }

    private void mockDefaultMigrationResult() {
        when(migrator.canHandle(any(VersionNumber.class))).thenReturn(true);
        when(migrator.migrate(configurator)).thenReturn(new VersionNumber("10"));
    }

    private void mockConfigurationVersionToBe(final String version) {
        when(configurator.getVersion()).thenReturn(version);
    }

    private void mockDefaultProgramVersion() {
        mockProgramVersionToBe("10");
    }

    private void mockProgramVersionToBe(final String version) {
        mockStatic(Jenkins.class);
        when(Jenkins.getInstance()).thenReturn(jenkins);
        when(jenkins.getPluginManager()).thenReturn(pluginManager);
        when(pluginManager.getPlugin("trafficlightcontroller")).thenReturn(pluginWrapper);
        when(pluginWrapper.getVersionNumber()).thenReturn(new VersionNumber(version));
    }

    private void createEmptyConfigFile() throws IOException {
        file.newFile(TrafficLightConfigurator.class.getName() + ".xml");
        when(jenkins.getRootDir()).thenReturn(file.getRoot());
    }

    @Test
    public void shouldSaveOnlyOnceDuringMigration() throws IOException {
        mockProgramVersionToBe("3.1");
        mockConfigurator();
        mockConfiguratorToHaveNoPowerStrips();

        TrafficLightConfigurationMigrator migrator = new TrafficLightConfigurationMigrator();
        migrator.setMigrationConfig(new MigrationConfig());
        migrator.setTrafficLightConfigurator(configurator);

        migrator.onLoaded();

        verify(configurator).save();
    }

    @SuppressWarnings("unchecked")
    private void mockConfiguratorToHaveNoPowerStrips() {
        when(configurator.getPowerStripList()).thenReturn(powerStripList);
        when(powerStripList.getPowerStrips()).thenReturn(EMPTY_LIST);
    }

    private void mockConfigurator() {
        when(configurator.getVersion()).thenReturn(null);
        when(configurator.getInfraTechAddress()).thenReturn("10.0.0.1");
        when(password.getPlainText()).thenReturn("");
        mockStatic(Secret.class);
        when(Secret.decrypt(anyString())).thenReturn(null);
        when(configurator.getNetControlAddress()).thenReturn("");
        when(uuid.toString()).thenReturn("");
    }
}
