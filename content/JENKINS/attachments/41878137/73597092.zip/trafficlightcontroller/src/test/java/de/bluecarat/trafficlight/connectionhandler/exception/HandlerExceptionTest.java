/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.connectionhandler.exception;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;

import org.junit.Test;

public class HandlerExceptionTest {

    @Test
    public void shouldKeepCause() throws Exception {
        final NullPointerException cause = new NullPointerException();
        final HandlerException exception = new HandlerException(cause);
        assertSame(cause, exception.getCause());
    }

    @Test
    public void shouldKeepMessageAndCause() throws Exception {
        final NullPointerException cause = new NullPointerException();
        final HandlerException exception = new HandlerException("some message", cause);
        assertSame(cause, exception.getCause());
        assertEquals("some message", exception.getMessage());
    }

    @Test
    public void shouldKeepMessage() throws Exception {
        final HandlerException exception = new HandlerException("some message");
        assertEquals("some message", exception.getMessage());
    }

    @Test
    public void shouldHaveNoCause() throws Exception {
        final HandlerException exception = new HandlerException();
        assertNull(exception.getCause());
    }
}
