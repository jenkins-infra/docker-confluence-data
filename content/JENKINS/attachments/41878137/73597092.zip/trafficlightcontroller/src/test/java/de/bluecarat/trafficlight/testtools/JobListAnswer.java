/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.testtools;

import hudson.model.Job;

import java.util.ArrayList;
import java.util.List;

import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

/**
 * List of Jobs with type information. Mockito needs the static type in some rare edge cases.
 */
public class JobListAnswer implements Answer<List<Job< ? , ? >>> {

    /** List of jobs. */
    private final List<Job< ? , ? >> jobs = new ArrayList<Job< ? , ? >>();

    /**
     * Create the answer with an arbitrary number of jobs.
     *
     * @param jobs
     *            to create the answer from
     */
    public JobListAnswer(final Job< ? , ? >... jobs) {
        for (final Job< ? , ? > job : jobs) {
            this.jobs.add(job);
        }
    }

    /**
     * Get the answer.
     */
    public List<Job< ? , ? >> answer(final InvocationOnMock invocation) throws Throwable {
        return jobs;
    }
}
