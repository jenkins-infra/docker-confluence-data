/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.net.URI;
import java.net.URISyntaxException;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import de.bluecarat.trafficlight.connectionhandler.HttpGetHandler;
import de.bluecarat.trafficlight.connectionhandler.exception.HandlerException;
import de.bluecarat.trafficlight.connectionhandler.exception.PowerStripCommunicationException;
import de.bluecarat.trafficlight.powerstrips.NetControlPowerStrip;

@RunWith(PowerMockRunner.class)
@PrepareForTest(HttpGetHandler.class)
public class NetControlTrafficLightControllerTest {

    private NetControlTrafficLightController controller;

    @Mock
    private HttpGetHandler handler;

    @Rule
    ExpectedException thrown = ExpectedException.none();

    @Before
    public void prepare() {
        final NetControlPowerStrip powerStrip = new NetControlPowerStrip("dc9d87a0-08e2-11e4-a978-0002a5d5c51b",
                "some name", "somehost", "80");
        controller = new NetControlTrafficLightController(powerStrip, handler);
    }

    @Test
    public void shouldTakeNameFromConstructor() {
        assertEquals("some name", controller.getName());
    }

    @Test
    public void shouldTakeIdFromConstructor() {
        assertEquals("dc9d87a0-08e2-11e4-a978-0002a5d5c51b", controller.getId().toString());
    }

    @Test
    public void shouldTurnOnGreen() throws Exception {
        controller.greenOn();
        verify(handler).handle(URI.create("http://somehost:80/mobile.cgi?x=0&F0=0"));
    }

    @Test
    public void shouldTurnOffGreen() throws Exception {
        controller.greenOff();
        verify(handler).handle(URI.create("http://somehost:80/mobile.cgi?x=0&F0=1"));
    }

    @Test
    public void shouldTurnOnYellow() throws Exception {
        controller.yellowOn();
        verify(handler).handle(URI.create("http://somehost:80/mobile.cgi?x=0&F1=0"));
    }

    @Test
    public void shouldTurnOffYellow() throws Exception {
        controller.yellowOff();
        verify(handler).handle(URI.create("http://somehost:80/mobile.cgi?x=0&F1=1"));
    }

    @Test
    public void shouldTurnOnRed() throws Exception {
        controller.redOn();
        verify(handler).handle(URI.create("http://somehost:80/mobile.cgi?x=0&F2=0"));
    }

    @Test
    public void shouldTurnOffRed() throws Exception {
        controller.redOff();
        verify(handler).handle(URI.create("http://somehost:80/mobile.cgi?x=0&F2=1"));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void shouldThrowPowerStripCommunicationExceptionWhenHostnameIsIllegal() throws Exception {
        when(handler.handle(any(URI.class))).thenThrow(URISyntaxException.class);
        thrown.expect(PowerStripCommunicationException.class);
        controller.greenOn();
    }

    @SuppressWarnings("unchecked")
    @Test
    public void shouldThrowwPowerStripCommunicationExceptionnWhenHandlerHasAnError() throws Exception {
        when(handler.handle(any(URI.class))).thenThrow(HandlerException.class);
        thrown.expect(PowerStripCommunicationException.class);
        controller.greenOn();
    }
}
