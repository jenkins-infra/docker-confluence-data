/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight;

import hudson.model.Result;

import java.util.logging.Logger;

/**
 * TrafficLightState machine to handle the state transition for the traffic light. See
 * ../../../doc-files/Traffic-Light-State-Machine.png
 *
 * @author CME
 * @author CST
 *
 */
public enum TrafficLightState {

    /**
     * TrafficLightState red.
     */
    RED {

        /**
         * {@inheritDoc}
         *
         * If it is not a TopLevelProject, the state will not be changed.
         */
        @Override
        public TrafficLightState buildStarted(final boolean isTopLevelProject) {

            if (isTopLevelProject) {
                return super.buildStarted(isTopLevelProject);
            } else {
                return RED; // stay red, because a module has already failed.
            }
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public TrafficLightState buildFinished(final Result result, final boolean isTopLevelProject) {

            // do not distinguish between TopLevelProjects and modules
            // if a module has already failed, build stays red.
            return RED;
        }
    },
    /**
     * TrafficLightState green.
     */
    GREEN {

        /**
         * {@inheritDoc}
         *
         * A build cannot be finished, if it is already in the state GREEN.
         */
        @Override
        public TrafficLightState buildFinished(final Result result, final boolean isTopLevelProject) {

            LOGGER.warning("TrafficLightState.buildFinished" + " called on state GREEN. This must not happen.");
            return ILLEGAL;
        }

    },
    /**
     * TrafficLightState yellow.
     */
    YELLOW,
    /**
     * Will be reached if an illegal operation has been called. e.g. a build has been finished from the green state.
     */
    ILLEGAL;

    /**
     * Logger of this state machine.
     */
    private static final Logger LOGGER = Logger.getLogger(TrafficLightState.class.getName());

    /**
     * Returns the following state after the build has started.
     *
     * @param isTopLevelProject
     *            indicates whether is is a top level project, or e.g. just a module.
     *
     * @return the state, which follows the old state
     */
    public TrafficLightState buildStarted(final boolean isTopLevelProject) {
        return TrafficLightState.YELLOW;
    }

    /**
     * Returns the following state.
     *
     * @param result
     *            to choose the corresponding following state
     * @param isTopLevelProject
     *            true, if the result is the result of a whole project
     * @return following state, depending on the result of the build
     */
    public TrafficLightState buildFinished(final Result result, final boolean isTopLevelProject) {
        if (Result.SUCCESS.equals(result)) {
            if (isTopLevelProject) { // has been successfully finished, and is a project, not e.g. a module
                return GREEN;
            } else { // has been successfully finished, but was not a project (e.g. a module)
                return YELLOW;
            }
        } else {
            return RED;
        }
    }
}
