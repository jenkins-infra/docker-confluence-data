/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.configuration;

import hudson.Extension;
import hudson.model.JobProperty;
import hudson.model.JobPropertyDescriptor;
import hudson.model.Job;

import java.util.ArrayList;
import java.util.List;

import org.kohsuke.stapler.DataBoundConstructor;

/**
 * Represents an identifier to reference a power strip. The outer class {@link TrafficLightId} is used for persistence.
 * The inner classes are used for configuration via UI.
 */
public final class TrafficLightId extends JobProperty<Job< ? , ? >> {

    /**
     * The id.
     */
    private final String id;

    /**
     * Initialize.
     *
     * @param id
     *            to reference the traffic light with
     */
    @DataBoundConstructor
    public TrafficLightId(final String id) {
        super();
        this.id = id;
    }

    /**
     * Getter.
     *
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * {@inheritDoc}
     */
    // CSOFF: AvoidInlineConditionals
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1; // NOPMD: generated
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    } // CSON

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof TrafficLightId)) {
            return false;
        }
        final TrafficLightId other = (TrafficLightId) obj;
        if (id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        return true;
    }

    /**
     * Used by jelly for displaying all available traffic lights.
     */
    @Extension
    public static final class TrafficLightIdDescriptor extends JobPropertyDescriptor {

        /**
         * Service to get all controller names from.
         */
        private TrafficLightRegistry registry;

        /**
         * {@inheritDoc}
         */
        @Override
        public String getDisplayName() {
            return TrafficLightIdDescriptor.class.getSimpleName();
        }

        /**
         * Get all currently registered traffic light controllers.
         *
         * @return the list of currently registered traffic light controllers, never null
         */
        public List<TrafficLight> getAvailableTrafficLights() {
            final List<TrafficLight> trafficLights = new ArrayList<TrafficLight>();
            if (registry != null) {
                for (final String id : registry.getAllControllerIds()) {
                    trafficLights.add(new TrafficLight(registry.getControllerById(id).getName(), id));
                }
            }
            return trafficLights;
        }

        /**
         * @param registry
         *            the registry to set
         */
        public void setTrafficLightRegistry(final TrafficLightRegistry registry) {
            this.registry = registry;
        }

        /**
         * Represents a name and an id for a traffic light.
         */
        public static final class TrafficLight {

            /**
             * Name of the traffic light.
             */
            private final String name;

            /**
             * Id of the traffic light.
             */
            private final String id;

            /**
             * Initialize.
             *
             * @param name
             *            of the traffic light
             * @param id
             *            of the traffic light
             */
            public TrafficLight(final String name, final String id) {
                this.name = name;
                this.id = id;
            }

            /**
             * Getter.
             *
             * @return the name
             */
            public String getName() {
                return name;
            }

            /**
             * Getter.
             *
             * @return the id
             */
            public String getId() {
                return id;
            }
        }
    }
}
