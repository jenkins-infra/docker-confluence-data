/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.controller;

import hudson.util.Secret;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import de.bluecarat.trafficlight.connectionhandler.HttpGetHandler;
import de.bluecarat.trafficlight.connectionhandler.exception.HandlerException;
import de.bluecarat.trafficlight.connectionhandler.exception.PowerStripCommunicationException;
import de.bluecarat.trafficlight.powerstrips.InfraTecPowerStrip;

/**
 * Implementation to provide controlling capabilities to a traffic light attached to the device.
 *
 * This implementation has only been tested with a Infratec PM 211-MIP. This traffic light has no yellow light as it
 * only has 2 slots.
 *
 * @author JSH
 * @author CST
 */
public class InfraTecTrafficLightController extends AbstractTrafficLightController implements TrafficLightController {

    /**
     * Logger to use.
     */
    private static final Logger LOGGER = Logger.getLogger(InfraTecTrafficLightController.class.getName());

    /**
     * Address of the traffic light.
     */
    private static final String ADDRESS = //
            "http://${host}:${port}/sw?u=${username}&p=${password}&o=${color}&f=${status}";

    /**
     * The parameter for the "green" lamp in the URI.
     */
    private static final String GREEN = "1";

    /**
     * The parameter for the "red" lamp in the URI.
     */
    private static final String RED = "2";

    /**
     * Symbol for on.
     */
    private static final String ON = "on";

    /**
     * Symbol for off.
     */
    private static final String OFF = "off";

    /**
     * The username to access the power strip.
     */
    private final String username;
    /**
     * The password to access the power strip.
     */
    private final Secret password;

    /**
     * Handler to use for HTTP calls.
     */
    private final HttpGetHandler handler;

    /**
     * Constructor.
     *
     * @param powerStrip
     *            to get the configuration from
     * @param handler
     *            to use for communication
     */
    public InfraTecTrafficLightController(final InfraTecPowerStrip powerStrip, final HttpGetHandler handler) {
        super(powerStrip);
        this.handler = handler;
        this.username = powerStrip.getUsername();
        this.password = powerStrip.getPassword();
    }

    /**
     * {@inheritDoc}
     * 
     * @throws PowerStripCommunicationException
     */
    @Override
    public final void greenOff() throws PowerStripCommunicationException {
        setTrafficLightStatus(GREEN, OFF);
    }

    /**
     * {@inheritDoc}
     * 
     * @throws PowerStripCommunicationException
     */
    @Override
    public final void greenOn() throws PowerStripCommunicationException {
        setTrafficLightStatus(GREEN, ON);

    }

    /**
     * {@inheritDoc}
     * 
     * @throws PowerStripCommunicationException
     */
    @Override
    public final void redOff() throws PowerStripCommunicationException {
        setTrafficLightStatus(RED, OFF);

    }

    /**
     * {@inheritDoc}
     * 
     * @throws PowerStripCommunicationException
     */
    @Override
    public final void redOn() throws PowerStripCommunicationException {
        setTrafficLightStatus(RED, ON);

    }

    /**
     * This method does nothing. This traffic light has no yellow light as it only has 2 slots.
     */
    @Override
    public final void yellowOff() {
        // nothing to do
    }

    /**
     * This method does nothing. This traffic light has no yellow light as it only has 2 slots.
     */
    @Override
    public final void yellowOn() {
        // nothing to do
    }

    /**
     * Sets the state of the traffic light. This method can only set one status for each call, for example GREEN,ON.
     *
     * @param colour
     *            of the light
     * @param status
     *            on or off
     * @throws PowerStripCommunicationException
     *             Problems during communication with power strip.
     */
    private void setTrafficLightStatus(final String colour, final String status)
            throws PowerStripCommunicationException {
        final Map<String, String> values = new HashMap<String, String>();
        values.put("host", getHostname());
        values.put("port", getPort());
        values.put("username", username);
        values.put("password", Secret.toString(password));
        values.put("color", colour);
        values.put("status", status);
        try {
            final URI uri = buildUri(values);
            LOGGER.fine("opening URI: " + uri.toString());
            handler.handle(uri);
        } catch (URISyntaxException e) {
            throw new PowerStripCommunicationException(e);
        } catch (HandlerException e) {
            throw new PowerStripCommunicationException(e);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected final String getAddressTemplate() {
        return ADDRESS;
    }
}
