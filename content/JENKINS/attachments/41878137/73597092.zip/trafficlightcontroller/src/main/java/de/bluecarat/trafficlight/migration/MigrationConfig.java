/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.migration;

import java.util.ArrayList;
import java.util.List;

/**
 * The migration config. All available migrators are here defined.
 *
 * @author SHO
 *
 */
public class MigrationConfig {

    /**
     * The list of all migrators.
     */
    private final List<Migrator> migrators;

    /**
     * Constructor.
     */
    public MigrationConfig() {
        migrators = new ArrayList<Migrator>();
        migrators.add(new Migrator23To30());
        migrators.add(new Migrator30To31());
    }

    /**
     * Getter.
     *
     * @return the migrators
     */
    public final List<Migrator> getMigrators() {
        return migrators;
    }

}
