/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.controller;

import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import de.bluecarat.trafficlight.connectionhandler.HttpGetHandler;
import de.bluecarat.trafficlight.connectionhandler.HttpPostHandler;
import de.bluecarat.trafficlight.connectionhandler.exception.HandlerException;
import de.bluecarat.trafficlight.connectionhandler.exception.PowerStripCommunicationException;
import de.bluecarat.trafficlight.powerstrips.NetControlV4PowerStrip;

/**
 * Implementation to provide controlling capabilities to a traffic light attached to a NetCtrl power strip with firmware
 * version 4.x.
 *
 * @author MBU
 * @author CST
 *
 */
public class NetControlV4TrafficLightController extends AbstractTrafficLightController //
implements TrafficLightController {

    /**
     * Resource to get for current status.
     */
    public static final String GET_URL_SUFFIX = "strg.cfg";

    /**
     * Resource to post commands to.
     */
    public static final String POST_URL_SUFFIX = "ctrl.htm";

    /**
     * Offset within the data received from the power strip where the socket status begins.
     */
    private static final int DATA_OFFSET_FOR_SOCKETS = 20;

    /**
     * Logger to use.
     */
    private static final Logger LOGGER = Logger.getLogger(NetControlV4TrafficLightController.class.getName());

    /**
     * The parameter for the "green" lamp in the URL.
     */
    private static final String GREEN = "1";

    /**
     * The parameter for the "yellow" lamp in the URL.
     */
    private static final String YELLOW = "0";

    /**
     * The parameter for the "red" lamp in the URL.
     */
    private static final String RED = "2";

    /**
     * Symbol for on.
     */
    private static final String ON = "1";

    /**
     * Symbol for off.
     */
    private static final String OFF = "0";

    /**
     * Address of the traffic light.
     */
    private static final String ADDRESS = "http://${host}:${port}/${path}";

    /**
     * Connects to the power strip and retrieves the current state.
     */
    private final HttpGetHandler httpGetHandler;

    /**
     * Connects to the power strip and updates the current state.
     */
    private final HttpPostHandler httpPostHandler;

    /**
     * Constructor.
     *
     * @param powerStrip
     *            to get the configuration from
     * @param httpGetHandler
     *            to use for communication
     * @param httpPostHandler
     *            to use for communication
     */
    public NetControlV4TrafficLightController(final NetControlV4PowerStrip powerStrip,
            final HttpGetHandler httpGetHandler, final HttpPostHandler httpPostHandler) {
        super(powerStrip);
        this.httpGetHandler = httpGetHandler;
        this.httpPostHandler = httpPostHandler;
    }

    /**
     * {@inheritDoc}
     *
     * @throws PowerStripCommunicationException
     *             Problems during communication with power strip.
     */
    protected final void setTrafficLightStatus(final String colour, final String status)
            throws PowerStripCommunicationException {
        final Map<String, String> values = new HashMap<String, String>();
        values.put("host", getHostname());
        values.put("port", getPort());
        values.put("path", POST_URL_SUFFIX);
        try {
            final String responseContent = getCurrentStatus();
            final String[] lines = responseContent.split(";");
            final String currentStatus = extractCurrentStatusFromServerResponse(colour, lines);
            sleepShort();
            if (!currentStatus.equals(status)) {
                LOGGER.log(Level.FINE, "Changing status of socket " + colour + " to: " + status);
                httpPostHandler.handle(buildUri(values), "F" + colour + "=");
            }
        } catch (URISyntaxException e) {
            throw new PowerStripCommunicationException(e);
        } catch (HandlerException e) {
            throw new PowerStripCommunicationException(e);
        }
    }

    private String getCurrentStatus() throws HandlerException, URISyntaxException {
        final Map<String, String> values = new HashMap<String, String>();
        values.put("host", getHostname());
        values.put("port", getPort());
        values.put("path", GET_URL_SUFFIX);
        return httpGetHandler.handle(buildUri(values));
    }

    private String extractCurrentStatusFromServerResponse(final String colour, final String... lines)
            throws PowerStripCommunicationException {

        final int colourAsInt = Integer.parseInt(colour);
        if (lines.length < DATA_OFFSET_FOR_SOCKETS + colourAsInt) {

            final String message = "Could not get current status from response: " + Arrays.toString(lines);
            LOGGER.log(Level.SEVERE, message);
            throw new PowerStripCommunicationException(message);
        }

        final String currentStatus = lines[DATA_OFFSET_FOR_SOCKETS + colourAsInt];
        LOGGER.log(Level.FINE, "Current status of socket " + colour + " is: " + currentStatus);
        return currentStatus;
    }

    /**
     * {@inheritDoc}
     *
     * @throws PowerStripCommunicationException
     */
    @Override
    public final void greenOff() throws PowerStripCommunicationException {
        setTrafficLightStatus(GREEN, OFF);
    }

    /**
     * {@inheritDoc}
     *
     * @throws PowerStripCommunicationException
     */
    @Override
    public final void greenOn() throws PowerStripCommunicationException {
        setTrafficLightStatus(GREEN, ON);
    }

    /**
     * {@inheritDoc}
     *
     * @throws PowerStripCommunicationException
     */
    @Override
    public final void redOff() throws PowerStripCommunicationException {
        setTrafficLightStatus(RED, OFF);
    }

    /**
     * {@inheritDoc}
     *
     * @throws PowerStripCommunicationException
     */
    @Override
    public final void redOn() throws PowerStripCommunicationException {
        setTrafficLightStatus(RED, ON);
    }

    /**
     * {@inheritDoc}
     *
     * @throws PowerStripCommunicationException
     */
    @Override
    public final void yellowOff() throws PowerStripCommunicationException {
        setTrafficLightStatus(YELLOW, OFF);
    }

    /**
     * {@inheritDoc}
     *
     * @throws PowerStripCommunicationException
     */
    @Override
    public final void yellowOn() throws PowerStripCommunicationException {
        setTrafficLightStatus(YELLOW, ON);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected final String getAddressTemplate() {
        return ADDRESS;
    }
}
