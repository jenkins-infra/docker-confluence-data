/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.powerstrips;

import hudson.Extension;
import hudson.util.Secret;

import org.kohsuke.stapler.DataBoundConstructor;

import de.bluecarat.trafficlight.connectionhandler.HttpGetHandler;
import de.bluecarat.trafficlight.controller.InfraTecTrafficLightController;
import de.bluecarat.trafficlight.controller.TrafficLightController;

/**
 * Configuration class of the InfraTec power strip.
 *
 * @author SHO
 *
 */
public class InfraTecPowerStrip extends AbstractPowerStripWithAuthentication {

    /**
     * Timeout for connections.
     */
    private static final int TIMEOUT_FOR_CONNECTIONS = 30000;

    /**
     * Construct a new InfraTec power strip.
     *
     * @param id
     *            The unique id
     * @param name
     *            The name of the power strip.
     * @param address
     *            The address of the power strip.
     * @param port
     *            The port of the power strip.
     * @param username
     *            The username of the account from the power strip in which you want to communicate.
     * @param password
     *            The password of the user account from the power strip.
     */
    @DataBoundConstructor
    public InfraTecPowerStrip(final String id, final String name, final String address, final String port,
            final String username, final Secret password) {
        super(id, name, address, port, username, password);
    }

    /**
     * Descriptor. Required for auto discovery.
     *
     * @author SHO
     *
     */
    @Extension
    public static final class InfraTecPowerStripDescriptor extends AbstractPowerStripDescriptorWithValidation {

        /**
         * {@inheritDoc}
         */
        @Override
        public String getDisplayName() {
            return "InfraTec";
        }

        /**
         * {@inheritDoc}
         */
        @Override
        protected AbstractPowerStrip getSpecificPowerStrip(final String address, final String port,
                final String username, final String password) {
            return new InfraTecPowerStrip(null, null, address, port, username, Secret.fromString(password));
        }

    }

    /**
     * Creates a {@link InfraTecTrafficLightController} from the configuration.
     *
     * @return the newly created and configured {@link TrafficLightController}
     */
    @Override
    public final TrafficLightController createController() {
        final HttpGetHandler getHandler = new HttpGetHandler(TIMEOUT_FOR_CONNECTIONS);
        return new InfraTecTrafficLightController(this, getHandler);
    }
}
