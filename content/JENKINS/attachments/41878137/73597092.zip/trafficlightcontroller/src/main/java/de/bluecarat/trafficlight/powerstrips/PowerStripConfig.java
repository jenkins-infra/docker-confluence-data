/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.powerstrips;

import hudson.Extension;
import hudson.model.AbstractDescribableImpl;
import hudson.model.Descriptor;

import org.kohsuke.stapler.DataBoundConstructor;

import de.bluecarat.trafficlight.NullSafeJenkins;

/**
 * This class wraps the configuration of a power strip to allow Jenkins to display configuration elements in the UI.
 * 
 * @author SHO
 * 
 */
public class PowerStripConfig extends AbstractDescribableImpl<PowerStripConfig> {

    /**
     * The power strip.
     */
    private final AbstractPowerStrip powerStrip;

    /**
     * Constructor. Will be invoked by jenkins.
     * 
     * @param powerStrip
     *            The specific strip
     */
    @DataBoundConstructor
    public PowerStripConfig(final AbstractPowerStrip powerStrip) {
        super();
        this.powerStrip = powerStrip;
    }

    /**
     * @return the strip
     */
    public final AbstractPowerStrip getPowerStrip() {
        return powerStrip;
    }

    /**
     * Get the descriptor for this class.
     * 
     * @return The descriptor of this class
     */
    @SuppressWarnings("unchecked")
    public final Descriptor<PowerStripConfig> getDescriptor() {
        return NullSafeJenkins.getInstance().getDescriptor(getClass());
    }

    /**
     * Power Strip Descriptor. Needed for auto discovery.
     * 
     * @author SHO
     * 
     */
    @Extension
    public static class PowerStripTypeDesciptor extends Descriptor<PowerStripConfig> {

        /**
         * {@inheritDoc}
         */
        @Override
        public final String getDisplayName() {
            return "Power Strip Config";
        }

    }
}
