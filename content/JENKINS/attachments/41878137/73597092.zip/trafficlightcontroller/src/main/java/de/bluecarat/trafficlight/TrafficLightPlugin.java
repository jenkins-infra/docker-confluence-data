/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight;

import hudson.Plugin;

import java.util.logging.Logger;

/**
 * Base class for the traffic light plugin. Jenkins will find this class and trigger plugin initialization, e.g.
 * register {@link hudson.Extension} annotated classes.
 * 
 * @author SHO
 * 
 */
public class TrafficLightPlugin extends Plugin {

    /**
     * Logger to use.
     */
    private static final Logger LOGGER = Logger.getLogger(TrafficLightPlugin.class.getName());

    /**
     * Called on plugin start.
     */
    @Override
    public final void start() {
        LOGGER.fine("Start traffic light plugin");
    }

}
