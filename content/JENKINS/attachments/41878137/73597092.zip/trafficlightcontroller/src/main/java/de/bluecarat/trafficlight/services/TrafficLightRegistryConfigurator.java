/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.services;

import de.bluecarat.trafficlight.NullSafeJenkins;
import de.bluecarat.trafficlight.TrafficLightStateUpdater;
import de.bluecarat.trafficlight.configuration.TrafficLightId.TrafficLightIdDescriptor;
import de.bluecarat.trafficlight.configuration.TrafficLightRegistry;
import de.bluecarat.trafficlight.powerstrips.AbstractPowerStripDescriptorWithValidation;
import de.bluecarat.trafficlight.powerstrips.InfraTecPowerStrip.InfraTecPowerStripDescriptor;
import de.bluecarat.trafficlight.powerstrips.NetControlPowerStrip.NetControlPowerStripDescriptor;
import de.bluecarat.trafficlight.powerstrips.NetControlV4PowerStrip.NetControlV4PowerStripDescriptor;
import de.bluecarat.trafficlight.powerstrips.PowerStripConfig;
import de.bluecarat.trafficlight.powerstrips.PowerStripList;

/**
 * Configures the traffic light registry. This will happen upon Jenkins start after reading the plugin configuration.
 */
public final class TrafficLightRegistryConfigurator {

    /**
     * Creates the power strip controllers from the current configuration and registers them in the
     * {@link TrafficLightRegistry}. The initialized {@link TrafficLightRegistry} is registered in all run listeners.
     *
     * @param registry
     *            to configure
     * @param powerStrips
     *            to initialize the registry from
     */
    public void initializeTrafficLightRegistry(final TrafficLightRegistry registry, final PowerStripList powerStrips) {
        createAndRegisterControllersForPowerStrips(registry, powerStrips);
        setControllerServiceOnTrafficLightStateUpdater(registry);
        setControllerServiceOnLinkedJobs(registry);
        setRegistryOnDescriptors(registry, InfraTecPowerStripDescriptor.class, NetControlPowerStripDescriptor.class,
                NetControlV4PowerStripDescriptor.class);
    }

    @SuppressWarnings("unchecked")
    private void setRegistryOnDescriptors(final TrafficLightRegistry registry, final Class< ? >... descriptors) {
        for (final Class< ? > descriptorClass : descriptors) {
            final AbstractPowerStripDescriptorWithValidation descriptor = NullSafeJenkins.getInstance()
                    .getDescriptorByType((Class<AbstractPowerStripDescriptorWithValidation>) descriptorClass);
            if (descriptor != null) {
                descriptor.setTrafficLightRegistry(registry);
            }
        }
    }

    private void createAndRegisterControllersForPowerStrips(final TrafficLightRegistry registry,
            final PowerStripList powerStrips) {
        if (powerStrips != null && powerStrips.getPowerStrips() != null) {
            for (final PowerStripConfig config : powerStrips.getPowerStrips()) {
                registry.putController(config.getPowerStrip().createController());
            }
        }
    }

    private void setControllerServiceOnTrafficLightStateUpdater(final TrafficLightRegistry registry) {
        for (final TrafficLightStateUpdater updater : NullSafeJenkins.getInstance().getExtensionList(
                TrafficLightStateUpdater.class)) {
            updater.setTrafficLightRegistry(registry);
        }
    }

    private void setControllerServiceOnLinkedJobs(final TrafficLightRegistry registry) {
        for (final TrafficLightIdDescriptor descriptor : NullSafeJenkins.getInstance().getExtensionList(
                TrafficLightIdDescriptor.class)) {
            descriptor.setTrafficLightRegistry(registry);
        }
    }
}
