/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.configuration;

import hudson.Extension;
import hudson.model.JobProperty;
import hudson.model.JobPropertyDescriptor;
import hudson.model.Job;

import java.util.ArrayList;
import java.util.List;

import org.kohsuke.stapler.DataBoundConstructor;

/**
 * Property for jobs to configure the linkage to power strips. Power strips are referenced by IDs. Multiple power strips
 * per job are supported.
 */
public final class LinkedTrafficLights extends JobProperty<Job< ? , ? >> {

    /**
     * Linked traffic lights.
     */
    private final List<TrafficLightId> trafficLights = new ArrayList<TrafficLightId>();

    /**
     * Initialize.
     *
     * @param trafficLights
     *            to set
     */
    @DataBoundConstructor
    public LinkedTrafficLights(final List<TrafficLightId> trafficLights) {
        super();
        if (trafficLights != null) {
            this.trafficLights.addAll(trafficLights);
        }
    }

    /**
     * @return the trafficLights
     */
    public List<TrafficLightId> getTrafficLights() {
        return trafficLights;
    }

    /**
     * Necessary for jelly.
     */
    @Extension
    public static final class LinkedTrafficLightsDescriptor extends JobPropertyDescriptor {

        /**
         * {@inheritDoc}
         */
        @Override
        public String getDisplayName() {
            return LinkedTrafficLightsDescriptor.class.getSimpleName();
        }
    }
}
