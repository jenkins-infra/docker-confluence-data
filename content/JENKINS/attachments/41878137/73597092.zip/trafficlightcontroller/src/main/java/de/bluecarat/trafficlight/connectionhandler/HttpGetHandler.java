/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.connectionhandler;

import java.io.IOException;
import java.net.URI;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.GetMethod;

import de.bluecarat.trafficlight.connectionhandler.exception.HandlerException;

/**
 * This class is responsible for HTTP Get handling and timeout issues. It requests the content via HTTP Get.
 *
 * @author STH
 * @author SHO
 * @author DKE
 *
 */
public final class HttpGetHandler extends BaseHttpHandler {

    /**
     * Maximum size of http response in bytes in case the size is unknown.
     */
    private static final int MAX_BODY_SIZE = 65536;

    /**
     * Logger for this class.
     */
    private static final Logger LOGGER = Logger.getLogger(HttpGetHandler.class.getName());

    /**
     * Create a new get handler instance.
     *
     * @param timeoutForConnections
     *            for Get and Post requests
     */
    public HttpGetHandler(final int timeoutForConnections) {
        super(timeoutForConnections);
    }

    /**
     * Create a new get handler instance with authentication.
     *
     * @param username
     *            to use for authentication
     * @param password
     *            to use for authentication
     * @param timeoutForConnections
     *            for Get and Post requests
     */
    public HttpGetHandler(final String username, final String password, final int timeoutForConnections) {
        super(username, password, timeoutForConnections);
    }

    /**
     * Execute HTTP-GET request for the given URI.
     *
     * @param uri
     *            to execute a get request for
     * @return The body of the response
     * @throws HandlerException
     *             In case an error occurs
     */
    public String handle(final URI uri) throws HandlerException {
        final String responseContent = retrieveResponse(uri);
        LOGGER.log(Level.FINEST, "Request sucessfully.");
        return responseContent;

    }

    private String retrieveResponse(final URI uri) throws HandlerException {
        final GetMethod getMethod = new GetMethod(uri.toString());
        try {
            LOGGER.log(Level.FINEST, "Executing GET request for " + uri.toString() + ".");
            final int getResult = getHttpclient().executeMethod(getMethod);
            LOGGER.log(Level.FINEST, "Received response.");
            if (getResult != HttpStatus.SC_OK) {
                if (getResult == HttpStatus.SC_UNAUTHORIZED) {
                    throw new HandlerException("Unauthorized. Check your credentials.");
                } else {
                    throw new HandlerException("Unexpected response, aborting (" + uri.getHost() + "). Status code: "
                            + getResult);
                }
            }
        } catch (HttpException e) {
            throw new HandlerException("Unexpected Error, aborting (" + uri.getHost() + ").", e);
        } catch (IOException e) {
            throw new HandlerException("Unexpected Error, aborting (" + uri.getHost() + ").", e);
        }

        return readResponseData(uri, getMethod);
    }

    private String readResponseData(final URI uri, final GetMethod getMethod) throws HandlerException {
        try {
            return getMethod.getResponseBodyAsString(MAX_BODY_SIZE);
        } catch (IOException e) {
            throw new HandlerException("Could not parse response, aborting (" + uri.getHost() + ").", e);
        }
    }
}
