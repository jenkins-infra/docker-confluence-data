/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.services;

import hudson.model.Item;
import hudson.model.TopLevelItem;
import hudson.model.Job;
import hudson.model.Run;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import de.bluecarat.trafficlight.NullSafeJenkins;
import de.bluecarat.trafficlight.configuration.LinkedTrafficLights;
import de.bluecarat.trafficlight.configuration.SelectedTrafficLightEntry;
import de.bluecarat.trafficlight.configuration.TrafficLightId;

/**
 * This service handles collecting specific jobs from jenkins.
 *
 * @author DKE
 * @author SHO
 *
 */
public final class JobCollector {

    /**
     * Collect all jobs that are visualized with the trafficlight from the given job.
     *
     * @param run
     *            to select the traffic light from, which visualizes all collected Jobs
     * @return the set of visualized Jobs, may be empty, if the run is not visualized
     */
    public Set<String> collectAllJobsForTrafficLightOf(final Run< ? , ? > run) {
        // TODO 2013-12-04 Change to Set<Job>
        final Set<String> visualizedJobs = new HashSet<String>();
        final Job< ? , ? > job = run.getParent();
        final LinkedTrafficLights linkedLights = job.getProperty(LinkedTrafficLights.class);
        if (linkedLights != null) { // a configuration was set on this Job
            visualizedJobs.add(job.getDisplayName());
            for (final TrafficLightId light : linkedLights.getTrafficLights()) {
                visualizedJobs.addAll(collectAllVisualizedJobs(new SelectedTrafficLightEntry(light.getId())));
            }
        }
        return visualizedJobs;
    }

    /**
     * Collects all Jobs, which are visualized with the selected Traffic light.
     *
     * @param selectedTrafficLight
     *            traffic light, for which all visualized Jobs are collected
     * @return set with visualized jobs
     */
    public Set<String> collectAllVisualizedJobs(final SelectedTrafficLightEntry selectedTrafficLight) {
        final List<Job< ? , ? >> allJobs = getAllJobsFromJenkins();
        final Set<String> filteredJobs = filterAllJobsForLinkedTrafficLight(allJobs, selectedTrafficLight);
        return new HashSet<String>(filteredJobs);
    }

    private List<Job< ? , ? >> getAllJobsFromJenkins() {
        final List<Job< ? , ? >> jobsFromJenkins = new ArrayList<Job< ? , ? >>();
        for (final Item item : NullSafeJenkins.getInstance().getAllItems()) {
            if (item instanceof TopLevelItem) {
                for (final Job< ? , ? > job : item.getAllJobs()) {
                    jobsFromJenkins.add(job);
                }
            }
        }
        return jobsFromJenkins;
    }

    private Set<String> filterAllJobsForLinkedTrafficLight(final Collection<Job< ? , ? >> allJobs,
            final SelectedTrafficLightEntry selectedTrafficLight) {
        final Set<String> visualizedJobs = new HashSet<String>();
        final String idOfTrafficLight = selectedTrafficLight.getSelectedTrafficLightControllerId();

        for (final Job< ? , ? > job : allJobs) {
            if (hasJobTheIdOfTrafficLight(job, idOfTrafficLight)) {
                visualizedJobs.add(job.getDisplayName());
            }
        }

        return visualizedJobs;
    }

    private boolean hasJobTheIdOfTrafficLight(final Job< ? , ? > job, final String idOfTrafficLight) {
        final LinkedTrafficLights linkedLights = job.getProperty(LinkedTrafficLights.class);
        if (linkedLights != null) {
            for (final TrafficLightId id : linkedLights.getTrafficLights()) {
                if (id.getId().equals(idOfTrafficLight)) {
                    return true;
                }
            }
        }
        return false;
    }
}
