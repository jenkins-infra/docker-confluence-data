/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.powerstrips;

import hudson.util.FormValidation;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.kohsuke.stapler.QueryParameter;

import de.bluecarat.trafficlight.configuration.TrafficLightRegistry;
import de.bluecarat.trafficlight.connectionhandler.exception.PowerStripCommunicationException;
import de.bluecarat.trafficlight.controller.TrafficLightController;

/**
 * Adds name validation to power strip descriptors.
 */
public abstract class AbstractPowerStripDescriptorWithValidation extends AbstractPowerStripDescriptor {

    /** Lowest valid port number. */
    private static final int LOWEST_PORT_NUMBER = 1;

    /** Highest valid port number. */
    private static final int HIGHEST_PORT_NUMBER = 65535;

    /** For getting all available traffic light to check for duplicates. */
    private TrafficLightRegistry registry;

    /**
     * Check if name is not already in use.
     *
     * @param name
     *            the user wants to use for the traffic light
     * @param idOfTrafficLight
     *            of the traffic light in question
     * @return the validation result
     */
    public final FormValidation doCheckName(@QueryParameter final String name,
            @QueryParameter final String idOfTrafficLight) {
        if (StringUtils.isEmpty(name)) {
            return FormValidation.error("The name may not be empty!");
        }

        if (registry == null || isNameAvailable(name, idOfTrafficLight)) {
            return FormValidation.ok();
        } else {
            return FormValidation.error("The name is already in use!");
        }
    }

    @edu.umd.cs.findbugs.annotations.SuppressWarnings(value = "UWF_FIELD_NOT_INITIALIZED_IN_CONSTRUCTOR", //
            justification = "False positive, null-guard for registry is in doCheckName")
    private boolean isNameAvailable(final String name, final String idOfTrafficLight) {
        final Map<String, String> registeredNamesWithId = new HashMap<String, String>();
        for (final String controllerId : registry.getAllControllerIds()) {
            final TrafficLightController controller = registry.getControllerById(controllerId);
            registeredNamesWithId.put(controller.getName(), controller.getId().toString());
        }

        return !registeredNamesWithId.containsKey(name) || registeredNamesWithId.get(name).equals(idOfTrafficLight);
    }

    /**
     * Check if the entered port is a number between 1 and 65535.
     *
     * @param port
     *            to check
     * @return the validation result
     */
    public final FormValidation doCheckPort(@QueryParameter final String port) {
        if (StringUtils.isEmpty(port)) {
            return FormValidation.ok();
        }
        try {
            final int portNumber = Integer.parseInt(port);
            if (isValidPortNumber(portNumber)) {
                return FormValidation.ok();
            } else {
                return FormValidation.error("The port must be a number between 1 and 65535");
            }
        } catch (NumberFormatException e) {
            return FormValidation.error("The port must be a number between 1 and 65535");
        }
    }

    private boolean isValidPortNumber(final int portNumber) {
        return portNumber >= LOWEST_PORT_NUMBER && portNumber <= HIGHEST_PORT_NUMBER;
    }

    /**
     * Check the connection to the power strip with the current variables.
     *
     * @param id
     *            of the power strip
     * @param address
     *            of the power strip
     * @param port
     *            of the power strip
     * @param username
     *            of the power strip
     * @param password
     *            of the power strip
     * @return the result of the connection test.
     */
    public final FormValidation doTestConnection(@QueryParameter("powerStrip.id") final String id,
            @QueryParameter("powerStrip.address") final String address,
            @QueryParameter("powerStrip.port") final String port,
            @QueryParameter("powerStrip.username") final String username,
            @QueryParameter("powerStrip.password") final String password) {
        try {
            getSpecificPowerStrip(address, port, username, password).createController().blink();
            setTrafficLightsBasedOnCurrentStateIfAvailable(id);
            return FormValidation.ok("You should've seen the lights blinking!");
        } catch (PowerStripCommunicationException e) {
            return FormValidation.error(ExceptionUtils.getRootCauseMessage(e));
        }
    }

    private void setTrafficLightsBasedOnCurrentStateIfAvailable(final String id) {
        if (registry != null) {
            final TrafficLightController controller = registry.getControllerById(id);
            if (controller != null) {
                controller.setTrafficLights();
            }
        }
    }

    /**
     * Get the specific power strip for creating its controller for validation.
     *
     * @param address
     *            of power strip
     * @param port
     *            of power strip
     * @param username
     *            of power strip
     * @param password
     *            of power strip
     * @return the specific power strip
     */
    protected abstract AbstractPowerStrip getSpecificPowerStrip(String address, String port, String username,
            String password);

    /**
     * @param registry
     *            the registry to set
     */
    public final void setTrafficLightRegistry(final TrafficLightRegistry registry) {
        this.registry = registry;
    }
}
