/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.configuration;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import de.bluecarat.trafficlight.controller.TrafficLightController;

/**
 * Holds the configured {@link TrafficLightController} for later use.
 *
 */
public final class TrafficLightRegistry {

    /**
     * Saves all the controller by ID.
     */
    private final Map<String, TrafficLightController> controllers = new HashMap<String, TrafficLightController>();

    /**
     * Returns a saved controller with the given id.
     *
     * @param id
     *            to get the corresponding controller
     * @return the controllers
     */
    public TrafficLightController getControllerById(final String id) {
        return controllers.get(id);
    }

    /**
     * Saves a controller with the given id.
     *
     * @param controller
     *            to save
     */
    public void putController(final TrafficLightController controller) {
        controllers.put(controller.getId().toString(), controller);
    }

    /**
     * @return all saves id of all controllers.
     */
    public Set<String> getAllControllerIds() {
        return controllers.keySet();
    }
}
