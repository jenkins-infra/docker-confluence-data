/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight;

import hudson.Extension;
import hudson.model.Result;
import hudson.model.TaskListener;
import hudson.model.TopLevelItem;
import hudson.model.Job;
import hudson.model.Run;
import hudson.model.listeners.RunListener;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.google.inject.Inject;

import de.bluecarat.trafficlight.configuration.LinkedTrafficLights;
import de.bluecarat.trafficlight.configuration.TrafficLightId;
import de.bluecarat.trafficlight.configuration.TrafficLightRegistry;
import de.bluecarat.trafficlight.controller.TrafficLightController;
import de.bluecarat.trafficlight.services.JobCollector;

/**
 * RunListener to listen for runs and set the traffic lights accordingly.
 */
@Extension
public class TrafficLightStateUpdater extends RunListener<Run< ? , ? >> {

    /**
     * Logger to use.
     */
    private static final Logger LOGGER = Logger.getLogger(TrafficLightStateUpdater.class.getName());

    /**
     * Collector for collecting jobs from jenkins.
     */
    private JobCollector collector;

    /**
     * Controller service.
     */
    private TrafficLightRegistry trafficLightRegistry;

    /**
     * @param collector
     *            to do maintenance work
     */
    @Inject
    public final void setCollector(final JobCollector collector) {
        this.collector = collector;
    }

    /**
     * @param trafficLightRegistry
     *            the trafficLightRegistry to set
     */
    public final void setTrafficLightRegistry(final TrafficLightRegistry trafficLightRegistry) {
        this.trafficLightRegistry = trafficLightRegistry;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public final void onStarted(final Run< ? , ? > run, final TaskListener listener) {
        LOGGER.log(Level.FINE, "onStarted called");
        final Set<String> jobsWithTrafficLight = collector.collectAllJobsForTrafficLightOf(run);
        if (!jobsWithTrafficLight.isEmpty() && isJobBuilding(jobsWithTrafficLight)) {
            for (final TrafficLightController controller : getController(run)) {
                controller.buildStarted();
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public final void onFinalized(final Run< ? , ? > run) {
        LOGGER.log(Level.FINE, String.format("onFinalized called with result %s on project %s", run.getResult(), run
                .getParent().getDisplayName()));
        final Set<String> jobsWithTrafficLight = collector.collectAllJobsForTrafficLightOf(run);
        if (!jobsWithTrafficLight.isEmpty() && !isJobBuilding(jobsWithTrafficLight)) {
            final Result globalResult = getGlobalResult(jobsWithTrafficLight);
            for (final TrafficLightController controller : getController(run)) {
                controller.buildFinished(globalResult);
            }
        }
    }

    private List<TrafficLightController> getController(final Run< ? , ? > run) {
        final List<TrafficLightController> controller = new ArrayList<TrafficLightController>();
        final LinkedTrafficLights lights = run.getParent().getProperty(LinkedTrafficLights.class);
        if (trafficLightRegistry != null && lights != null) {
            for (final TrafficLightId light : lights.getTrafficLights()) {
                controller.add(trafficLightRegistry.getControllerById(light.getId()));
            }
        }
        return controller;
    }

    private Result getGlobalResult(final Set<String> observedItems) {
        final Set<Result> results = new HashSet<Result>();
        for (final String projectName : observedItems) {
            final TopLevelItem item = NullSafeJenkins.getInstance().getItem(projectName);
            if (item instanceof Job) {
                results.add(getCurrentStatus((Job< ? , ? >) item));
            }
        }
        return determineGlobalResult(results);
    }

    private Result getCurrentStatus(final Job< ? , ? > job) {
        final Run< ? , ? > lastBuild = job.getLastBuild();
        if (lastBuild != null) {
            final Result currentStatus = lastBuild.getResult();
            if (Result.ABORTED.equals(currentStatus)) {
                return getCurrentStatusForAbortedBuild(job);
            } else {
                return currentStatus;
            }
        } else {
            return Result.SUCCESS;
        }

    }

    private Result getCurrentStatusForAbortedBuild(final Job< ? , ? > job) {
        final Run< ? , ? > lastCompletedBuild = job.getLastCompletedBuild();
        if (lastCompletedBuild != null) {
            return lastCompletedBuild.getResult();
        } else {
            return Result.SUCCESS;
        }
    }

    private Result determineGlobalResult(final Set<Result> results) {
        if (results.contains(Result.SUCCESS) && results.size() == 1) {
            return Result.SUCCESS;
        } else {
            return Result.FAILURE;
        }
    }

    private boolean isJobBuilding(final Set<String> jobs) {
        for (final String name : jobs) {
            final TopLevelItem tli = NullSafeJenkins.getInstance().getItem(name);
            if (tli instanceof Job && ((Job< ? , ? >) tli).isBuilding()) {
                LOGGER.fine(String.format("At least one job is currently building"));
                return true;
            }
        }
        LOGGER.fine(String.format("No job is currently building"));
        return false;
    }
}
