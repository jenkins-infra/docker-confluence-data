/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.migration;

import hudson.model.Item;
import hudson.model.TopLevelItem;
import hudson.model.Job;
import hudson.util.Secret;
import hudson.util.VersionNumber;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Logger;

import de.bluecarat.trafficlight.NullSafeJenkins;
import de.bluecarat.trafficlight.TrafficLightConfigurator;
import de.bluecarat.trafficlight.configuration.LinkedTrafficLights;
import de.bluecarat.trafficlight.configuration.TrafficLightId;
import de.bluecarat.trafficlight.powerstrips.InfraTecPowerStrip;
import de.bluecarat.trafficlight.powerstrips.NetControlPowerStrip;
import de.bluecarat.trafficlight.powerstrips.PowerStripConfig;
import de.bluecarat.trafficlight.powerstrips.PowerStripList;

/**
 * Migrator for the migration of the config file from version 2.2/2.3 to version 3.0.
 *
 * @author SHO
 *
 */
public class Migrator23To30 implements Migrator {

    /**
     * Logger to use.
     */
    private static final Logger LOGGER = Logger.getLogger(Migrator23To30.class.getName());

    /**
     * {@inheritDoc}
     */
    public final boolean canHandle(final VersionNumber version) {
        return new VersionNumber("0").equals(version);
    }

    /**
     * {@inheritDoc}
     */
    public final VersionNumber migrate(final TrafficLightConfigurator configurator) {
        LOGGER.fine("Migrate configuration version 2.2/2.3 to 3.0");

        final ArrayList<PowerStripConfig> powerStrips = new ArrayList<PowerStripConfig>();

        if (netControlNeedsMigration(configurator)) {
            final PowerStripConfig netControl = migrateNetControl(configurator);
            powerStrips.add(netControl);
        }

        if (infraTecNeedsMigration(configurator)) {
            final PowerStripConfig infraTec = migrateInfraTec(configurator);
            powerStrips.add(infraTec);
        }

        configurator.setPowerStripList(new PowerStripList(powerStrips));
        return new VersionNumber("3.0");
    }

    private PowerStripConfig migrateInfraTec(final TrafficLightConfigurator configurator) {
        final UUID generatedUuid = UUID.randomUUID();
        final InfraTecPowerStrip powerStrip = new InfraTecPowerStrip(generatedUuid.toString(), "InfraTecTrafficLight",
                configurator.getInfraTechAddress(), "", "admin", Secret.fromString("admin"));
        linkPowerStripsWithJobs(configurator.getObservedItemNamesInfratech(), generatedUuid);
        return new PowerStripConfig(powerStrip);
    }

    private PowerStripConfig migrateNetControl(final TrafficLightConfigurator configurator) {
        final UUID generatedUuid = UUID.randomUUID();
        final NetControlPowerStrip powerStrip = new NetControlPowerStrip(generatedUuid.toString(),
                "NetControlTrafficLight", configurator.getNetControlAddress(), "");
        linkPowerStripsWithJobs(configurator.getObservedItemNamesNetControl(), generatedUuid);
        return new PowerStripConfig(powerStrip);
    }

    private boolean netControlNeedsMigration(final TrafficLightConfigurator configurator) {
        return !configurator.getNetControlAddress().isEmpty()
                || !configurator.getObservedItemNamesNetControl().isEmpty();
    }

    private boolean infraTecNeedsMigration(final TrafficLightConfigurator configurator) {
        return !configurator.getInfraTechAddress().isEmpty() || !configurator.getObservedItemNamesInfratech().isEmpty();
    }

    /**
     * Link power strips with jobs.
     *
     * @param jobsToLink
     *            The jobs to link
     * @param uuidOfPowerStripToLink
     *            The uuid of the traffic light to link
     */
    public final void linkPowerStripsWithJobs(final List<String> jobsToLink, final UUID uuidOfPowerStripToLink) {
        for (final String jobToLink : jobsToLink) {
            for (final Job< ? , ? > job : getAllJobs()) {
                if (job.getDisplayName().equals(jobToLink)) {
                    try {
                        final List<TrafficLightId> newLinkedLights = new ArrayList<TrafficLightId>();
                        newLinkedLights.addAll(getExistingLinksAndRemoveOldProperty(job));
                        newLinkedLights.add(new TrafficLightId(uuidOfPowerStripToLink.toString()));
                        job.addProperty(new LinkedTrafficLights(newLinkedLights));
                        job.save();
                    } catch (IOException e) {
                        LOGGER.severe("Cannot write job property");
                    }
                }
            }
        }
    }

    @SuppressWarnings("unchecked")
    private List<TrafficLightId> getExistingLinksAndRemoveOldProperty(final Job< ? , ? > job) throws IOException {
        final LinkedTrafficLights exitingLinkedLights = job.getProperty(LinkedTrafficLights.class);
        if (exitingLinkedLights == null) {
            return Collections.EMPTY_LIST;
        } else {
            job.removeProperty(LinkedTrafficLights.class);
            return exitingLinkedLights.getTrafficLights();
        }
    }

    @SuppressWarnings("rawtypes")
    private Set<Job> getAllJobs() {
        final Set<Job> jobs = new HashSet<Job>();
        for (final Item item : NullSafeJenkins.getInstance().getAllItems()) {
            if (item instanceof TopLevelItem) {
                jobs.addAll(item.getAllJobs());
            }
        }
        return jobs;
    }
}
