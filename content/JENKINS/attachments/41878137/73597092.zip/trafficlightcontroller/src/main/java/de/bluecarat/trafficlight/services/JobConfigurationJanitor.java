/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.services;

import hudson.model.Item;
import hudson.model.TopLevelItem;
import hudson.model.Job;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.logging.Logger;

import de.bluecarat.trafficlight.NullSafeJenkins;
import de.bluecarat.trafficlight.configuration.LinkedTrafficLights;
import de.bluecarat.trafficlight.configuration.TrafficLightId;

/**
 * This class takes care of maintenance of job configurations. E.g. deleting orphaned traffic light IDs.
 */
public final class JobConfigurationJanitor {

    /**
     * Logger to use.
     */
    private static final Logger LOGGER = Logger.getLogger(JobConfigurationJanitor.class.getName());

    /**
     * Search and remove invalid links to traffic lights.
     *
     * @param availablePowerStrips
     *            that are currently valid
     */
    public void removeInvalidTrafficLightsFromProjects(final List<TrafficLightId> availablePowerStrips) {

        for (final Item item : NullSafeJenkins.getInstance().getAllItems()) {
            if (item instanceof TopLevelItem) {
                @SuppressWarnings("rawtypes")
                final Collection< ? extends Job> jobs = item.getAllJobs();
                for (final Job< ? , ? > job : jobs) {
                    removeInvalidTrafficLightsFromProject(availablePowerStrips, job);
                }
            }
        }
    }

    private void removeInvalidTrafficLightsFromProject(final List<TrafficLightId> availablePowerStrips,
            final Job< ? , ? > job) {
        final LinkedTrafficLights existingLinkedLights = job.getProperty(LinkedTrafficLights.class);
        if (existingLinkedLights != null) {
            try {
                job.removeProperty(LinkedTrafficLights.class);
                final List<TrafficLightId> validPowerStrips = filterForValidPowerStrips(availablePowerStrips,
                        existingLinkedLights);
                job.addProperty(new LinkedTrafficLights(validPowerStrips));
                job.save();
            } catch (IOException e) {
                LOGGER.severe("Cannot write job property");
            }
        }
    }

    private List<TrafficLightId> filterForValidPowerStrips(final List<TrafficLightId> availablePowerStrips,
            final LinkedTrafficLights oldLinkedLights) {
        final List<TrafficLightId> validEntries = new ArrayList<TrafficLightId>();
        for (final TrafficLightId light : oldLinkedLights.getTrafficLights()) {
            if (availablePowerStrips.contains(light)) {
                validEntries.add(light);
            }
        }
        return validEntries;
    }
}
