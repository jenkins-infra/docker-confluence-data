/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.migration;

import hudson.util.VersionNumber;

import java.util.logging.Logger;

import de.bluecarat.trafficlight.TrafficLightConfigurator;
import de.bluecarat.trafficlight.powerstrips.AbstractPowerStrip;
import de.bluecarat.trafficlight.powerstrips.NetControlV4PowerStrip;
import de.bluecarat.trafficlight.powerstrips.PowerStripConfig;

/**
 * Migrator for the migration of the config file from version 3.0 to version 3.1.
 */
public final class Migrator30To31 implements Migrator {

    /**
     * Logger to use.
     */
    private static final Logger LOGGER = Logger.getLogger(Migrator30To31.class.getName());

    /**
     * {@inheritDoc}
     */
    public boolean canHandle(final VersionNumber version) {
        return new VersionNumber("3.0").equals(version);
    }

    /**
     * {@inheritDoc}
     */
    public VersionNumber migrate(final TrafficLightConfigurator configurator) {
        LOGGER.fine("Migrate configuration version 3.0 to 3.1");
        for (final PowerStripConfig config : configurator.getPowerStripList().getPowerStrips()) {
            final AbstractPowerStrip powerStrip = config.getPowerStrip();
            final boolean isConfigurablePortNewForPowerStrip = !(powerStrip instanceof NetControlV4PowerStrip);
            if (isConfigurablePortNewForPowerStrip) {
                powerStrip.setPort("80");
            }
        }
        return new VersionNumber("3.1");
    }
}
