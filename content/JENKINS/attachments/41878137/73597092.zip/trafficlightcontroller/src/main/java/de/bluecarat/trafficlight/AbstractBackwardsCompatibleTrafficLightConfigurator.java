/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight;

import hudson.model.Descriptor;
import hudson.tasks.Publisher;

import java.util.ArrayList;
import java.util.List;

/**
 * Contains legacy fields for parsing old configuration files.
 *
 * @author SHO
 * @author DKE
 *
 */
public abstract class AbstractBackwardsCompatibleTrafficLightConfigurator extends Descriptor<Publisher> {

    /**
     * List of all projects associated with the net control power strip.
     */
    private final transient List<String> observedItemNamesNetControl = new ArrayList<String>();

    /**
     * List of all projects associated with the infraTec power strip.
     */
    private final transient List<String> observedItemNamesInfratech = new ArrayList<String>();

    /**
     * Address of the net-control server.
     */
    private transient String netControlAddress = "";

    /**
     * Address of infratec server.
     */
    private transient String infraTechAddress = "";

    /**
     * Constructor.
     */
    @SuppressWarnings("unchecked")
    public AbstractBackwardsCompatibleTrafficLightConfigurator() {
        super(self());
    }

    /**
     * @return the observedItemNamesNetControl
     */
    public final List<String> getObservedItemNamesNetControl() {
        return observedItemNamesNetControl;
    }

    /**
     * @param observedItemNamesNetControl
     *            the observedItemNamesNetControl to set
     */
    public final void setObservedItemNamesNetControl(final List<String> observedItemNamesNetControl) {
        this.observedItemNamesNetControl.clear();
        this.observedItemNamesNetControl.addAll(observedItemNamesNetControl);
    }

    /**
     * @return the observedItemNamesInfratech
     */
    public final List<String> getObservedItemNamesInfratech() {
        return observedItemNamesInfratech;
    }

    /**
     * @param observedItemNamesInfratech
     *            the observedItemNamesInfratech to set
     */
    public final void setObservedItemNamesInfratech(final List<String> observedItemNamesInfratech) {
        this.observedItemNamesInfratech.clear();
        this.observedItemNamesInfratech.addAll(observedItemNamesInfratech);
    }

    /**
     * @return the netControlAddress
     */
    public final String getNetControlAddress() {
        return netControlAddress;
    }

    /**
     * @param netControlAddress
     *            the netControlAddress to set
     */
    public final void setNetControlAddress(final String netControlAddress) {
        this.netControlAddress = netControlAddress;
    }

    /**
     * @return the infraTechAddress
     */
    public final String getInfraTechAddress() {
        return infraTechAddress;
    }

    /**
     * @param infraTechAddress
     *            the infraTechAddress to set
     */
    public final void setInfraTechAddress(final String infraTechAddress) {
        this.infraTechAddress = infraTechAddress;
    }
}
