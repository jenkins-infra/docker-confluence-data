/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.configuration;

import hudson.Extension;
import hudson.XmlFile;
import hudson.model.listeners.ItemListener;
import hudson.util.VersionNumber;

import java.io.File;
import java.util.List;
import java.util.logging.Logger;

import com.google.inject.Inject;

import de.bluecarat.trafficlight.NullSafeJenkins;
import de.bluecarat.trafficlight.TrafficLightConfigurator;
import de.bluecarat.trafficlight.migration.MigrationConfig;
import de.bluecarat.trafficlight.migration.Migrator;
import de.bluecarat.trafficlight.migration.exception.CanNotConvertConfigFileException;

/**
 * This class migrates the configuration file of the traffic light plugin if needed. This is done before the plugin
 * itself starts.
 *
 * @author SHO
 *
 */
@Extension
public class TrafficLightConfigurationMigrator extends ItemListener {

    /**
     * Logger to use.
     */
    private static final Logger LOGGER = Logger.getLogger(TrafficLightConfigurationMigrator.class.getName());

    /**
     * List of all available migrators.
     */
    private List<Migrator> availableMigrators;

    /**
     * The TrafficLight Configurator.
     */
    private TrafficLightConfigurator configurator;

    /**
     * The config file version.
     */
    private VersionNumber configVersion;

    /**
     * The program version.
     */
    private VersionNumber programVersion;

    /**
     *
     * @param configurator
     *            The TrafficLightConfigurator (should be injected).
     */
    @Inject
    public final void setTrafficLightConfigurator(final TrafficLightConfigurator configurator) {
        this.configurator = configurator;
    }

    /**
     *
     * @param migrationConfig
     *            The MigrationConfig (should be injected).
     */
    @Inject
    public final void setMigrationConfig(final MigrationConfig migrationConfig) {
        this.availableMigrators = migrationConfig.getMigrators();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public final void onLoaded() {
        LOGGER.fine("onLoaded");
        determineVersionNumbers();
        if (checkForConfigFile()) {
            LOGGER.fine("Checking if migration is needed");
            migrateFromOlderVersion();
            configurator.initializeTrafficLightRegistry();
        }
    }

    /**
     * Check if config file is exist.
     *
     * @return True if config file exist.
     */
    private boolean checkForConfigFile() {
        final XmlFile file = new XmlFile(new File(NullSafeJenkins.getInstance().getRootDir(),
                TrafficLightConfigurator.class.getName() + ".xml"));
        LOGGER.fine("Checking if config exist: " + file.getFile().getAbsolutePath());
        if (file.exists()) {
            return true;
        } else {
            configurator.setVersion(programVersion.toString().split("-")[0]);
            return false;
        }
    }

    /**
     * Determine the version of the config file and of the program.
     */
    private void determineVersionNumbers() {
        if (configurator.getVersion() == null) {
            configVersion = new VersionNumber("0");
        } else {
            configVersion = new VersionNumber(configurator.getVersion());
        }
        LOGGER.fine("Config version is " + configVersion);
        programVersion = NullSafeJenkins.getInstance().getPluginManager().getPlugin("trafficlightcontroller")
                .getVersionNumber();
        LOGGER.fine("Program version is " + programVersion);
    }

    /**
     * Convert the config files from an older version.
     */
    private void migrateFromOlderVersion() {
        if (isProgramVersionNewerThanConfigVersion()) {
            for (final Migrator migrator : availableMigrators) {
                if (migrator.canHandle(configVersion)) {
                    configVersion = migrator.migrate(configurator);
                }
            }
            if (isProgramVersionEqualToConfigVersion()) {
                configurator.setVersion(configVersion.toString());
                configurator.save();
            } else {
                LOGGER.severe("can NOT convert config file");
                throw new CanNotConvertConfigFileException();
            }
        } else {
            LOGGER.fine("No migration is needed");
        }
    }

    private boolean isProgramVersionEqualToConfigVersion() {
        return getCleanProgramVersion().compareTo(configVersion) == 0;
    }

    private boolean isProgramVersionNewerThanConfigVersion() {
        return getCleanProgramVersion().compareTo(configVersion) > 0;
    }

    private VersionNumber getCleanProgramVersion() {
        if (programVersion.toString().contains("-")) {
            return new VersionNumber(programVersion.toString().split("-")[0]);
        } else {
            return programVersion;
        }
    }
}
