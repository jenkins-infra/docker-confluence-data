/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.connectionhandler.exception;

/**
 * This exception type can be used to control error handling within {@link TrafficLightConnectionHandler}
 * implementations.
 */
public class PowerStripCommunicationException extends Exception {

    /**
     * Serialization id.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Create a new instance.
     */
    public PowerStripCommunicationException() {
        super();
    }

    /**
     * Create a new instance providing a cause.
     *
     * @param cause
     *            wrapped by this exception
     */
    public PowerStripCommunicationException(final Exception cause) {
        super(cause);
    }

    /**
     * Create a new instance providing a message.
     *
     * @param message
     *            for details
     */
    public PowerStripCommunicationException(final String message) {
        super(message);
    }
}
