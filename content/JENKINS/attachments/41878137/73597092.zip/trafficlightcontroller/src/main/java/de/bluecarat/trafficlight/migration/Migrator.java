/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.migration;

import hudson.util.VersionNumber;
import de.bluecarat.trafficlight.TrafficLightConfigurator;

/**
 * This interface provides operations for config file migration.
 * 
 * @author SHO
 * 
 */
public interface Migrator {

    /**
     * Check if the implementation can handle the given version.
     * 
     * @param version
     *            The version of the config file
     * 
     * @return If the implementation can handle the config file
     */
    boolean canHandle(VersionNumber version);

    /**
     * Migrate the config file.
     * 
     * @param configurator
     *            The TrafficLight Configurator
     * 
     * @return The new version number after conversion
     */
    VersionNumber migrate(TrafficLightConfigurator configurator);

}
