/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import de.bluecarat.trafficlight.connectionhandler.HttpGetHandler;
import de.bluecarat.trafficlight.connectionhandler.exception.HandlerException;
import de.bluecarat.trafficlight.connectionhandler.exception.PowerStripCommunicationException;
import de.bluecarat.trafficlight.powerstrips.NetControlPowerStrip;

/**
 * Implementation to provide controlling capabilities to a traffic light attached to the device.
 *
 * This implementation has only been tested with a "NET-PwdCtrl" Home http://www.
 * anel-elektronik.de/deutsch/Produkte/NET-PwrCtrl_HOME/net-pwrctrl_home.html
 *
 * @author CST
 *
 */
public class NetControlTrafficLightController extends AbstractTrafficLightController implements TrafficLightController {

    /**
     * Logger to use.
     */
    private static final Logger LOGGER = Logger.getLogger(NetControlTrafficLightController.class.getName());

    /**
     * The parameter for the "green" lamp in the URI.
     */
    private static final String GREEN = "F0";

    /**
     * The parameter for the "yellow" lamp in the URI.
     */
    private static final String YELLOW = "F1";

    /**
     * The parameter for the "red" lamp in the URI.
     */
    private static final String RED = "F2";

    /**
     * Symbol for on.
     */
    private static final String ON = "0";

    /**
     * Symbol for off.
     */
    private static final String OFF = "1";

    /**
     * Address of the traffic light.
     */
    private static final String ADDRESS = "http://${host}:${port}/mobile.cgi?x=0&${color}=${status}";

    /**
     * Connects to the power strip and sets the lights.
     */
    private final HttpGetHandler handler;

    /**
     * Constructor.
     *
     * @param powerStrip
     *            to get the configuration from
     * @param handler
     *            to use for communication
     */
    public NetControlTrafficLightController(final NetControlPowerStrip powerStrip, final HttpGetHandler handler) {
        super(powerStrip);
        this.handler = handler;
    }

    /**
     * Sets the state of the traffic light. This method can only set one status for each call, for example GREEN,ON.
     *
     * @param colour
     *            of the light
     * @param status
     *            on or off
     * @throws PowerStripCommunicationException
     *             Problems during communication with power strip.
     */
    protected final void setTrafficLightStatus(final String colour, final String status)
            throws PowerStripCommunicationException {
        final Map<String, String> values = new HashMap<String, String>();
        values.put("host", getHostname());
        values.put("port", getPort());
        values.put("color", colour);
        values.put("status", status);
        try {
            final URI uri = buildUri(values);
            LOGGER.fine("opening URI: " + uri.toString());
            handler.handle(uri);
        } catch (URISyntaxException e) {
            throw new PowerStripCommunicationException(e);
        } catch (HandlerException e) {
            throw new PowerStripCommunicationException(e);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @throws PowerStripCommunicationException
     */
    @Override
    public final void greenOff() throws PowerStripCommunicationException {
        setTrafficLightStatus(GREEN, OFF);
    }

    /**
     * {@inheritDoc}
     * 
     * @throws PowerStripCommunicationException
     */
    @Override
    public final void greenOn() throws PowerStripCommunicationException {
        setTrafficLightStatus(GREEN, ON);
    }

    /**
     * {@inheritDoc}
     * 
     * @throws PowerStripCommunicationException
     */
    @Override
    public final void redOff() throws PowerStripCommunicationException {
        setTrafficLightStatus(RED, OFF);
    }

    /**
     * {@inheritDoc}
     * 
     * @throws PowerStripCommunicationException
     */
    @Override
    public final void redOn() throws PowerStripCommunicationException {
        setTrafficLightStatus(RED, ON);
    }

    /**
     * {@inheritDoc}
     * 
     * @throws PowerStripCommunicationException
     */
    @Override
    public final void yellowOff() throws PowerStripCommunicationException {
        setTrafficLightStatus(YELLOW, OFF);
    }

    /**
     * {@inheritDoc}
     * 
     * @throws PowerStripCommunicationException
     */
    @Override
    public final void yellowOn() throws PowerStripCommunicationException {
        setTrafficLightStatus(YELLOW, ON);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected final String getAddressTemplate() {
        return ADDRESS;
    }
}
