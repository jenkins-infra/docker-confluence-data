/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.powerstrips;

import hudson.model.AbstractDescribableImpl;

import java.util.UUID;

import org.apache.commons.lang.StringUtils;

import de.bluecarat.trafficlight.controller.TrafficLightController;

/**
 * Abstract template for power strips.
 *
 * @author SHO
 *
 */
public abstract class AbstractPowerStrip extends AbstractDescribableImpl<AbstractPowerStrip> {

    /**
     * The uuid of the controller.
     */
    private final String id;

    /**
     * The name of the power strip.
     */
    private final String name;

    /**
     * The adress of the power strip.
     */
    private final String address;

    /**
     * The port of the power strip.
     */
    private String port;

    /**
     * Constructor.
     *
     * @param name
     *            The name of the power strip
     * @param address
     *            The address of the power strip
     * @param port
     *            The port of the power strip.
     * @param id
     *            The unique id
     */
    public AbstractPowerStrip(final String id, final String name, final String address, final String port) {
        super();
        if (StringUtils.isEmpty(id)) {
            this.id = UUID.randomUUID().toString();
        } else {
            this.id = id;
        }
        this.name = name;
        this.address = address;
        this.port = port;
    }

    /**
     * @return the id
     */
    public final String getId() {
        return id;
    }

    /**
     * @return the name
     */
    public final String getName() {
        return name;
    }

    /**
     * @return the address
     */
    public final String getAddress() {
        return address;
    }

    /**
     * @return the port
     */
    public final String getPort() {
        return port;
    }

    /**
     * @param port
     *            the port to set
     */
    public final void setPort(final String port) {
        this.port = port;
    }

    /**
     * Create the specific traffic light controller based upon the read configuration.
     *
     * @return the newly created and configured traffic light controller
     */
    public abstract TrafficLightController createController();
}
