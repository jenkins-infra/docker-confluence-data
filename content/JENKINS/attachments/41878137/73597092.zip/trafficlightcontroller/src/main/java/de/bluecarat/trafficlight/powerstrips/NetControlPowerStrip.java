/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.powerstrips;

import hudson.Extension;

import org.kohsuke.stapler.DataBoundConstructor;

import de.bluecarat.trafficlight.connectionhandler.HttpGetHandler;
import de.bluecarat.trafficlight.controller.NetControlTrafficLightController;
import de.bluecarat.trafficlight.controller.TrafficLightController;

/**
 * Configuration class of the net control power strip.
 *
 * @author SHO
 *
 */
public class NetControlPowerStrip extends AbstractPowerStrip {

    /**
     * Timeout for connections.
     */
    private static final int TIMEOUT_FOR_CONNECTIONS = 30000;

    /**
     * Construct a new NetControl power strip.
     *
     * @param id
     *            The unique id
     * @param name
     *            The name of the power strip.
     * @param address
     *            The address of the power strip.
     * @param port
     *            The port of the power strip.
     */
    @DataBoundConstructor
    public NetControlPowerStrip(final String id, final String name, final String address, final String port) {
        super(id, name, address, port);
    }

    /**
     * Descriptor. Required for auto discovery.
     *
     * @author STH
     *
     */
    @Extension
    public static final class NetControlPowerStripDescriptor extends AbstractPowerStripDescriptorWithValidation {

        /**
         * {@inheritDoc}
         */
        @Override
        public String getDisplayName() {
            return "Net-Control";
        }

        /**
         * {@inheritDoc}
         */
        @Override
        protected AbstractPowerStrip getSpecificPowerStrip(final String address, final String port,
                final String username, final String password) {
            return new NetControlPowerStrip(null, null, address, port);
        }
    }

    /**
     * Creates a {@link NetControlTrafficLightController} from the configuration.
     *
     * @return the newly created and configured {@link TrafficLightController}
     */
    @Override
    public final TrafficLightController createController() {
        final HttpGetHandler getHandler = new HttpGetHandler(TIMEOUT_FOR_CONNECTIONS);
        return new NetControlTrafficLightController(this, getHandler);
    }
}
