/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.controller;

import hudson.model.Result;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang.text.StrSubstitutor;

import de.bluecarat.trafficlight.TrafficLightState;
import de.bluecarat.trafficlight.connectionhandler.exception.PowerStripCommunicationException;
import de.bluecarat.trafficlight.powerstrips.AbstractPowerStrip;

/**
 * This class handles the state and transitions of traffic lights.
 */
public abstract class AbstractTrafficLightController {

    /**
     * Logger to use.
     */
    private static final Logger LOGGER = Logger.getLogger(AbstractTrafficLightController.class.getName());

    /**
     * Number of ms to wait after the call to the power strip.
     */
    private static final long DELAY = 200L;

    /**
     * Initial TrafficLightState of the traffic light.
     */
    private TrafficLightState trafficLightState = TrafficLightState.GREEN;

    /**
     * The powerStrip.
     */
    private final AbstractPowerStrip powerStrip;

    /**
     * Prevent direct instantiation for base classes.
     */
    protected AbstractTrafficLightController(final AbstractPowerStrip powerStrip) {
        this.powerStrip = powerStrip;
    }

    /**
     * Transition the state to {@link TrafficLightState.YELLOW}, because the build was started.
     */
    public final void buildStarted() {
        final TrafficLightState oldTrafficLightState = trafficLightState;
        trafficLightState = trafficLightState.buildStarted(true);
        LOGGER.fine(String.format("State transition from %s to %s for controller %s", oldTrafficLightState,
                trafficLightState, getName()));
        setTrafficLights();
    }

    /**
     * Transition the state to either {@link TrafficLightState.GREEN} if the build result is successful or
     * {@link TrafficLightState.RED} if the result was not successful. A transition from Yellow to Yellow is not
     * allowed.
     *
     * @param result
     *            with the information, whether the build was successful or not
     */
    public final void buildFinished(final Result result) {
        final TrafficLightState oldTrafficLightState = trafficLightState;
        trafficLightState = trafficLightState.buildFinished(result, true);
        LOGGER.fine(String.format("State transition from %s to %s for controller %s", oldTrafficLightState,
                trafficLightState, getName()));
        setTrafficLights();
    }

    /**
     * Set the lights of the traffic light according to the current state.
     */
    @edu.umd.cs.findbugs.annotations.SuppressWarnings(value = "SWL_SLEEP_WITH_LOCK_HELD")
    public final void setTrafficLights() {

        synchronized (this) {
            LOGGER.info(String.format("Switching traffic light '%s' to: %s", getName(), trafficLightState));
            try {
                switch (trafficLightState) {
                case RED:
                    greenOff();
                    yellowOff();
                    redOn();
                    break;

                case GREEN:
                    yellowOff();
                    redOff();
                    greenOn();
                    break;

                case YELLOW:
                    greenOff();
                    redOff();
                    yellowOn();
                    break;

                case ILLEGAL:
                    yellowOn();
                    redOn();
                    greenOn();
                    break;

                default:
                    throw new UnsupportedOperationException("This default block shall never be reached");
                }
            } catch (PowerStripCommunicationException e) {
                LOGGER.log(Level.SEVERE, "Failed to communicate with power strip.", e);
            }
            try {
                Thread.sleep(DELAY);
            } catch (InterruptedException e) {
                LOGGER.warning("Sleep interrupted. Could not delay return of method.");
            }
        }
    }

    /**
     * Turn on the yellow light.
     *
     * @throws PowerStripCommunicationException
     */
    protected abstract void yellowOn() throws PowerStripCommunicationException;

    /**
     * Turn on the green light.
     *
     * @throws PowerStripCommunicationException
     */
    protected abstract void greenOn() throws PowerStripCommunicationException;

    /**
     * Turn off the red light.
     *
     * @throws PowerStripCommunicationException
     */
    protected abstract void redOff() throws PowerStripCommunicationException;

    /**
     * Turn on the red light.
     *
     * @throws PowerStripCommunicationException
     */
    protected abstract void redOn() throws PowerStripCommunicationException;

    /**
     * Turn off the yellow light.
     *
     * @throws PowerStripCommunicationException
     */
    protected abstract void yellowOff() throws PowerStripCommunicationException;

    /**
     * Turn off the green light.
     *
     * @throws PowerStripCommunicationException
     */
    protected abstract void greenOff() throws PowerStripCommunicationException;

    /**
     * Getter.
     *
     * @return The id of the controller.
     */
    public final UUID getId() {
        return UUID.fromString(powerStrip.getId());
    }

    /**
     * Getter.
     *
     * @return The name of the controller.
     */
    public final String getName() {
        return powerStrip.getName();
    }

    /**
     * Getter.
     *
     * @return The hostname for the controller.
     */
    public final String getHostname() {
        return powerStrip.getAddress();
    }

    /**
     * Getter.
     *
     * @return The port for the controller.
     */
    public final String getPort() {
        return powerStrip.getPort();
    }

    /**
     * Get the address template.
     *
     * @return the address template
     */
    protected abstract String getAddressTemplate();

    /**
     * Build the URI based on the address template and the given values.
     *
     * @param values
     *            to set on the template
     * @return the uri
     * @throws URISyntaxException
     *             when the uri is invalid
     */
    public final URI buildUri(final Map<String, String> values) throws URISyntaxException {
        return new URI(new StrSubstitutor(values).replace(getAddressTemplate()));
    }

    /**
     * Turn all lights off, on and off again.
     *
     * @throws PowerStripCommunicationException
     *             Problems during communication with power strip.
     */
    public final void blink() throws PowerStripCommunicationException {
        allOff();
        sleepLong();
        allOn();
        sleepLong();
        allOff();
    }

    private void allOn() throws PowerStripCommunicationException {
        sleepShort();
        redOn();
        sleepShort();
        yellowOn();
        sleepShort();
        greenOn();
        sleepShort();
    }

    private void allOff() throws PowerStripCommunicationException {
        sleepShort();
        redOff();
        sleepShort();
        yellowOff();
        sleepShort();
        greenOff();
        sleepShort();
    }

    private void sleepLong() {
        final int second = 1000;
        sleep(second);
    }

    /**
     * Wait for a short time.
     */
    protected final void sleepShort() {
        final int forthedSecond = 250;
        sleep(forthedSecond);
    }

    private void sleep(final int time) {
        try {
            Thread.sleep(time);
        } catch (InterruptedException e) {
            LOGGER.warning("Sleep interrupted. Could not delay return of method.");
        }
    }
}
