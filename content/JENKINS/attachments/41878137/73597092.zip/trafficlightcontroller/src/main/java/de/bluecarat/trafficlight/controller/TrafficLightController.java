/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.controller;

import hudson.model.Result;

import java.util.UUID;

import de.bluecarat.trafficlight.connectionhandler.exception.PowerStripCommunicationException;

/**
 * This interface provides all operations necessary to control a traffic sign. The different lights are independent,
 * therefore turning on yellow does not have any side-effects on the other lights.
 *
 * @author CST
 *
 */
public interface TrafficLightController {

    /**
     * Getter.
     *
     * @return The id of the controller.
     */
    UUID getId();

    /**
     * Getter.
     *
     * @return The name of the controller.
     */
    String getName();

    /**
     * Transition the state to {@link de.bluecarat.trafficlight.TrafficLightState.YELLOW}, because the build was
     * started.
     */
    void buildStarted();

    /**
     * Transition the state to either {@link de.bluecarat.trafficlight.TrafficLightState.GREEN} if the build result is
     * successful or {@link de.bluecarat.trafficlight.TrafficLightState.RED} if the result was not successful. A
     * transition from Yellow to Yellow is not allowed.
     *
     * @param result
     *            with the information, whether the build was successful or not
     */
    void buildFinished(final Result result);

    /**
     * Turn all lights off, on and off again.
     * 
     * @throws PowerStripCommunicationException
     *             Problems during communication with power strip.
     */
    void blink() throws PowerStripCommunicationException;

    /**
     * Set the lights of the traffic light according to the current state.
     */
    void setTrafficLights();
}
