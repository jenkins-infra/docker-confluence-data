/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.configuration;

import org.kohsuke.stapler.DataBoundConstructor;

/**
 * Jenkins uses this class e.g. when the user configures a job to be watched by a specific traffic light.
 *
 * @author CSTT
 */
public final class SelectedTrafficLightEntry {

    /**
     * Description of the selected traffic light.
     */
    private final String selectedTrafficLightControllerId;

    /**
     * @return the selectedTrafficLightControllerId
     */
    public String getSelectedTrafficLightControllerId() {
        return selectedTrafficLightControllerId;
    }

    /**
     * Constructor. Called by jenkins.
     *
     * @param selectedTrafficLightControllerId
     *            the id of the traffic light controller, selected in the drop down box at the job configuration
     */
    @DataBoundConstructor
    public SelectedTrafficLightEntry(final String selectedTrafficLightControllerId) {
        this.selectedTrafficLightControllerId = selectedTrafficLightControllerId;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean equals(final Object other) {
        if (other instanceof SelectedTrafficLightEntry) {
            final SelectedTrafficLightEntry otherEntry = (SelectedTrafficLightEntry) other;
            return selectedTrafficLightControllerId.equals(otherEntry.getSelectedTrafficLightControllerId());
        } else {
            return false;
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int hashCode() {
        return selectedTrafficLightControllerId.hashCode();
    }
}
