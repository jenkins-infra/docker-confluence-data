/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.powerstrips;

import hudson.Extension;
import hudson.model.AbstractDescribableImpl;
import hudson.model.Descriptor;

import java.util.List;

import org.kohsuke.stapler.DataBoundConstructor;

import de.bluecarat.trafficlight.NullSafeJenkins;

/**
 * Configuration class of the list of power strips.
 * 
 * @author SHO
 * 
 */
public class PowerStripList extends AbstractDescribableImpl<PowerStripList> {

    /**
     * List of power strip configs.
     */
    private final List<PowerStripConfig> powerStrips;

    /**
     * Constructor. Will invoked by jenkins.
     * 
     * @param powerStrips
     *            List of power strip configs which contains the specific power strip.
     */
    @DataBoundConstructor
    public PowerStripList(final List<PowerStripConfig> powerStrips) {
        super();
        this.powerStrips = powerStrips;
    }

    /**
     * @return the powerStrips
     */
    public final List<PowerStripConfig> getPowerStrips() {
        return powerStrips;
    }

    /**
     * Get all descriptors for power strip list type.
     * 
     * @return Gets the Descriptor to the {@link PowerStripList} type
     */
    @SuppressWarnings("unchecked")
    public final Descriptor<PowerStripList> getDescriptor() {
        return NullSafeJenkins.getInstance().getDescriptor(getClass());
    }

    /**
     * Descriptor. Needed for auto discovery.
     * 
     * @author STH
     * 
     */
    @Extension
    public static class PowerStripListDesciptor extends Descriptor<PowerStripList> {

        /**
         * {@inheritDoc}
         */
        @Override
        public final String getDisplayName() {
            return "PowerStripList";
        }
    }
}
