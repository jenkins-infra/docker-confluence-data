/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.migration.exception;

/**
 * Exception if the config file cannot convert from one version to a newer version.
 *
 * @author SHO
 *
 */
public class CanNotConvertConfigFileException extends RuntimeException {

    /**
     * Default serial version id.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Construct a CanNotConvertConfigFileException with no message.
     */
    public CanNotConvertConfigFileException() {
        super();
    }

    /**
     * Construct a CanNotConvertConfigFileException with message.
     *
     * @param message
     *            The exception message
     */
    public CanNotConvertConfigFileException(final String message) {
        super(message);
    }
}
