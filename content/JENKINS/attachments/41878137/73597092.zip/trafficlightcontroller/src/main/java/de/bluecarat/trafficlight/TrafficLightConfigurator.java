/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight;

import hudson.Extension;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.kohsuke.stapler.StaplerRequest;

import com.google.inject.Inject;

import de.bluecarat.trafficlight.configuration.SelectedTrafficLightEntry;
import de.bluecarat.trafficlight.configuration.TrafficLightId;
import de.bluecarat.trafficlight.configuration.TrafficLightRegistry;
import de.bluecarat.trafficlight.powerstrips.AbstractPowerStrip;
import de.bluecarat.trafficlight.powerstrips.AbstractPowerStripDescriptor;
import de.bluecarat.trafficlight.powerstrips.PowerStripConfig;
import de.bluecarat.trafficlight.powerstrips.PowerStripList;
import de.bluecarat.trafficlight.services.JobCollector;
import de.bluecarat.trafficlight.services.JobConfigurationJanitor;
import de.bluecarat.trafficlight.services.TrafficLightRegistryConfigurator;

/**
 * This class is responsible to let Jenkins add the global.jelly to the configuration list. So the user can configure
 * the traffic light plugin in the jenkins configuration GUI.
 *
 * @author CST
 * @author JSH
 * @author SHO
 * @author DKE
 */
@Extension
public class TrafficLightConfigurator extends AbstractBackwardsCompatibleTrafficLightConfigurator {

    /**
     * The version of the config.
     */
    private String version;

    /**
     * List of all configured power strips.
     */
    private PowerStripList powerStripList;

    /**
     * The registry which contains the controller.
     */
    private transient TrafficLightRegistry registry;

    /**
     * Janitor for cleanup operations on jobs.
     */
    private transient JobConfigurationJanitor janitor;

    /**
     * Collector for collecting jobs from jenkins.
     */
    private transient JobCollector collector;

    /**
     * Configures the traffic light registry based on the plugin configuration.
     */
    private transient TrafficLightRegistryConfigurator registryConfigurator;

    /**
     * Constructor. Also loads the configuration from the configuration file.
     */
    public TrafficLightConfigurator() {
        super();
        load();
    }

    /**
     * @return the power strips
     */
    public final PowerStripList getPowerStripList() {
        return powerStripList;
    }

    /**
     * @param powerStripList
     *            the powerStripList to set
     */
    public final void setPowerStripList(final PowerStripList powerStripList) {
        this.powerStripList = powerStripList;
    }

    /**
     * @param janitor
     *            to do maintenance work
     */
    @Inject
    public final void setJobConfigurationJanitor(final JobConfigurationJanitor janitor) {
        this.janitor = janitor;
    }

    /**
     * @param collector
     *            to collect and filter jobs from jenkins
     */
    @Inject
    public final void setCollector(final JobCollector collector) {
        this.collector = collector;
    }

    /**
     * @param registryConfigurator
     *            to configure the registry based on the plugin configuration
     */
    @Inject
    public final void setRegistryConfigurator(final TrafficLightRegistryConfigurator registryConfigurator) {
        this.registryConfigurator = registryConfigurator;
    }

    /**
     * Getter.
     *
     * @return The version of the config.
     */
    public final String getVersion() {
        return version;
    }

    /**
     * @param version
     *            the version to set
     */
    public final void setVersion(final String version) {
        this.version = version;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public final String getDisplayName() {
        return "TrafficLight configuration";
    }

    /**
     * Get a sorted list of projects with active traffic light as a comma separated string. If the list is empty return
     * "none".
     *
     * @param id
     *            the id of the controller
     *
     * @return Projects as a comma separated string
     */
    public final String getProjectsForIdAsStringList(final String id) {
        final List<String> visualizedJobs = getProjectsForId(id);
        Collections.sort(visualizedJobs, String.CASE_INSENSITIVE_ORDER);
        if (visualizedJobs.isEmpty()) {
            return "none";
        } else {
            return StringUtils.join(visualizedJobs, ", ");
        }
    }

    /**
     * Get list of jobs assigned to the given traffic-light id.
     *
     * @param id
     *            the id of the controller
     *
     * @return Projects as a list of strings
     */
    public final List<String> getProjectsForId(final String id) {
        final SelectedTrafficLightEntry trafficLight = new SelectedTrafficLightEntry(id);
        return new ArrayList<String>(collector.collectAllVisualizedJobs(trafficLight));
    }

    /**
     * Get descriptors for all available power strips.
     *
     * @return List of all available descriptors.
     */
    public final List<AbstractPowerStripDescriptor> getPowerStripDescriptors() {
        return NullSafeJenkins.getInstance().getDescriptorList(AbstractPowerStrip.class);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public final boolean configure(final StaplerRequest req, final JSONObject json) throws FormException {
        powerStripList = req.bindJSON(PowerStripList.class, json);
        initializeTrafficLightRegistry();
        janitor.removeInvalidTrafficLightsFromProjects(getAvailablePowerStrips());
        save();
        return true;
    }

    /**
     * @return the registry
     */
    public final TrafficLightRegistry getTrafficLightRegistry() {
        return registry;
    }

    /**
     * Creates the power strip controllers from the current configuration and registers them in the
     * {@link TrafficLightRegistry}. The initialized {@link TrafficLightRegistry} is registered in all run listeners.
     */
    public final void initializeTrafficLightRegistry() {
        registry = new TrafficLightRegistry();
        registryConfigurator.initializeTrafficLightRegistry(registry, powerStripList);
    }

    private List<TrafficLightId> getAvailablePowerStrips() {
        final List<TrafficLightId> powerStripEntries = new ArrayList<TrafficLightId>();
        if (powerStripList != null && null != powerStripList.getPowerStrips()) {
            for (final PowerStripConfig config : powerStripList.getPowerStrips()) {
                final AbstractPowerStrip powerStrip = config.getPowerStrip();
                powerStripEntries.add(new TrafficLightId(powerStrip.getId()));
            }
        }
        return powerStripEntries;
    }
}
