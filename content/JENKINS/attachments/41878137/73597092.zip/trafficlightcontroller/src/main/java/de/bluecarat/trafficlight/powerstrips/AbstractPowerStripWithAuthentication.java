/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.powerstrips;

import hudson.util.Secret;

/**
 * Configuration class for power strips that need authentication information to be controlled.
 *
 * @author STH
 *
 */
public abstract class AbstractPowerStripWithAuthentication extends AbstractPowerStrip {

    /**
     * The username of the account from the power strip in which you want to communicate.
     */
    private final String username;
    /**
     * The password of the user account from the power strip.
     */
    private final Secret password;

    /**
     * Construct a new power strip with authentication information.
     *
     * @param id
     *            The unique id
     * @param name
     *            The name of the power strip.
     * @param address
     *            The address of the power strip.
     * @param port
     *            The port of the power strip.
     * @param username
     *            The username of the account from the power strip in which you want to communicate.
     * @param password
     *            The password of the user account from the power strip.
     */
    public AbstractPowerStripWithAuthentication(final String id, final String name, final String address,
            final String port, final String username, final Secret password) {
        super(id, name, address, port);
        this.username = username;
        this.password = password;
    }

    /**
     * @return the username
     */
    public final String getUsername() {
        return username;
    }

    /**
     * @return the password
     */
    public final Secret getPassword() {
        return password;
    }
}
