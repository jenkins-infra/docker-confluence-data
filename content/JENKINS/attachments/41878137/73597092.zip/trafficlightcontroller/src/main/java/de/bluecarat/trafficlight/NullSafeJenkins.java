/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight;

import hudson.model.Failure;

import java.util.logging.Level;
import java.util.logging.Logger;

import jenkins.model.Jenkins;

/**
 * This class resolves the current jenkins instance. In case this instance is null an exception is thrown. This way
 * error handling must only be implemented once.
 * 
 * @author STH
 */
public final class NullSafeJenkins {

    /**
     * Logger to use.
     */
    private static final Logger LOGGER = Logger.getLogger(NullSafeJenkins.class.getName());

    private NullSafeJenkins() {
        // do not instantiate
    }

    /**
     * Get the current instance or fail.
     * 
     * @return the current Jenkins instance, never null
     */
    public static Jenkins getInstance() {
        final Jenkins instance = Jenkins.getInstance();
        if (instance == null) {
            final String message = "Could not retrieve Jenkins instance, aborting execution.";
            LOGGER.log(Level.SEVERE, message);
            throw new Failure(message);
        }
        return instance;
    }
}
