/**
 * BLUECARAT AG
 *
 * values at work.
 *
 * Albin-Köbis-Straße 4
 * 51147 Köln
 *
 * http://www.bluecarat.de
 *
 * This module is free software, and you may redistribute it and/or modify it under the same terms as Jenkins itself.
 */
package de.bluecarat.trafficlight.connectionhandler;

import org.apache.commons.httpclient.Credentials;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.UsernamePasswordCredentials;
import org.apache.commons.httpclient.auth.AuthScope;
import org.apache.commons.httpclient.params.HttpConnectionParams;

/**
 *
 * Base class for HTTP handlers. Timeout and authentication features are provided.
 *
 * @author DKE
 * @author STH
 *
 */
public class BaseHttpHandler {

    /**
     * HTTP client to use to communicate.
     */
    private final HttpClient httpclient;
    /**
     * User name to use for authentication.
     */
    private final String username;
    /**
     * Password to use for authentication.
     */
    private final String password;
    /**
     * How long to wait for a successful connection setup.
     */
    private final int timeoutForConnections;

    /**
     * Create a new get handler instance.
     *
     * @param timeoutForConnections
     *            for Get and Post requests
     */
    public BaseHttpHandler(final int timeoutForConnections) {
        this.username = null; // NOPMD: final declaration needs assignment
        this.password = null; // NOPMD: final declaration needs assignment
        this.timeoutForConnections = timeoutForConnections;
        this.httpclient = createAndConfigureHttpClient();

    }

    /**
     * Create a new get handler instance with authentication.
     *
     * @param username
     *            to use for authentication
     * @param password
     *            to use for authentication
     * @param timeoutForConnections
     *            for Get and Post requests
     */
    public BaseHttpHandler(final String username, final String password, final int timeoutForConnections) {
        this.username = username;
        this.password = password;
        this.timeoutForConnections = timeoutForConnections;
        this.httpclient = createAndConfigureHttpClientWithAuth();
    }

    private HttpClient createAndConfigureHttpClientWithAuth() {
        final HttpClient client = createAndConfigureHttpClient();
        configureAuthentication(client);
        return client;
    }

    private HttpClient createAndConfigureHttpClient() {
        final HttpClient client = new HttpClient();
        configureTimeouts(client);
        return client;
    }

    private void configureAuthentication(final HttpClient client) {
        final Credentials credentials = new UsernamePasswordCredentials(username, password);
        client.getState().setCredentials(AuthScope.ANY, credentials);
        client.getParams().setAuthenticationPreemptive(true);
    }

    private void configureTimeouts(final HttpClient client) {
        final HttpConnectionParams params = client.getHttpConnectionManager().getParams();
        params.setConnectionTimeout(timeoutForConnections);
        params.setSoTimeout(timeoutForConnections);
    }

    /**
     * @return the httpclient
     */
    protected final HttpClient getHttpclient() {
        return httpclient;
    }
}
