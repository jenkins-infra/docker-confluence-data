/*
 * The MIT License
 *
 * Copyright (c) 2004-2011, Sun Microsystems, Inc., Frederik Fromm
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

package hudson.plugins.priorityblocker;

import hudson.Extension;
import hudson.model.JobProperty;
import hudson.model.JobPropertyDescriptor;
import hudson.model.Job;

import java.util.logging.Level;
import java.util.logging.Logger;

import net.sf.json.JSONException;
import net.sf.json.JSONObject;

import org.kohsuke.stapler.StaplerRequest;

/**
 * WARNING: DO NOT RENAME THE BuildBlockerProperty CLASS!!! If you name it anything else then the jenkins config prompt won't show up
 */
public class BuildBlockerProperty extends JobProperty<Job<?, ?>> {
    /**
     * the logger
     */
    private static final Logger LOG = Logger.getLogger(BuildBlockerProperty.class.getName());

    /**
     * the enable checkbox in the job's config
     */
    public static final String USE_PRIORITY_BLOCKER = "usePriorityBlocker";

    /**
     * priority form field name
     */
    public static final String PRIORITY_KEY = "priority";
    
    /**
     * flag if priority blocker should be used
     */
    private boolean usePriorityBlocker;

    /**
     * the job names that block the build if running
     */
    private int priority;


    public boolean isUsePriorityBlocker() {
        return usePriorityBlocker;
    }

    public void setUsePriorityBlocker(boolean usePriorityBlocker) {
        this.usePriorityBlocker = usePriorityBlocker;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    /**
     * Descriptor
     */
    @Extension
    public static final class PriorityBlockerDescriptor extends JobPropertyDescriptor {

        /**
         * Constructor loading the data from the config file
         */
        public PriorityBlockerDescriptor() {
            load();
        }

        /**
         * Returns the name to be shown on the website
         * @return the name to be shown on the website.
         */
        @Override
        public String getDisplayName() {
            return Messages.DisplayName();
        }

        /**
         * Returns a new instance of the build blocker property
         * when job config page is saved.
         * @param req stapler request
         * @param formData  the form data
         * @return a new instance of the build blocker property
         * @throws FormException
         */
        @Override
        public BuildBlockerProperty newInstance(StaplerRequest req, JSONObject formData) throws FormException {
          BuildBlockerProperty blockerProperty = new BuildBlockerProperty();

            if(formData.containsKey(USE_PRIORITY_BLOCKER)) {
                try {
                    blockerProperty.setUsePriorityBlocker(true);
                    blockerProperty.setPriority(formData.getJSONObject(USE_PRIORITY_BLOCKER).getInt(PRIORITY_KEY));

                } catch(JSONException e) {
                    blockerProperty.setUsePriorityBlocker(false);
                    LOG.log(Level.WARNING, "could not get blocking jobs from " + formData.toString() + ": " + e);
                }
            }

            return blockerProperty;
        }

        /**
         * Returns always true a it can be used in all types of jobs.
         * @param jobType the job type to be checked if this property is applicable.
         * @return true
         */
        @Override
        public boolean isApplicable(Class<? extends Job> jobType) {
            return true;
        }
    }

}
