/*
 * The MIT License
 *
 * Copyright (c) 2004-2011, Sun Microsystems, Inc., Frederik Fromm
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

package hudson.plugins.priorityblocker;

import hudson.model.AbstractProject;
import hudson.model.Queue;
import hudson.model.Queue.BuildableItem;
import hudson.model.queue.SubTask;

import java.util.List;

/**
 * This class represents a monitor that checks all pending jobs for a higher priority job
 *
 * The first hit returns the blocking job's name.
 */
public class BlockingPriorityMonitor {
  
  /**
   * Returns the name of the first blocking pending job. If not found, it returns null.
   * @param item The queue item for which we are checking whether it can run or not.
   *        or null if we are not checking a job from the queue (currently only used by testing).
   * @return the name of the first blocking job.
   */
  public static SubTask getHigherPriorityPendingJob(Queue.Item currentItem, int currentItemPriority) {
    
    /*
     * check the items in the queue
     */
    Queue.Item[] queueItems = Queue.getInstance().getItems();
    for(Queue.Item queueItem:queueItems){
      if(currentItem != queueItem){
        AbstractProject<?, ?> project = (AbstractProject<?, ?>)queueItem.task;
        BuildBlockerProperty queueItemBlockerProperty = project.getProperty(BuildBlockerProperty.class);
        if(queueItemBlockerProperty!=null){
          if(currentItemPriority > queueItemBlockerProperty.getPriority()){
            return project;
          }
        }
      }
    }
    
    /**
     * check the list of items that have
     * already been approved for building
     * (but haven't actually started yet)
     */
    List<BuildableItem> pendingItems = Queue.getInstance().getPendingItems();
    for(BuildableItem pendingItem:pendingItems){
      if(currentItem != pendingItem){
        AbstractProject<?, ?> project = (AbstractProject<?, ?>)pendingItem.task;
        BuildBlockerProperty pendingItemBlockerProperty = project.getProperty(BuildBlockerProperty.class);
        if(pendingItemBlockerProperty!=null){
          if(currentItemPriority > pendingItemBlockerProperty.getPriority()){
            return project;
          }
        }
      }
    }
    
    return null;
  }
  
}
