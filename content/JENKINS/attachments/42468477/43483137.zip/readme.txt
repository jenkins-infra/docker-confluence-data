This is the Serenity code coverage packaged files. It includes the Serenity jar and 
required libraries. Please refer to the wiki for either Jenkins or Hudson to configure 
Serenity to generate coverage and code metrics for your Ant or Maven project.

Jenkins: https://wiki.jenkins-ci.org/display/JENKINS/Serenity+Plugin
Hudson: http://wiki.hudson-ci.org/display/HUDSON/Serenity+Plugin